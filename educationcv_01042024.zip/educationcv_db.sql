-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 04, 2024 at 04:52 AM
-- Server version: 8.0.31
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `educationcv_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cms_page`
--

DROP TABLE IF EXISTS `tbl_cms_page`;
CREATE TABLE IF NOT EXISTS `tbl_cms_page` (
  `_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `contant` longtext NOT NULL,
  `created_at` timestamp NOT NULL,
  `modified_at` timestamp NOT NULL,
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `tbl_cms_page`
--

INSERT INTO `tbl_cms_page` (`_id`, `name`, `contant`, `created_at`, `modified_at`) VALUES
(1, 'Terms & Conditions', '<p>By using this website, you agree to the following terms:</p>\r\n\r\n<ol>\r\n	<li>\r\n	<p><strong>Acceptance:</strong> You agree to abide by these terms and use the website lawfully.</p>\r\n	</li>\r\n	<li>\r\n	<p><strong>Changes:</strong> We can update these terms at any time without notice, so check periodically.</p>\r\n	</li>\r\n	<li>\r\n	<p><strong>Privacy:</strong> Your use of this website is also subject to our Privacy Policy.</p>\r\n	</li>\r\n	<li>\r\n	<p><strong>Intellectual Property:</strong> All content on this website is protected; you can&#39;t use it without permission.</p>\r\n	</li>\r\n	<li>\r\n	<p><strong>Disclaimer:</strong> We provide information as is, without guarantees on accuracy or completeness.</p>\r\n	</li>\r\n	<li>\r\n	<p><strong>Limitation of Liability:</strong> We&#39;re not responsible for any damages resulting from the use of this website.</p>\r\n	</li>\r\n	<li>\r\n	<p><strong>Governing Law:</strong> These terms are governed by the laws of [Your Jurisdiction].</p>\r\n	</li>\r\n	<li>\r\n	<p><strong>Contact:</strong> If you have questions, reach out to us at [Contact Email].</p>\r\n	</li>\r\n</ol>\r\n', '2023-10-27 05:19:33', '2023-10-27 05:19:33');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comments`
--

DROP TABLE IF EXISTS `tbl_comments`;
CREATE TABLE IF NOT EXISTS `tbl_comments` (
  `_id` int NOT NULL AUTO_INCREMENT,
  `register_id` int NOT NULL,
  `post_register_id` int NOT NULL,
  `message` text NOT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`_id`),
  KEY `register_id` (`register_id`),
  KEY `post_register_id` (`post_register_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `tbl_comments`
--

INSERT INTO `tbl_comments` (`_id`, `register_id`, `post_register_id`, `message`, `status`, `created_at`) VALUES
(1, 2, 1, 'Testing messages', 1, '2023-10-24 10:08:42'),
(2, 2, 1, 'Testing messages', 1, '2023-10-24 10:08:42'),
(3, 2, 1, 'Testing messages', 1, '2023-10-24 10:08:42'),
(4, 2, 1, 'Testing messages', 1, '2023-10-24 10:08:42'),
(5, 2, 1, 'Testing messages', 1, '2023-10-24 10:08:42'),
(6, 2, 1, 'Testing messages', 1, '2023-10-24 10:08:42'),
(7, 1, 2, 'nice aasd asdnajshdasd ,masbdjkasbdad', 1, '2023-12-11 11:31:13'),
(8, 1, 2, 'no need to discuss more', 1, '2023-12-11 11:31:36');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact_us`
--

DROP TABLE IF EXISTS `tbl_contact_us`;
CREATE TABLE IF NOT EXISTS `tbl_contact_us` (
  `_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL,
  `modified_at` timestamp NOT NULL,
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `tbl_contact_us`
--

INSERT INTO `tbl_contact_us` (`_id`, `name`, `email_id`, `subject`, `message`, `created_at`, `modified_at`) VALUES
(1, 'Vishal Patel', 'vishal@gmail.com', 'Help', 'I need help for register account', '2023-10-27 05:19:33', '2023-10-27 05:19:33'),
(2, 'aasdasd', 'sadasdas@gmail.com', 'asdad', 'adadadasd', '2023-11-03 12:10:02', '0000-00-00 00:00:00'),
(3, 'sada', 'dasda@gmail.com', 'adsadad', 'asdadad', '2023-11-03 12:11:03', '0000-00-00 00:00:00'),
(4, 'pankaj', 'pankaj@gmail.com', 'NEED HELP', 'ANY THING', '2023-11-07 10:08:18', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_education_exp`
--

DROP TABLE IF EXISTS `tbl_education_exp`;
CREATE TABLE IF NOT EXISTS `tbl_education_exp` (
  `_id` int NOT NULL AUTO_INCREMENT,
  `register_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `collage_name` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `start_year` year NOT NULL,
  `end_year` year DEFAULT NULL,
  `spent` int NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`_id`),
  KEY `register_id` (`register_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `tbl_education_exp`
--

INSERT INTO `tbl_education_exp` (`_id`, `register_id`, `name`, `collage_name`, `details`, `start_year`, `end_year`, `spent`, `created_at`) VALUES
(1, 2, 'Senior UI/UX Designer', 'Adobe Corporation', 'In publishing and graphic design, lorem ipsum is a filler text or greeking commonly used to demonstrate the textual elements of a graphic document or visual presentation. Lorem Ipsum is also known as: Greeked text.', 2005, 2013, 5000, '2023-10-24 10:09:26'),
(2, 2, 'Testing changes', 'sdfsfsdf', 'sdfsfsdfsdfsdf sfsf sdfsf', 2000, 2001, 5000, '2023-11-23 05:46:44');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_education_traning`
--

DROP TABLE IF EXISTS `tbl_education_traning`;
CREATE TABLE IF NOT EXISTS `tbl_education_traning` (
  `_id` int NOT NULL AUTO_INCREMENT,
  `register_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `collage_name` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `start_year` year NOT NULL,
  `end_year` year DEFAULT NULL,
  `spent` int NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`_id`),
  KEY `register_id` (`register_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `tbl_education_traning`
--

INSERT INTO `tbl_education_traning` (`_id`, `register_id`, `name`, `collage_name`, `details`, `start_year`, `end_year`, `spent`, `created_at`) VALUES
(1, 1, 'Architecure', 'Politehnica University of Timisoara: Bachelor of Architecture', 'In publishing and graphic design, lorem ipsum is a filler text or greeking commonly used to demonstrate the textual elements of a graphic document or visual presentation. Lorem Ipsum is also known as: Greeked text.', 2011, 2015, 8541, '2023-10-24 10:10:03'),
(3, 2, 'Testing', 'sdfsfsdf', 'sdfsdfsdf', 1997, 2002, 5241, '2023-11-23 10:32:28'),
(5, 2, 'dsfsdfsdfdsf', 'sdfsdf', 'fsdfsdfsdfsd', 1998, 2023, 5885, '2023-11-23 12:06:33');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_followers`
--

DROP TABLE IF EXISTS `tbl_followers`;
CREATE TABLE IF NOT EXISTS `tbl_followers` (
  `_id` int NOT NULL AUTO_INCREMENT,
  `register_id` int NOT NULL,
  `post_register_id` int NOT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`_id`),
  KEY `register_id` (`register_id`),
  KEY `post_register_id` (`post_register_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `tbl_followers`
--

INSERT INTO `tbl_followers` (`_id`, `register_id`, `post_register_id`, `status`, `created_at`) VALUES
(1, 2, 1, 1, '2023-10-24 10:08:42'),
(2, 1, 2, 2, '2023-10-24 10:08:42');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_graduate_certificate`
--

DROP TABLE IF EXISTS `tbl_graduate_certificate`;
CREATE TABLE IF NOT EXISTS `tbl_graduate_certificate` (
  `_id` int NOT NULL AUTO_INCREMENT,
  `register_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `course_name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `location` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `file` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`_id`),
  KEY `register_id` (`register_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `tbl_graduate_certificate`
--

INSERT INTO `tbl_graduate_certificate` (`_id`, `register_id`, `name`, `course_name`, `location`, `file`, `created_at`) VALUES
(1, 1, 'Senior Editor', 'Marketing & Communication', 'London, UK', 'coursefile.png', '2023-10-24 10:10:31'),
(3, 2, 'asdas', 'dasdasd', 'asdad', '27331700819385.png', '2023-11-24 09:49:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

DROP TABLE IF EXISTS `tbl_login`;
CREATE TABLE IF NOT EXISTS `tbl_login` (
  `_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`_id`, `username`, `email_id`, `password`) VALUES
(1, 'admin', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_non_award_program`
--

DROP TABLE IF EXISTS `tbl_non_award_program`;
CREATE TABLE IF NOT EXISTS `tbl_non_award_program` (
  `_id` int NOT NULL AUTO_INCREMENT,
  `register_id` int NOT NULL,
  `name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`_id`),
  KEY `register_id` (`register_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `tbl_non_award_program`
--

INSERT INTO `tbl_non_award_program` (`_id`, `register_id`, `name`, `created_at`) VALUES
(1, 1, 'PHP', '0000-00-00 00:00:00'),
(2, 1, 'GOOGLE HOSTING\r\n', '0000-00-00 00:00:00'),
(4, 2, 'Testing', '2023-11-24 09:58:59');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_profile_view`
--

DROP TABLE IF EXISTS `tbl_profile_view`;
CREATE TABLE IF NOT EXISTS `tbl_profile_view` (
  `_id` int NOT NULL AUTO_INCREMENT,
  `register_id` int NOT NULL,
  `date` date NOT NULL,
  `views` int NOT NULL,
  PRIMARY KEY (`_id`),
  KEY `register_id` (`register_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `tbl_profile_view`
--

INSERT INTO `tbl_profile_view` (`_id`, `register_id`, `date`, `views`) VALUES
(1, 1, '2023-10-24', 105);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_register`
--

DROP TABLE IF EXISTS `tbl_register`;
CREATE TABLE IF NOT EXISTS `tbl_register` (
  `_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `mobile_no` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `email_id` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `otp` int DEFAULT NULL,
  `profession` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `photo` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `profile_url` varchar(255) NOT NULL,
  `location` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `followers` int NOT NULL,
  `following` int NOT NULL,
  `profile_view` int NOT NULL,
  `about_us` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `status` int NOT NULL,
  `is_suspend` int NOT NULL,
  `created_at` timestamp NOT NULL,
  `modified_at` timestamp NOT NULL,
  PRIMARY KEY (`_id`),
  UNIQUE KEY `email_id` (`email_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `tbl_register`
--

INSERT INTO `tbl_register` (`_id`, `name`, `mobile_no`, `email_id`, `password`, `otp`, `profession`, `photo`, `profile_url`, `location`, `followers`, `following`, `profile_view`, `about_us`, `status`, `is_suspend`, `created_at`, `modified_at`) VALUES
(1, 'Ann R. Robinson', '9874563210', 'Robinson@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', NULL, 'Designer', NULL, 'Robinson123', 'San Francisco, CA', 120, 100, 152, 'Lorem Ipsum is also known as: Greeked text, blind text, placeholder text, dummy content, filler text, lipsum, and mock-content. In publishing and graphic design, lorem ipsum is a filler text or greeking commonly used to demonstrate the textual elements of a graphic document or visual presentation.\r\n\r\nIn publishing and graphic design, lorem ipsum is a filler text or greeking commonly used to demonstrate the textual elements of a graphic document or visual presentation. Lorem Ipsum is also known as: Greeked text.', 1, 0, '2023-10-24 10:05:52', '2023-10-24 10:05:52'),
(2, 'Pankaj Variya', '9874563210', 'pankaj@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', NULL, 'PHP Developer', '58261699612818.png', 'pankaj1', 'Surat, Gujarat, India', 200, 0, 0, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 1, 0, '2023-11-03 06:29:12', '2023-12-21 05:54:40');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_social_media`
--

DROP TABLE IF EXISTS `tbl_social_media`;
CREATE TABLE IF NOT EXISTS `tbl_social_media` (
  `_id` int NOT NULL AUTO_INCREMENT,
  `register_id` int NOT NULL,
  `faceboook_link` text,
  `twitter_link` text,
  `instagram_link` text,
  `linkedin_link` text,
  `youtube_link` text,
  `pinterest_link` text,
  `snapchat_link` text,
  `whatsapp_link` text,
  `threads_link` text,
  `tiktok_link` text,
  `others_link` text,
  PRIMARY KEY (`_id`),
  KEY `register_id` (`register_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `tbl_social_media`
--

INSERT INTO `tbl_social_media` (`_id`, `register_id`, `faceboook_link`, `twitter_link`, `instagram_link`, `linkedin_link`, `youtube_link`, `pinterest_link`, `snapchat_link`, `whatsapp_link`, `threads_link`, `tiktok_link`, `others_link`) VALUES
(2, 2, 'http://localhost/educationcv/profile', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://localhost/educationcv/profile', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_websites`
--

DROP TABLE IF EXISTS `tbl_websites`;
CREATE TABLE IF NOT EXISTS `tbl_websites` (
  `_id` int NOT NULL AUTO_INCREMENT,
  `register_id` int NOT NULL,
  `website_name` text NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`_id`),
  KEY `register_id` (`register_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `tbl_websites`
--

INSERT INTO `tbl_websites` (`_id`, `register_id`, `website_name`, `created_at`) VALUES
(1, 1, 'socailmedisa.com', '0000-00-00 00:00:00'),
(2, 1, 'socailsdfwerfrmedisa.com', '0000-00-00 00:00:00'),
(5, 2, 'https://google.com', '2023-11-24 09:58:42');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_comments`
--
ALTER TABLE `tbl_comments`
  ADD CONSTRAINT `tbl_comments_ibfk_1` FOREIGN KEY (`register_id`) REFERENCES `tbl_register` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_comments_ibfk_2` FOREIGN KEY (`post_register_id`) REFERENCES `tbl_register` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_education_exp`
--
ALTER TABLE `tbl_education_exp`
  ADD CONSTRAINT `tbl_education_exp_ibfk_1` FOREIGN KEY (`register_id`) REFERENCES `tbl_register` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_education_traning`
--
ALTER TABLE `tbl_education_traning`
  ADD CONSTRAINT `tbl_education_traning_ibfk_1` FOREIGN KEY (`register_id`) REFERENCES `tbl_register` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_followers`
--
ALTER TABLE `tbl_followers`
  ADD CONSTRAINT `tbl_followers_ibfk_1` FOREIGN KEY (`post_register_id`) REFERENCES `tbl_register` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_followers_ibfk_2` FOREIGN KEY (`register_id`) REFERENCES `tbl_register` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_graduate_certificate`
--
ALTER TABLE `tbl_graduate_certificate`
  ADD CONSTRAINT `tbl_graduate_certificate_ibfk_1` FOREIGN KEY (`register_id`) REFERENCES `tbl_register` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_non_award_program`
--
ALTER TABLE `tbl_non_award_program`
  ADD CONSTRAINT `tbl_non_award_program_ibfk_1` FOREIGN KEY (`register_id`) REFERENCES `tbl_register` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_profile_view`
--
ALTER TABLE `tbl_profile_view`
  ADD CONSTRAINT `tbl_profile_view_ibfk_1` FOREIGN KEY (`register_id`) REFERENCES `tbl_register` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_social_media`
--
ALTER TABLE `tbl_social_media`
  ADD CONSTRAINT `tbl_social_media_ibfk_1` FOREIGN KEY (`register_id`) REFERENCES `tbl_register` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_websites`
--
ALTER TABLE `tbl_websites`
  ADD CONSTRAINT `tbl_websites_ibfk_1` FOREIGN KEY (`register_id`) REFERENCES `tbl_register` (`_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
