<section class="mt-100">
   <div class="pxp-container">
      <div class="pxp-blog-hero">
         <h1>About Us</h1>
         <div class="pxp-hero-subtitle pxp-text-light">Innovating Tomorrow's Solutions Today</div>
      </div>
      <div class="col-md-12">
         <div>
            <p>At education.cv, we are passionate about helping educators and education professionals advance their careers and make a lasting impact in the world of learning. Our journey began with a simple yet powerful idea: to provide a platform that simplifies the process of creating exceptional CVs tailored to the unique needs of educators.</p>
            <p>Our mission is to empower educators, administrators, researchers, and all those dedicated to the field of education with the tools they need to showcase their skills and experiences effectively. We believe that every educator deserves a compelling CV that highlights their achievements and aspirations.</p>
            <p><b>Expertise:</b> Our team consists of professionals with extensive knowledge in both education and resume writing. We understand the nuances of the education sector and the importance of a well-crafted CV.</p>
            <p><b>User-Friendly:</b> We've designed our platform to be user-friendly and intuitive, making it easy for you to create a polished CV, even if you have no prior experience.</p>
            <p><b>Customization:</b> We offer a range of templates and customization options to ensure your CV reflects your unique personality and professional journey.</p>
            <p><b>Constant Improvement:</b> We are committed to continuous improvement. We regularly update our tools and resources to stay aligned with industry trends and best practices.</p>
            <p><b>Customer Support: </b> Our dedicated customer support team is here to assist you every step of the way, ensuring you have a seamless experience.</p>
            <p>Join Us in Shaping the Future of Education</p>
            <p>We invite you to join our growing community of educators and education enthusiasts who are using education.cv to take their careers to new heights. Whether you're a seasoned educator or just starting out, we are here to support you on your professional journey.</p>
            <p>Thank you for choosing education.cv as your trusted partner in creating outstanding CVs for the world of education.</p>
         </div>
      </div>
   </div>
</section>
<section class="mt-100">
   <div class="pxp-container">
      <div class="row justify-content-between align-items-center mt-4 mt-md-5">
         <div class="col-lg-6 col-xxl-5">
            <div class="pxp-info-fig pxp-animate-in pxp-animate-in-right">
               <div class="pxp-info-fig-image pxp-cover" style="background-image: url(<?php echo WEBASSETS; ?>images/info-section-image.jpg);"></div>
            </div>
         </div>
         <div class="col-lg-5 col-xxl-6">
            <div class="pxp-info-caption pxp-animate-in pxp-animate-in-top mt-4 mt-sm-5 mt-lg-0">
               <h2 class="pxp-section-h2">Empowering Minds, Shaping Futures:<br>Your Education CV Solution.</h2>
               <p class="pxp-text-light">Create a professional education-focused CV with our user-friendly online CV maker website. Choose from a range of templates, input your educational qualifications, and customize your CV to showcase your academic achievements effectively. Impress potential employers and educational institutions with a polished and well-organized CV. Start building your educational CV today!</p>
               <!-- <div class="pxp-info-caption-cta">
                  <a href="#" class="btn rounded-pill pxp-section-cta">Get Started Now<span class="fa fa-angle-right"></span></a>
                  </div> -->
            </div>
         </div>
      </div>
   </div>
</section>