<div class="pxp-dashboard-content-details">
<h2>Welcome, <?php echo $records[0]['name']; ?></h2>
<!-- <p class="pxp-text-light">Welcome to education.cv!</p> -->
<div class="row mt-4 mt-lg-5 align-items-center">
   <div class="col-sm-6 col-xxl-3">
      <a href="<?php echo base_url('followers'); ?>" style="color:black;">
      <div class="pxp-dashboard-stats-card bg-primary bg-opacity-10 mb-3 mb-xxl-0">
         <div class="pxp-dashboard-stats-card-icon text-primary">
            <span class="fa fa-users"></span>
         </div>
         <div class="pxp-dashboard-stats-card-info">
            <div class="pxp-dashboard-stats-card-info-number"><?php echo $records[0]['followers']; ?></div>
            <div class="pxp-dashboard-stats-card-info-text pxp-text-light">Followers</div>
         </div>
      </div>
      </a>
   </div>
   <div class="col-sm-6 col-xxl-3">
      <a href="<?php echo base_url('following'); ?>" style="color:black;">
      <div class="pxp-dashboard-stats-card bg-success bg-opacity-10 mb-3 mb-xxl-0">
         <div class="pxp-dashboard-stats-card-icon text-success">
            <span class="fa fa-users"></span>
         </div>
         <div class="pxp-dashboard-stats-card-info">
            <div class="pxp-dashboard-stats-card-info-number"><?php echo $records[0]['following']; ?></div>
            <div class="pxp-dashboard-stats-card-info-text pxp-text-light">Following</div>
         </div>
      </div>
      </a>
   </div>
   <div class="col-sm-6 col-xxl-3">
      <div class="pxp-dashboard-stats-card bg-warning bg-opacity-10 mb-3 mb-xxl-0">
         <div class="pxp-dashboard-stats-card-icon text-warning">
            <span class="fa fa-eye"></span>
         </div>
         <div class="pxp-dashboard-stats-card-info">
            <div class="pxp-dashboard-stats-card-info-number"><?php echo $records[0]['profile_view']; ?></div>
            <div class="pxp-dashboard-stats-card-info-text pxp-text-light">Profile visits</div>
         </div>
      </div>
   </div>
   <div class="col-sm-6 col-xxl-3">
      <a href="<?php echo base_url('comments'); ?>" style="color:black;">
      <div class="pxp-dashboard-stats-card bg-danger bg-opacity-10 mb-3 mb-xxl-0">
         <div class="pxp-dashboard-stats-card-icon text-danger">
            <span class="fa fa-bell-o"></span>
         </div>
         <div class="pxp-dashboard-stats-card-info">
            <div class="pxp-dashboard-stats-card-info-number"><?php echo $comments; ?></div>
            <div class="pxp-dashboard-stats-card-info-text pxp-text-light">Comments</div>
         </div>
      </div>
      </a>
   </div>
   <div class="col-sm-6 col-xxl-3">
   <!-- linkedin_ajax_form.php -->
      <form id="linkedinForm" method="post" autocomplete="off">
         <label class="mb-4" for="url">Profile URL: <a target="_blank" href="<?php echo base_url().$records[0]['profile_url']; ?>"><?php echo base_url().$records[0]['profile_url']; ?></a></label>
         <div class="input-group mb-3">
            <input type="text" pattern="^\S+$" title="Spaces are not allowed" value="<?php echo $records[0]['profile_url']; ?>" placeholder="Profile URL Name" id="url" class="form-control" placeholder="" required>
            <button type="submit" name="submit" class="btn">Update</button>
         </div>
         <small id="error"></small>
      </form>

      <script>
          $('#linkedinForm').submit(function(e) {
              e.preventDefault();
              var url = $('#url').val();
              $.ajax({
                  type: 'POST',
                  url: '<?= base_url('Profile/process_profile_ajax') ?>',
                  data: { url: url },
                  success: function(response) {
                     if(response == "Profile URL Updated"){
                        $('#error').html('');
                        alert(response);
                        location.reload();
                     }else{
                        $('#error').html(response);
                     }
                  },
                  error: function(xhr, status, error) {
                     $('#error').html(error); 
                  }
              });
          });
      </script>
   </div>
</div>
<!-- <div class="row mt-4 mt-lg-5">
   <div class="col-xl-12">
      <h2>Profile Visits</h2>
      <div class="mt-3 mt-lg-4 pxp-dashboard-chart-container">
         <div class="row justify-content-between align-content-center mb-4">
            <div class="col-auto">
               <span class="pxp-dashboard-chart-value">154</span><span class="pxp-dashboard-chart-percent text-success"><span class="fa fa-long-arrow-up"></span> 34%</span><span class="pxp-dashboard-chart-vs">vs last 7 days</span>
            </div>
            <div class="col-auto">
               <select class="form-select">
                  <option value="-7 days">Last 7 days</option>
                  <option value="-30 days">Last 30 days</option>
                  <option value="-60 days">Last 60 days</option>
                  <option value="-90 days">Last 90 days</option>
                  <option value="-12 months">Last 12 months</option>
               </select>
            </div>
         </div>
         <canvas id="pxp-candidate-dashboard-visits-chart"></canvas>
      </div>
   </div>
</div> -->
<script type="text/javascript">
  $(document).ready(function (e) {
      $(".m_dashboard").addClass('pxp-active');  
  });
</script>