<div class="pxp-dashboard-content-details">
   <ul class="nav nav-pills nav-fill nav-tabs">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('profile'); ?>">Edit Profile</a>
      </li>
      <li class="nav-item">
         <a class="nav-link" href="<?php echo base_url('profile/education_experience'); ?>">Education Experience</a>
      </li>
      <li class="nav-item">
         <a class="nav-link active" aria-current="page" href="<?php echo base_url('profile/education_training'); ?>">Education & Training</a>
      </li>
      <li class="nav-item">
         <a class="nav-link" href="<?php echo base_url('profile/graduate_certificate'); ?>">Graduate Certificate</a>
      </li>
      <li class="nav-item">
         <a class="nav-link" href="<?php echo base_url('profile/programs_websites'); ?>">Programs & Websites</a>
      </li>
   </ul>
   <form method="post" autocomplete="off" enctype="multipart/form-data" onsubmit="return validateYears()">
      <div class="mt-4">
         <?php if ($this->session->flashdata('error')) { ?>
            <div class="alert alert-danger">
                <?php echo $this->session->flashdata('error'); ?>
            </div>
         <?php } ?>
         <?php if ($this->session->flashdata('success')) { ?>
            <div class="alert alert-success">
                <?php echo $this->session->flashdata('success'); ?>
            </div>
         <?php } ?>
         <div class="table-responsive">
            <table class="table align-middle">
               <?php foreach ($education_traning as $key => $value) { ?>
               <tr>
                  <td style="width: 30%;">
                     <div class="pxp-candidate-dashboard-experience-title"><?php echo $value['name']; ?></div>
                  </td>
                  <td style="width: 25%;">
                     <div class="pxp-candidate-dashboard-experience-company"><?php echo $value['collage_name']; ?></div>
                  </td>
                  <td style="width: 15%;">
                     <div class="pxp-candidate-dashboard-experience-time"><?php echo $value['start_year']; ?> - <?php echo $value['end_year']; ?></div>
                  </td>
                  <td style="width: 10%;">
                     <div class="pxp-candidate-dashboard-experience-time"><?php echo $value['spent']; ?></div>
                  </td>
                  <td>
                     <div class="pxp-dashboard-table-options">
                        <ul class="list-unstyled">
                           <li><button type="button" title="Edit"><a href="<?php echo base_url('profile/education_training/').$value['_id']; ?>"><span class="fa fa-pencil"></span></a></button></li>
                           <li><button type="button" title="Delete"><a onclick="return confirm('Are you sure want to delete?')" href="<?php echo base_url('profile/delete_education_training/').$value['_id']; ?>"><span class="fa fa-trash-o"></span></a></button></li>
                        </ul>
                     </div>
                  </td>
               </tr>
               <?php } ?>
            </table>
         </div>
         <div class="row mt-3 mt-lg-4">
            <div class="col-md-6">
               <div class="mb-3">
                  <label for="name" class="form-label">Training title</label>
                  <input type="text" value="<?php if(isset($education_traning_update)){ echo $education_traning_update[0]['name']; } ?>" name="name" id="name" class="form-control" placeholder="E.g. Web Designer" required>
               </div>
            </div>
            <div class="col-md-6">
               <div class="mb-3">
                  <label for="collage_name" class="form-label">University</label>
                  <input type="text" value="<?php if(isset($education_traning_update)){ echo $education_traning_update[0]['collage_name']; } ?>" name="collage_name" id="collage_name" class="form-control" placeholder="University name" required>
               </div>
            </div>
            <div class="col-md-3">
               <div class="mb-3">
                  <label for="start_year" class="form-label">Start Year</label>
                  <input type="number" value="<?php if(isset($education_traning_update)){ echo $education_traning_update[0]['start_year']; } ?>" id="start_year" name="start_year" class="form-control" placeholder="E.g. 2005" required>
               </div>
            </div>
            <div class="col-md-3">
               <div class="mb-3">
                  <label for="end_year" class="form-label">End Year</label>
                  <input type="number" value="<?php if(isset($education_traning_update)){ echo $education_traning_update[0]['end_year']; } ?>" name="end_year" id="end_year" max="<?php echo date('Y'); ?>" class="form-control" placeholder="E.g. 2013" required>
               </div>
            </div>
            <div class="col-md-6">
               <div class="mb-3">
                  <label for="spent" class="form-label">Money Spent</label>
                  <input type="number" value="<?php if(isset($education_traning_update)){ echo $education_traning_update[0]['spent']; } ?>" id="spent" name="spent" class="form-control" placeholder="E.g. 10000" required>
               </div>
            </div>
         </div>
         <div class="mb-3">
            <label for="details" class="form-label">Description</label>
            <textarea class="form-control pxp-smaller" name="details" id="details" placeholder="Type a short description here..." required><?php if(isset($education_traning_update)){ echo $education_traning_update[0]['details']; } ?></textarea>
         </div>
         <button name="submit" class="btn rounded-pill pxp-subsection-cta"><?php if(isset($education_traning_update)){ echo 'Update'; }else{ echo 'Add'; } ?> Experience</button>
      </div>
   </form>
</div>
<script type="text/javascript">
  $(document).ready(function (e) {
      $(".m_profile").addClass('pxp-active');  
  });
</script>
<script>
    function validateYears() {
        var startYear = document.getElementById('start_year').value;
        var endYear = document.getElementById('end_year').value;
        if (parseInt(endYear) <= parseInt(startYear)) {
            alert("End Year must be greater than Start Year");
            return false;
        }
        return true;
    }
</script>