<div class="pxp-dashboard-content-details">
   <ul class="nav nav-pills nav-fill nav-tabs">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('profile'); ?>">Edit Profile</a>
      </li>
      <li class="nav-item">
         <a class="nav-link" href="<?php echo base_url('profile/education_experience'); ?>">Education Experience</a>
      </li>
      <li class="nav-item">
         <a class="nav-link" href="<?php echo base_url('profile/education_training'); ?>">Education & Training</a>
      </li>
      <li class="nav-item">
         <a class="nav-link" href="<?php echo base_url('profile/graduate_certificate'); ?>">Graduate Certificate</a>
      </li>
      <li class="nav-item">
         <a class="nav-link active" aria-current="page" href="<?php echo base_url('profile/programs_websites'); ?>">Programs & Websites</a>
      </li>
   </ul>
   <form method="post" autocomplete="off" enctype="multipart/form-data">
      <div class="mt-4">
         <?php if ($this->session->flashdata('error')) { ?>
            <div class="alert alert-danger">
                <?php echo $this->session->flashdata('error'); ?>
            </div>
         <?php } ?>
         <?php if ($this->session->flashdata('success')) { ?>
            <div class="alert alert-success">
                <?php echo $this->session->flashdata('success'); ?>
            </div>
         <?php } ?>
         <h2>Non-award programs</h2>
         <div class="pxp-candidate-dashboard-skills mb-3">
            <ul class="list-unstyled">
               <?php foreach ($non_award_program as $key => $value) { ?>
               <li><?php echo $value['name']; ?><a onclick="return confirm('Are you sure want to delete?')" href="<?php echo base_url('profile/delete_non_award_program/').$value['_id']; ?>"><span class="fa fa-trash-o"></span></a></li>
               <?php } ?>
            </ul>
         </div>
         <div class="input-group mb-3">
            <input type="text" name="name" class="form-control" placeholder="Non-award programs" required>
            <button type="submit" name="submit1" class="btn">Add Non-award programs</button>
         </div>
      </div>
   </form>
   <form method="post" autocomplete="off" enctype="multipart/form-data">
      <div class="mt-4 mt-lg-5">
         <h2>Websites</h2>
         <div class="pxp-candidate-dashboard-skills mb-3">
            <ul class="list-unstyled">
               <?php foreach ($websites as $key => $value) { ?>
               <li><?php echo $value['website_name']; ?><a onclick="return confirm('Are you sure want to delete?')" href="<?php echo base_url('profile/delete_websites/').$value['_id']; ?>"><span class="fa fa-trash-o"></span></a></li>
               <?php } ?>
            </ul>
         </div>
         <div class="input-group mb-3">
            <input type="url" name="website_name" class="form-control" placeholder="Link" required>
            <button type="submit" name="submit" class="btn">Add Websites</button>
         </div>
      </div>
   </form>
</div>
<script type="text/javascript">
  $(document).ready(function (e) {
      $(".m_profile").addClass('pxp-active');  
  });
</script>