<div class="pxp-dashboard-content-details">
   <ul class="nav nav-pills nav-fill nav-tabs">
     <li class="nav-item">
       <a class="nav-link active" aria-current="page" href="<?php echo base_url('followers'); ?>">Followers</a>
     </li>
     <li class="nav-item">
       <a class="nav-link" href="<?php echo base_url('following'); ?>">Following</a>
     </li>
   </ul>
   <div class="mt-4 mt-lg-5">
      <div class="table-responsive">
         <table id="followers_table" class="table table-hover align-middle">
            <thead>
               <tr>
                  <th style="width: 25%;">Follower Name</th>
                  <th style="width: 20%;">Location</th>
                  <th style="width: 12%;">Followers</th>
                  <th>Status</th>
                  <th>Date</th>
               </tr>
            </thead>
         </table>
      </div>
   </div>
</div>
<script type="text/javascript">
  $(document).ready(function (e) {
      $(".m_followers").addClass('pxp-active');  
  });
</script>
<link  href="https://cdn.datatables.net/1.13.8/css/dataTables.bootstrap5.min.css" rel="stylesheet" type="text/css">
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script> 
<script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
   $('#followers_table').DataTable({
        "responsive": true,
        "pagingType": "full_numbers",
        "processing": true,
        "serverSide": true,
        "order": [],
        "ajax": {
          "url": "<?php echo base_url('followers/getLists'); ?>",
          "type": "POST",
        },
        "columnDefs": [{ 
          "targets": [0,1,2],
          "orderable": false
        }]
      });
  });
</script>