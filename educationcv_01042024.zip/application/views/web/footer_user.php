<footer>
   <div class="pxp-footer-copyright pxp-text-light">© 2023 education.cv. All Right Reserved.</div>
</footer>
</div>
<script src="<?php echo WEBASSETS; ?>js/bootstrap.bundle.min.js"></script>
<script src="<?php echo WEBASSETS; ?>js/owl.carousel.min.js"></script>
<script src="<?php echo WEBASSETS; ?>js/nav.js"></script>
<script src="<?php echo WEBASSETS; ?>js/Chart.min.js"></script>
<script src="<?php echo WEBASSETS; ?>js/main.js"></script>
</body>
</html>