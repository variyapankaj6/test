<footer class="pxp-main-footer">
   <div class="pxp-main-footer-top pt-100 pb-100" style="background-color: var(--pxpMainColorLight);">
      <div class="pxp-container">
         <div class="row">
            <div class="col-lg-6 col-xl-5 col-xxl-4 mb-2">
               <div class="pxp-footer-logo">
                  <a href="<?php echo base_url(); ?>" class="pxp-animate">
                     <img src="<?php echo WEBASSETS; ?>images/logo.png" style="height:30px;margin-bottom: 20px;" alt="Find the perfect job for you">
                     <!-- <span style="color: var(--pxpMainColor)">education</span>.cv -->
                  </a>
                  <P>Building Bright Futures,<br/>One CV Click Away</P>
               </div>
               <div class="mt-2 mt-md-4 pxp-footer-section">
                  <div class="pxp-footer-social mt-3">
                     <ul class="list-unstyled">
                        <li style="margin-left: 5px;"><a href="#"><span class="fa fa-facebook"></span></a></li>
                        <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                        <li><a href="#"><span class="fa fa-instagram"></span></a></li>
                        <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="col-lg-6 col-xl-7 col-xxl-8">
               <div class="row">
                  <div class="col-md-6 col-xl-4 col-xxl-3 mb-4">
                     <div class="pxp-footer-section">
                        <h3>Helpful</h3>
                        <ul class="pxp-footer-list">
                           <li><a href="<?php echo base_url(); ?>">Home</a></li>
                           <li><a href="<?php echo base_url('privacy_policy'); ?>">Privacy Policy</a></li>
                           <li><a href="<?php echo base_url('terms_and_conditions'); ?>">Terms & Conditions</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-md-6 col-xl-4 col-xxl-3 mb-4">
                     <div class="pxp-footer-section">
                        <h3>For Discover</h3>
                        <ul class="pxp-footer-list">
                           <li><a href="<?php echo base_url('login'); ?>">Login</a></li>
                           <li><a href="<?php echo base_url('register'); ?>">Register</a></li>
                           <li><a href="<?php echo base_url('discover'); ?>">Discover</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-md-6 col-xl-4 col-xxl-3 mb-4">
                     <div class="pxp-footer-section">
                        <h3>About Us</h3>
                        <ul class="pxp-footer-list">
                           <li><a href="<?php echo base_url('about_us'); ?>">About Us</a></li>
                           <li><a href="<?php echo base_url('faqs'); ?>">FAQs</a></li>
                           <li><a href="<?php echo base_url('contact_us'); ?>">Contact Us</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="pxp-main-footer-bottom" style="background-color: #000000;color: white;">
      <div class="pxp-container">
         <div class="justify-content-between align-items-center">
            <div class="text-center">
               <div class="pxp-footer-copyright pxp-text-light">© 2023 education.cv All Right Reserved.</div>
            </div>
         </div>
      </div>
   </div>
</footer>
<script src="<?php echo WEBASSETS; ?>js/jquery-3.4.1.min.js"></script>
<script src="<?php echo WEBASSETS; ?>js/bootstrap.bundle.min.js"></script>
<script src="<?php echo WEBASSETS; ?>js/owl.carousel.min.js"></script>
<script src="<?php echo WEBASSETS; ?>js/nav.js"></script>
<script src="<?php echo WEBASSETS; ?>js/main.js"></script>
</body>
<script type="text/javascript">
   // JavaScript to handle cookie consent
   $(document).ready(function () {
       const cookieConsent = $('#cookieConsent');
   
       // Check if the user has previously accepted cookies
       if (document.cookie.indexOf('cookieConsent=accepted') === -1) {
           cookieConsent.show();
       }
   
       // Handle the accept button click
       $('.accept').on('click', function () {
           // Set a cookie to remember the user's choice
           document.cookie = 'cookieConsent=accepted; expires=365; path=/';
   
           // Hide the pop-up
           cookieConsent.hide();
       });
   
       // Handle the reject button click
       $('.reject').on('click', function () {
           // Set a cookie to remember the user's choice (in this example, rejected cookies)
           document.cookie = 'cookieConsent=rejected; expires=365; path=/';
   
           // Hide the pop-up
           cookieConsent.hide();
       });
   });
</script>
</html>