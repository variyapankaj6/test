<div class="pxp-dashboard-content-details">
   <h2>Comments</h2>
   <div class="mt-4 mt-lg-5">
      <div class="table-responsive">
         <table id="Comments_table" class="table table-hover align-middle">
            <thead>
               <tr>
                  <th style="width: 25%;">Profile Name</th>
                  <th style="width: 40%;">Comment</th>
                  <th>Date</th>
               </tr>
            </thead>
         </table>
      </div>
   </div>
</div>
<script type="text/javascript">
  $(document).ready(function (e) {
      $(".m_comments").addClass('pxp-active');  
  });
</script>
<link  href="https://cdn.datatables.net/1.13.8/css/dataTables.bootstrap5.min.css" rel="stylesheet" type="text/css">
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script> 
<script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
   $('#Comments_table').DataTable({
        "responsive": true,
        "pagingType": "full_numbers",
        "processing": true,
        "serverSide": true,
        "order": [],
        "ajax": {
          "url": "<?php echo base_url('comments/getLists'); ?>",
          "type": "POST",
        },
        "columnDefs": [{ 
          "targets": [0],
          "orderable": false
        }]
      });
  });
</script>
