<section class="pxp-hero vh-100" style="background-color: var(--pxpMainColorLight);">
   <div class="pxp-hero-caption">
      <div class="pxp-container">
         <div class="row pxp-pl-80 align-items-center justify-content-between">
            <div class="col-12 col-xl-6 col-xxl-5">
               <h1>Building Bright Futures,<br><span style="color: var(--pxpMainColor);"><small>One CV Click Away</small></span></h1>
               <div class="pxp-hero-subtitle mt-3 mt-lg-4">Search more than <strong>100K+</strong> Curriculum vitae</div>
               <div class="pxp-info-caption-cta mb-3">
                  <a href="jobs-list-1.html" class="btn rounded-pill pxp-section-cta">Get Started Now<span class="fa fa-angle-right"></span></a>
               </div>
            </div>
            <div class="col-xl-5 position-relative">
               <!-- d-none d-xl-block  -->
               <div class="pxp-header-side-image pxp-has-animation">
                  <img src="<?php echo WEBASSETS; ?>images/hero-illustration.png" alt="Find the perfect job for you">
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<section class="mt-100">
   <div class="pxp-container">
      <div class="row justify-content-between align-items-center mt-4 mt-md-5">
         <div class="col-lg-6 col-xxl-5">
            <div class="pxp-info-fig pxp-animate-in pxp-animate-in-right">
               <div class="pxp-info-fig-image pxp-cover" style="background-image: url(<?php echo WEBASSETS; ?>images/info-section-image.jpg);"></div>
            </div>
         </div>
         <div class="col-lg-5 col-xxl-6">
            <div class="pxp-info-caption pxp-animate-in pxp-animate-in-top mt-4 mt-sm-5 mt-lg-0">
               <h2 class="pxp-section-h2">Empowering Minds, Shaping Futures:<br>Your Education CV Solution.</h2>
               <p class="pxp-text-light">Create a professional education-focused CV with our user-friendly online CV maker website. Choose from a range of templates, input your educational qualifications, and customize your CV to showcase your academic achievements effectively. Impress potential employers and educational institutions with a polished and well-organized CV. Start building your educational CV today!</p>
               <!-- <div class="pxp-info-caption-cta">
                  <a href="jobs-list-1.html" class="btn rounded-pill pxp-section-cta">Get Started Now<span class="fa fa-angle-right"></span></a>
                  </div> -->
            </div>
         </div>
      </div>
   </div>
</section>
<section class="mt-100">
   <div class="pxp-container">
      <div class="row justify-content-between align-items-center mt-4 mt-md-5">
         <div class="col-lg-5 col-xxl-6">
            <div class="pxp-info-caption pxp-animate-in pxp-animate-in-top mt-4 mt-sm-5 mt-lg-0">
               <h2 class="pxp-section-h2">Empowering Minds, Shaping Futures:<br>Your Education CV Solution.</h2>
               <p class="pxp-text-light">Create a professional education-focused CV with our user-friendly online CV maker website. Choose from a range of templates, input your educational qualifications, and customize your CV to showcase your academic achievements effectively. Impress potential employers and educational institutions with a polished and well-organized CV. Start building your educational CV today!</p>
               <!-- <div class="pxp-info-caption-cta">
                  <a href="jobs-list-1.html" class="btn rounded-pill pxp-section-cta">Get Started Now<span class="fa fa-angle-right"></span></a>
                  </div> -->
            </div>
         </div>
         <div class="col-lg-6 col-xxl-5">
            <div class="pxp-info-fig pxp-animate-in pxp-animate-in-right">
               <div class="pxp-info-fig-image pxp-cover" style="background-image: url(<?php echo WEBASSETS; ?>images/info-section-image.jpg);"></div>
            </div>
         </div>
      </div>
   </div>
</section>
<section class="mt-100">
   <div class="pxp-container">
      <div class="row justify-content-between align-items-center mt-4 mt-md-5">
         <div class="col-lg-6 col-xxl-5">
            <div class="pxp-info-fig pxp-animate-in pxp-animate-in-right">
               <div class="pxp-info-fig-image pxp-cover" style="background-image: url(<?php echo WEBASSETS; ?>images/info-section-image.jpg);"></div>
            </div>
         </div>
         <div class="col-lg-5 col-xxl-6">
            <div class="pxp-info-caption pxp-animate-in pxp-animate-in-top mt-4 mt-sm-5 mt-lg-0">
               <h2 class="pxp-section-h2">Empowering Minds, Shaping Futures:<br>Your Education CV Solution.</h2>
               <p class="pxp-text-light">Create a professional education-focused CV with our user-friendly online CV maker website. Choose from a range of templates, input your educational qualifications, and customize your CV to showcase your academic achievements effectively. Impress potential employers and educational institutions with a polished and well-organized CV. Start building your educational CV today!</p>
               <!-- <div class="pxp-info-caption-cta">
                  <a href="jobs-list-1.html" class="btn rounded-pill pxp-section-cta">Get Started Now<span class="fa fa-angle-right"></span></a>
                  </div> -->
            </div>
         </div>
      </div>
   </div>
</section>
<section class="mt-100 pb-100">
   <div class="pxp-container">
      <h2 class="pxp-section-h2">Top Profiles</h2>
      <p class="pxp-text-light">Exploring Excellence: Meet the Top Profiles </p>
      <div class="row mt-4 mt-md-5 pxp-animate-in pxp-animate-in-top">
         <?php foreach ($top_profiles as $key => $value) { 
            if($value['photo'])
            {
               $image = IMAGE."user/".$value['photo'];
            }else{
               $image = NO_USER;
            } 
            $course = $this->qm->num_row('tbl_education_traning',array('register_id' => $value['_id']));
         ?>
         <div class="col-12 col-md-4 col-lg-3 col-xxl-2 pxp-cities-card-1-container">
            <a href="<?php echo base_url('discover/view/').$value['_id']; ?>" class="pxp-cities-card-1 text-center">
               <div class="pxp-cities-card-1-top">
                  <div class="pxp-cities-card-1-image pxp-cover" style="background-image: url(<?php echo $image; ?>);"></div>
                  <div class="pxp-cities-card-1-name"><?php echo $value['name']; ?></div>
               </div>
               <div class="pxp-cities-card-1-bottom">
                  <div class="pxp-cities-card-1-jobs"><?php echo $value['profession']; ?></div>
                  <div class="pxp-candiadates-card-1-location"><span class="fa fa-globe"></span><?php echo $value['location']; ?></div>
               </div>
            </a>
         </div>
         <?php } ?>
      </div>
   </div>
</section>