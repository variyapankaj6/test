<!doctype html>
<html lang="en" class="pxp-root">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="shortcut icon" href="<?php echo WEBASSETS; ?>images/favicon.png" type="image/x-icon">
      <link rel="preconnect" href="https://fonts.googleapis.com/">
      <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600;700&amp;display=swap" rel="stylesheet">
      <link href="<?php echo WEBASSETS; ?>css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="<?php echo WEBASSETS; ?>css/font-awesome.min.css">
      <link rel="stylesheet" href="<?php echo WEBASSETS; ?>css/owl.carousel.min.css">
      <link rel="stylesheet" href="<?php echo WEBASSETS; ?>css/owl.theme.default.min.css">
      <link rel="stylesheet" href="<?php echo WEBASSETS; ?>css/animate.css">
      <link rel="stylesheet" href="<?php echo WEBASSETS; ?>css/style.css">
      <title>education.cv</title>
   </head>
   <style>
      .nav-pills .nav-link.active, .nav-pills .show>.nav-link {
         background-color: #002745;
      }
   </style>
   <script src="<?php echo WEBASSETS; ?>js/jquery-3.4.1.min.js"></script>
   <?php 
   $register = $this->qm->select_where('tbl_register',array('_id' => $this->session->userdata('educationcv_web_id')));
   if($register[0]['photo'])
   {
      $image = IMAGE."user/".$register[0]['photo'];
   }else{
      $image = NO_USER;
   }
   ?>
   <body style="background-color: var(--pxpMainColorLight);">
      <div class="pxp-preloader"><span>Loading...</span></div>
      <div class="pxp-dashboard-side-panel d-none d-lg-block">
         <div class="pxp-logo">
            <a href="<?php echo base_url(); ?>" class="pxp-animate"><span style="color: var(--pxpMainColor)">education</span>.cv</a>
         </div>
         <nav class="mt-3 mt-lg-4 d-flex justify-content-between flex-column pb-100">
            <ul class="list-unstyled">
               <li class="m_dashboard"><a href="<?php echo base_url('dashboard'); ?>"><span class="fa fa-home"></span>Dashboard</a></li>
               <li class="m_profile"><a href="<?php echo base_url('profile'); ?>"><span class="fa fa-pencil"></span>Edit Profile</a></li>
               <li class="m_changepassword"><a href="<?php echo base_url('changepassword'); ?>"><span class="fa fa-lock"></span>Change Password</a></li>
               <!-- <li class="m_comments"><a href="<?php echo base_url('delete_account'); ?>"><span class="fa fa-trash"></span>Delete Account</a></li> -->
            </ul>
         </nav>
         <!-- <nav class="pxp-dashboard-side-user-nav-container pxp-is-candidate">
            <div class="pxp-dashboard-side-user-nav">
               <div class="dropdown pxp-dashboard-side-user-nav-dropdown dropup">
                  <a role="button" class="dropdown-toggle" data-bs-toggle="dropdown">
                     <div class="pxp-dashboard-side-user-nav-avatar pxp-cover" style="background-image: url(<?php echo $image; ?>);"></div>
                     <div class="pxp-dashboard-side-user-nav-name"><?php echo $register[0]['name']; ?></div>
                  </a>
                  <ul class="dropdown-menu">
                     <li><a class="dropdown-item" href="<?php echo base_url('profile'); ?>">Dashboard</a></li>
                     <li><a class="dropdown-item" href="<?php echo base_url('login/logout'); ?>">Logout</a></li>
                  </ul>
               </div>
            </div>
         </nav> -->
      </div>
      <div class="pxp-dashboard-content">
      <div class="pxp-dashboard-content-header pxp-is-candidate">
         <div class="pxp-nav-trigger navbar pxp-is-dashboard d-lg-none">
            <a role="button" data-bs-toggle="offcanvas" data-bs-target="#pxpMobileNav" aria-controls="pxpMobileNav">
               <div class="pxp-line-1"></div>
               <div class="pxp-line-2"></div>
               <div class="pxp-line-3"></div>
            </a>
            <div class="offcanvas offcanvas-start pxp-nav-mobile-container pxp-is-dashboard pxp-is-candidate" tabindex="-1" id="pxpMobileNav">
               <div class="offcanvas-header">
                  <div class="pxp-logo">
                     <a href="<?php echo base_url(); ?>" class="pxp-animate"><span style="color: var(--pxpMainColor)">education</span>.cv</a>
                  </div>
                  <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
               </div>
               <div class="offcanvas-body">
                  <nav class="pxp-nav-mobile">
                     <ul class="navbar-nav justify-content-end flex-grow-1">
                        <li class="nav-item"><a href="<?php echo base_url('dashboard'); ?>"><span class="fa fa-home"></span>Dashboard</a></li>
                        <li class="nav-item"><a href="<?php echo base_url('profile'); ?>"><span class="fa fa-pencil"></span>Edit Profile</a></li>
                        <li class="nav-item"><a href="<?php echo base_url('changepassword'); ?>"><span class="fa fa-lock"></span>Change Password</a></li>
                        <!-- <li class="nav-item"><a href="<?php echo base_url('delete_account'); ?>"><span class="fa fa-trash"></span>Delete Account</a></li> -->
                     </ul>
                  </nav>
               </div>
            </div>
         </div>
         <nav class="pxp-user-nav pxp-on-light">
            <div class="dropdown pxp-user-nav-dropdown">
               <a role="button" class="dropdown-toggle" data-bs-toggle="dropdown">
                  <div class="pxp-user-nav-avatar pxp-cover" style="background-image: url(<?php echo $image; ?>);"></div>
                  <div class="pxp-user-nav-name d-none d-md-block"><?php echo $register[0]['name']; ?></div>
               </a>
               <ul class="dropdown-menu dropdown-menu-end">
                  <li><a class="dropdown-item" href="<?php echo base_url('profile'); ?>">Dashboard</a></li>
                  <li><a class="dropdown-item" href="<?php echo base_url('login/logout'); ?>">Logout</a></li>
               </ul>
            </div>
         </nav>
      </div>