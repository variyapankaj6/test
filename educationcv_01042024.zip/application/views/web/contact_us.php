<style type="text/css">
   .alert p{
      margin-bottom: 0px;
   }
   .alert{
      padding: 0.5rem 0.5rem;
   }
</style>
<section class="mt-100 pb-100 pxp-no-hero">
   <div class="pxp-container">
      <div class="row mt-100 justify-content-center pxp-animate-in pxp-animate-in-top">
         <div class="col-lg-6 col-xxl-4">
            <div class="pxp-contact-us-form pxp-has-animation pxp-animate">
               <h2 class="pxp-section-h2 text-center">Contact Us</h2>
               <?php if ($this->session->flashdata('error')) { ?>
                  <div class="alert alert-danger">
                      <?php echo $this->session->flashdata('error'); ?>
                  </div>
               <?php } ?>
               <?php if ($this->session->flashdata('success')) { ?>
                  <div class="alert alert-success">
                      <?php echo $this->session->flashdata('success'); ?>
                  </div>
               <?php } ?>
               <form class="mt-4" method="post" autocomplete="off">
                  <div class="mb-3">
                     <label for="name" class="form-label">Name</label>
                     <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name" value="<?php if($this->session->flashdata('errorpost')){ echo $this->session->flashdata('errorpost')['name']; } ?>" required>
                  </div>
                  <div class="mb-3">
                     <label for="email_id" class="form-label">Email</label>
                     <input type="email" class="form-control" id="email_id" name="email_id" placeholder="Enter your email address" value="<?php if($this->session->flashdata('errorpost')){ echo $this->session->flashdata('errorpost')['email_id']; } ?>" required>
                  </div>
                  <div class="mb-3">
                     <label for="subject" class="form-label">Subject</label>
                     <input type="text" class="form-control" id="subject" name="subject" placeholder="Enter your Subject" value="<?php if($this->session->flashdata('errorpost')){ echo $this->session->flashdata('errorpost')['subject']; } ?>" required>
                  </div>
                  <div class="mb-3">
                     <label for="message" class="form-label">Message</label>
                     <textarea class="form-control" id="message" name="message" placeholder="Type your message here..."><?php if($this->session->flashdata('errorpost')){ echo $this->session->flashdata('errorpost')['message']; } ?></textarea>
                  </div>
                  <div class="d-grid gap-2">
                     <button type="submit" name="submit" class="btn btn-block rounded-pill pxp-sign-hero-form-cta">Send Message</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</section>