<div class="pxp-dashboard-content-details">
   <ul class="nav nav-pills nav-fill nav-tabs">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('profile'); ?>">Edit Profile</a>
      </li>
      <li class="nav-item">
         <a class="nav-link" href="<?php echo base_url('profile/education_experience'); ?>">Education Experience</a>
      </li>
      <li class="nav-item">
         <a class="nav-link" href="<?php echo base_url('profile/education_training'); ?>">Education & Training</a>
      </li>
      <li class="nav-item">
         <a class="nav-link active" aria-current="page" href="<?php echo base_url('profile/graduate_certificate'); ?>">Graduate Certificate</a>
      </li>
      <li class="nav-item">
         <a class="nav-link" href="<?php echo base_url('profile/programs_websites'); ?>">Programs & Websites</a>
      </li>
   </ul>
   <form method="post" autocomplete="off" enctype="multipart/form-data">
      <div class="mt-4">
         <?php if ($this->session->flashdata('error')) { ?>
            <div class="alert alert-danger">
                <?php echo $this->session->flashdata('error'); ?>
            </div>
         <?php } ?>
         <?php if ($this->session->flashdata('success')) { ?>
            <div class="alert alert-success">
                <?php echo $this->session->flashdata('success'); ?>
            </div>
         <?php } ?>
         <div class="table-responsive">
            <table class="table align-middle">
               <?php foreach ($graduate_certificate as $key => $value) { ?>
               <tr>
                  <td style="width: 30%;">
                     <div class="pxp-candidate-dashboard-experience-title"><?php echo $value['name']; ?></div>
                  </td>
                  <td style="width: 25%;">
                     <div class="pxp-candidate-dashboard-experience-school"><?php echo $value['course_name']; ?></div>
                  </td>
                  <td style="width: 25%;">
                     <div class="pxp-candidate-dashboard-experience-time"><span class="fa fa-globe"></span> <?php echo $value['location']; ?></div>
                  </td>
                  <td>
                     <div class="pxp-dashboard-table-options">
                        <ul class="list-unstyled">
                           <li><button type="button" title="Edit"><a href="<?php echo base_url('profile/graduate_certificate/').$value['_id']; ?>"><span class="fa fa-pencil"></span></a></button></li>
                           <li><button type="button" title="Delete"><a onclick="return confirm('Are you sure want to delete?')" href="<?php echo base_url('profile/delete_graduate_certificate/').$value['_id']; ?>"><span class="fa fa-trash-o"></span></a></button></li>
                        </ul>
                     </div>
                  </td>
               </tr>
               <?php } ?>
            </table>
         </div>
         <div class="row mt-3 mt-lg-4">
            <div class="col-md-4">
               <div class="mb-3">
                  <label for="name" class="form-label">Certificate Title</label>
                  <input type="text" value="<?php if(isset($graduate_certificate_update)){ echo $graduate_certificate_update[0]['name']; } ?>" name="name" id="name" class="form-control" placeholder="E.g. Architecure" required>
               </div>
            </div>
            <div class="col-md-4">
               <div class="mb-3">
                  <label for="course_name" class="form-label">Category</label>
                  <input type="text" value="<?php if(isset($graduate_certificate_update)){ echo $graduate_certificate_update[0]['course_name']; } ?>" name="course_name" id="course_name" class="form-control" placeholder="Category name" required>
               </div>
            </div>
            <div class="col-md-4">
               <div class="mb-3">
                  <label for="location" class="form-label">Location</label>
                  <input type="text" value="<?php if(isset($graduate_certificate_update)){ echo $graduate_certificate_update[0]['location']; } ?>" name="location" id="location" class="form-control" placeholder="Location" required>
               </div>
            </div>
         </div>
         <div class="mb-3">
            <label for="pxp-candidate-edu-about" class="form-label">Certificate File</label>
            <input class="form-control" onchange="image_readURL(this);" accept="image/*" name="file" accept="" type="file" <?php if (!isset($graduate_certificate_update)) { echo "required"; } ?>>
         </div>
         <div class="mb-3">
            <?php if (!isset($graduate_certificate_update)) { ?>
            <img id="image" src="<?php echo NO_IMAGE;?>" alt="" height="160" width="160" />
            <?php } else { ?>
            <img src="<?php echo IMAGE."certificate/".$graduate_certificate_update[0]['file'];?>" alt="" height="160" width="160" id="image"/>
            <?php } ?>                        
         </div>
         <button name="submit" class="btn rounded-pill pxp-subsection-cta"><?php if(isset($graduate_certificate_update)){ echo 'Update'; }else{ echo 'Add'; } ?> Graduate Certificate</button>
      </div>
   </form>
</div>
<script type="text/javascript">
  $(document).ready(function (e) {
      $(".m_profile").addClass('pxp-active');  
  });
</script>
<script>
   function image_readURL(input) {
     if (input.files && input.files[0]){
      var reader = new FileReader();
      reader.onload = function(e) {
       $('#image').attr('src', e.target.result);
     }
     reader.readAsDataURL(input.files[0]);
   }}
</script>