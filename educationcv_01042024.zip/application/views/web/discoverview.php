<style type="text/css">
   .social-icon-container {
   width: 50px; /* Set your desired width here */
   height: 50px; /* Set your desired height here */
   border-radius: 50%;
   display: flex;
   justify-content: center;
   align-items: center;
   background: #bad5eea3 !important;
   }
</style>
<section class="mt-100">
   <div class="pxp-container">
      <div class="pxp-single-candidate-container pxp-has-columns">
         <div class="row">
            <div class="col-lg-5 col-xl-4 col-xxl-3 mt-4">
               <div class="pxp-single-candidate-side-panel mt-lg-0" style="background-color: var(--pxpMainColorLight);">
                  <div class="pxp-single-candidate-hero-content">
                     <div class="pxp-single-candidate-hero-avatar" style="background-image: url(<?php echo $image; ?>);"></div>
                     <div class="pxp-single-candidate-hero-name">
                        <h1><?php echo $register_details[0]['name']; ?></h1>
                        <div class="pxp-single-candidate-hero-title"><?php echo $register_details[0]['profession']; ?></div>
                     </div>
                  </div>
                  <div class="row mt-4 align-items-center">
                     <div class="col-6">
                        <div class="pxp-dashboard-stats-card bg-primary bg-opacity-10 p-3">
                           <div class="pxp-dashboard-stats-card-info">
                              <h3><?php echo $register_details[0]['followers']; ?></h3>
                              <div class="pxp-dashboard-stats-card-info-text pxp-text-light">Followers</div>
                           </div>
                        </div>
                     </div>
                     <div class="col-6">
                        <div class="pxp-dashboard-stats-card bg-success bg-opacity-10 p-3">
                           <div class="pxp-dashboard-stats-card-info">
                              <h3><?php echo $register_details[0]['following']; ?></h3>
                              <div class="pxp-dashboard-stats-card-info-text pxp-text-light">Following</div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="mt-4">
                     <div class="pxp-single-candidate-side-info-label pxp-text-light">Location</div>
                     <div class="pxp-single-candidate-side-info-data"><?php echo $register_details[0]['location']; ?></div>
                  </div>
                  <div class="mt-4">
                     <div class="pxp-single-candidate-side-info-label pxp-text-light">Websites</div>
                     <div class="pxp-single-company-side-info-data"><small><a href="https://twitter.com/">https://twitter.com</a></small></div>
                     <div class="pxp-single-candidate-side-info-data"><small><a href="https://www.google.com/">https://www.google.com</a></small></div>
                  </div>
                  <div class="mt-4">
                     <a href="#" class="btn rounded-pill pxp-card-btn">Follow</a>
                  </div>
               </div>
               <?php if(!empty($social_media)){ ?>
               <div class="pxp-single-candidate-side-panel mt-4 mt-lg-4" style="background-color: var(--pxpMainColorLight);">
                  <h3>Follow me:</h3>
                  <div class="row mt-4">
                     <?php if(!empty($social_media[0]['faceboook_link'])){ ?>
                     <div class="col-3 mb-3">
                        <a href="<?php if(!empty($social_media)){ echo $social_media[0]['faceboook_link']; }else{ echo '#'; } ?>" class="social-icon-container bg-primary">
                           <i class="fa fa-facebook fa-2x text-black"></i>
                        </a>
                     </div>
                     <?php } ?>
                     <?php if(!empty($social_media[0]['twitter_link'])){ ?>
                     <div class="col-3 mb-3">
                        <a href="<?php if(!empty($social_media)){ echo $social_media[0]['twitter_link']; }else{ echo '#'; } ?>" class="social-icon-container bg-primary text-white">
                           <img src="<?php echo WEBASSETS; ?>images/X.svg" style="width: 2.5rem;">
                        </a>
                     </div>
                     <?php } ?>
                     <?php if(!empty($social_media[0]['instagram_link'])){ ?>
                     <div class="col-3 mb-3">
                        <a href="<?php if(!empty($social_media)){ echo $social_media[0]['instagram_link']; }else{ echo '#'; } ?>" class="social-icon-container bg-primary text-white">
                           <i class="fa fa-instagram fa-2x text-black"></i>
                        </a>
                     </div>
                     <?php } ?>
                     <?php if(!empty($social_media[0]['linkedin_link'])){ ?>
                     <div class="col-3 mb-3">
                        <a href="<?php if(!empty($social_media)){ echo $social_media[0]['linkedin_link']; }else{ echo '#'; } ?>" class="social-icon-container bg-primary text-white">
                           <i class="fa fa-linkedin fa-2x text-black"></i>
                        </a>
                     </div>
                     <?php } ?>
                     <?php if(!empty($social_media[0]['youtube_link'])){ ?>
                     <div class="col-3 mb-3">
                        <a href="<?php if(!empty($social_media)){ echo $social_media[0]['youtube_link']; }else{ echo '#'; } ?>" class="social-icon-container bg-primary text-white">
                           <i class="fa fa-youtube fa-2x text-black"></i>
                        </a>
                     </div>
                     <?php } ?>
                     <?php if(!empty($social_media[0]['pinterest_link'])){ ?>
                     <div class="col-3 mb-3">
                        <a href="<?php if(!empty($social_media)){ echo $social_media[0]['pinterest_link']; }else{ echo '#'; } ?>" class="social-icon-container bg-primary text-white">
                           <i class="fa fa-pinterest fa-2x text-black"></i>
                        </a>
                     </div>
                     <?php } ?>
                     <?php if(!empty($social_media[0]['snapchat_link'])){ ?>
                     <div class="col-3 mb-3">
                        <a href="<?php if(!empty($social_media)){ echo $social_media[0]['snapchat_link']; }else{ echo '#'; } ?>" class="social-icon-container bg-primary text-white">
                           <i class="fa fa-snapchat fa-2x text-black"></i>
                        </a>
                     </div>
                     <?php } ?>
                     <?php if(!empty($social_media[0]['whatsapp_link'])){ ?>
                     <div class="col-3 mb-3">
                        <a href="<?php if(!empty($social_media)){ echo $social_media[0]['whatsapp_link']; }else{ echo '#'; } ?>" class="social-icon-container bg-primary text-white">
                           <i class="fa fa-whatsapp fa-2x text-black"></i>
                        </a>
                     </div>
                     <?php } ?>
                     <?php if(!empty($social_media[0]['threads_link'])){ ?>
                     <div class="col-3 mb-3">
                        <a href="<?php if(!empty($social_media)){ echo $social_media[0]['threads_link']; }else{ echo '#'; } ?>" class="social-icon-container bg-primary text-white">
                           <img src="<?php echo WEBASSETS; ?>images/threads.png" style="width: 2.0rem;">
                        </a>
                     </div>
                     <?php } ?>
                     <?php if(!empty($social_media[0]['tiktok_link'])){ ?>
                     <div class="col-3 mb-3">
                        <a href="<?php if(!empty($social_media)){ echo $social_media[0]['tiktok_link']; }else{ echo '#'; } ?>" class="social-icon-container bg-primary text-white">
                           <img src="<?php echo WEBASSETS; ?>images/tiktok.svg" style="width: 2.1rem;">
                        </a>
                     </div>
                     <?php } ?>
                     <?php if(!empty($social_media[0]['others_link'])){ ?>
                     <div class="col-3 mb-3">
                        <a href="<?php if(!empty($social_media)){ echo $social_media[0]['others_link']; }else{ echo '#'; } ?>" class="social-icon-container bg-primary text-white">
                           <i class="fa fa-link fa-2x text-black"></i>
                        </a>
                     </div>
                  <?php } ?>
                  </div>
               </div>
               <?php } ?>
            </div>
            <div class="col-lg-7 col-xl-8 col-xxl-9">
               <section class="mt-4 mt-lg-4">
                  <div class="pxp-single-candidate-content">
                     <h2>About <?php echo $register_details[0]['name']; ?></h2>
                     <p><?php echo $register_details[0]['about_us']; ?></p>
                     <div class="mt-4 mt-lg-4">
                        <h2>Education Portfolio</h2>
                        <div class="row align-items-center">
                           <div class="col-sm-6 col-xxl-3">
                              <div class="pxp-dashboard-stats-card bg-primary bg-opacity-10 mb-3 mb-xxl-0">
                                 <div class="pxp-dashboard-stats-card-icon text-primary">
                                    <span class="fa fa-calendar"></span>
                                 </div>
                                 <div class="pxp-dashboard-stats-card-info">
                                    <div class="pxp-dashboard-stats-card-info-number"><?php echo $totalYears; ?></div>
                                    <div class="pxp-dashboard-stats-card-info-text pxp-text-light">Years spent</div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-sm-6 col-xxl-3">
                              <div class="pxp-dashboard-stats-card bg-primary bg-opacity-10 mb-3 mb-xxl-0">
                                 <div class="pxp-dashboard-stats-card-icon text-success">
                                    <span class="fa fa-usd"></span>
                                 </div>
                                 <div class="pxp-dashboard-stats-card-info">
                                    <div class="pxp-dashboard-stats-card-info-number"><?php echo $totalSpent; ?></div>
                                    <div class="pxp-dashboard-stats-card-info-text pxp-text-light">Money spent</div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="mt-4 mt-lg-4">
                        <h2>Education Experience</h2>
                        <div class="pxp-single-candidate-timeline">
                           <?php foreach ($education_exp as $key => $value) { ?>
                           <div class="pxp-single-candidate-timeline-item">
                              <div class="pxp-single-candidate-timeline-dot"></div>
                              <div class="pxp-single-candidate-timeline-info ms-3">
                                 <div class="pxp-single-candidate-timeline-time"><span class="me-3"><?php echo $value['start_year']; ?> - <?php echo $value['end_year']; ?></span> <span class="me-3">$<?php echo $value['spent']; ?> spent</span></div>
                                 <div class="pxp-single-candidate-timeline-position mt-2"><?php echo $value['name']; ?></div>
                                 <div class="pxp-single-candidate-timeline-company pxp-text-light"><?php echo $value['collage_name']; ?></div>
                                 <div class="pxp-single-candidate-timeline-about mt-2 pb-4"><?php echo $value['details']; ?></div>
                              </div>
                           </div>
                           <?php } ?>
                        </div>
                     </div>
                     <div class="mt-4 mt-lg-4">
                        <h2>Education & Training</h2>
                        <div class="pxp-single-candidate-timeline">
                           <?php foreach ($education_traning as $key => $value) { ?>
                           <div class="pxp-single-candidate-timeline-item">
                              <div class="pxp-single-candidate-timeline-dot"></div>
                              <div class="pxp-single-candidate-timeline-info ms-3">
                                 <div class="pxp-single-candidate-timeline-time"><span class="me-3"><?php echo $value['start_year']; ?> - <?php echo $value['end_year']; ?></span> <span class="me-3">$<?php echo $value['spent']; ?> spent</span></div>
                                 <div class="pxp-single-candidate-timeline-position mt-2"><?php echo $value['name']; ?></div>
                                 <div class="pxp-single-candidate-timeline-company pxp-text-light"><?php echo $value['collage_name']; ?></div>
                                 <div class="pxp-single-candidate-timeline-about mt-2 pb-4"><?php echo $value['details']; ?></div>
                              </div>
                           </div>
                           <?php } ?>
                        </div>
                     </div>
                     <div class="mt-4 mt-lg-4">
                        <h2> Graduate Certificate</h2>
                        <div class="pxp-single-candidate-skills">
                           <div class="table-responsive">
                              <table class="table align-middle">
                                 <tbody>
                                    <?php foreach ($graduate_certificate as $key => $value) { ?>
                                    <tr>
                                       <td style="width: 45%;">
                                          <div class="pxp-candidate-dashboard-job-title"><?php echo $value['name']; ?></div>
                                          <div class="pxp-candidate-dashboard-job-company"><?php echo $value['course_name']; ?></div>
                                       </td>
                                       <td style="width: 35%;">
                                          <div class="pxp-candidate-dashboard-job-location"><span class="fa fa-globe"></span><?php echo $value['location']; ?></div>
                                       </td>
                                       <td>
                                          <div class="pxp-dashboard-table-options">
                                             <ul class="list-unstyled">
                                                <li><button title="View job details"><a target="_blank" href="<?php echo IMAGE."certificate/".$value['file'];?>"><span class="fa fa-eye"></span></a></button></li>
                                             </ul>
                                          </div>
                                       </td>
                                    </tr>
                                    <?php } ?>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                     <div class="mt-4 mt-lg-4">
                        <h2>Non-award programs</h2>
                        <div class="pxp-single-candidate-skills">
                           <ul class="list-unstyled">
                              <?php foreach ($non_award_program as $key => $value) { ?>
                              <li><?php echo $value['name']; ?></li>
                              <?php } ?>
                           </ul>
                        </div>
                     </div>
                  </div>
               </section>
            </div>
         </div>
      </div>
   </div>
</section>
<section class="mt-100 pb-100">
   <div class="pxp-container">
      <div class="pxp-blog-comments-block">
         <div class="pxp-blog-post-comments" id="commentview">
            <h4><?php echo $comments_total; ?> Comments <small style="font-weight:300;">(Lattest 5 comments)</small></h4>
            <div class="mt-3 mt-lg-4">
               <ol class="pxp-comments-list">
                  <?php foreach ($comments as $key => $value) { ?>
                  <li class="mt-3 mt-lg-4">
                     <div class="pxp-comments-list-item">
                        <img src="<?php if($value['photo']){ echo IMAGE."user/".$value['photo']; }else{ echo NO_USER; } ?>" alt="<?php echo $value['name']; ?>">
                        <div class="pxp-comments-list-item-body">
                           <h5><?php echo $value['name']; ?></h5>
                           <div class="pxp-comments-list-item-date"><?php echo date('d F Y h:i A',strtotime($value['created_at'])); ?></div>
                           <div class="pxp-comments-list-item-content mt-2"><?php echo $value['message']; ?></div>
                        </div>
                     </div>
                  </li>
                  <?php } ?>
               </ol>
            </div>
            <div class="mt-3 mt-lg-4">
               <form method="post" class="pxp-comments-form" autocomplete="off">
                  <?php if ($this->session->flashdata('error')) { ?>
                     <div class="alert alert-danger">
                         <?php echo $this->session->flashdata('error'); ?>
                     </div>
                  <?php } ?>
                  <?php if ($this->session->flashdata('success')) { ?>
                     <div class="alert alert-success">
                         <?php echo $this->session->flashdata('success'); ?>
                     </div>
                  <?php } ?>
                  <div class="mt-3 mt-lg- mb-3">
                     <label for="comment" class="form-label">Comment</label>
                     <textarea class="form-control" id="comment" name="comment" placeholder="Type your comment here..." required></textarea>
                  </div>
                  <button type="submit" name="submit" class="btn rounded-pill pxp-section-cta">Post Comment</button>
               </form>
            </div>
         </div>
      </div>
   </div>
</section>