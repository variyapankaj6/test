<section class="pxp-page-header-simple" style="background-color: var(--pxpMainColorLight);">
	<div class="pxp-container">
		<h1>Search Profiles</h1>
		<!-- <div class="pxp-hero-subtitle pxp-text-light">Work with the most talented Profiles in the world</div> -->
		<div class="pxp-hero-form pxp-hero-form-round pxp-large mt-3 mt-lg-4">
			<form class="row gx-3 align-items-center" method="get" autocomplete="off">
				<div class="col-12 col-lg">
					<div class="input-group mb-3 mb-lg-0">
						<span class="input-group-text"><span class="fa fa-search"></span></span>
						<input type="text" class="form-control" name="search" placeholder="Profiles Name or Keyword" value="<?php echo $fil_search; ?>">
					</div>
				</div>
				<div class="col-12 col-lg pxp-has-left-border">
					<div class="input-group mb-3 mb-lg-0">
						<span class="input-group-text"><span class="fa fa-globe"></span></span>
						<input type="text" name="location" class="form-control" placeholder="Location" value="<?php echo $fil_location; ?>">
					</div>
				</div>
				<div class="col-12 col-lg-auto">
					<button type="submit">Find Profile</button>
				</div>
			</form>
		</div>
	</div>
</section>
<section class="mt-100 pb-100">
	<div class="pxp-container">
		<div class="pxp-candidates-list-top">
			<div class="row justify-content-between align-items-center">
				<div class="col-auto">
					<h2><span class="pxp-text-light">Showing</span> <?php echo $total_items; ?> <span class="pxp-text-light">Profiles</span></h2>
				</div>
				<div class="col-auto">
					<select class="form-select">
						<option value="0" selected>Most relevant</option>
						<option value="1">Name Asc</option>
						<option value="2">Name Desc</option>
					</select>
				</div>
			</div>
		</div>
		<div class="row">
			<?php if(empty($discoverlist)){ ?>
	            <div class="col-md-12 text-center pt-5 pb-5">
	               <h2 class="pt-5 pb-5" style="font-weight:400;">Data not found.</h2>
	            </div>
	        <?php } ?>
	        <?php 
            foreach ($discoverlist as $val => $key) {
               if($key->photo)
               {
                  $image = IMAGE."user/".$key->photo;
               }else{
                  $image = NO_USER;
               } 
               $course = $this->qm->num_row('tbl_education_traning',array('register_id' => $key->_id));
            ?>
			<div class="col-md-6 col-xl-3 col-xxl-3 pxp-candiadates-card-1-container">
				<div class="pxp-candiadates-card-1 pxp-has-border text-center">
					<div class="pxp-candiadates-card-1-top">
						<div class="pxp-candiadates-card-1-avatar pxp-cover" style="background-image: url(<?php echo $image; ?>);"></div>
						<div class="pxp-candiadates-card-1-name"><?php echo $key->name; ?></div>
						<div class="pxp-candiadates-card-1-title"><?php echo $key->profession; ?></div>
						<div class="pxp-candiadates-card-1-title" style="display: flex;align-items: center;justify-content: space-between;flex-wrap: wrap;">
							<span style="background: #e6f0f9;padding: 6px;border-radius: 10px;"><i class="fa fa-graduation-cap"></i> <?php echo $course; ?> <small>Course</small></span> 
							<span style="background: #e6f0f9;padding: 6px;border-radius: 10px;"><i class="fa fa-users"></i> <?php echo $key->followers; ?> <small>Followers</small></span>
						</div>
						<div class="pxp-candiadates-card-1-location"><span class="fa fa-globe"></span> <?php echo $key->location; ?></div>
					</div>
					<div class="pxp-candiadates-card-1-bottom">
						<div class="pxp-candiadates-card-1-cta">
							<a href="<?php echo base_url('discover/view/').$key->_id; ?>">View profile<span class="fa fa-angle-right"></span></a>
						</div>
					</div>
				</div>
			</div>
         	<?php } ?>
		</div>
		<div class="row mt-4 mt-lg-5 justify-content-between align-items-center">
			<div class="col-auto">
				<nav class="mt-3 mt-sm-0" aria-label="Candidates pagination">
					<ul class="pagination pxp-pagination">
						<?php echo $links; ?>
					</ul>
				</nav>
			</div>
		</div>
	</div>
</section>