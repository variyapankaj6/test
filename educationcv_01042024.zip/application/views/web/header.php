<!DOCTYPE html>
<html lang="en" class="pxp-root">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>education.cv</title>
      <meta name="title" content="education.cv">
      <meta name="author" content="education.cv">
      <meta name="keywords" content="education.cv">
      <meta name="description" content="education.cv">
      <link rel="shortcut icon" href="<?php echo MAINLOGO; ?>" type="image/x-icon">
      <link rel="icon" href="<?php echo MAINLOGO; ?>" type="image/x-icon">
      <!-- Open Graph / Facebook -->
      <meta property="og:type" content="website">
      <meta property="og:url" content="<?php echo base_url(); ?>">
      <meta property="og:title" content="education.cv">
      <meta property="og:description" content="education.cv">
      <meta property="og:image" content="<?php echo MAINLOGO; ?>">
      <!-- Twitter -->
      <meta property="twitter:card" content="summary_large_image">
      <meta property="twitter:url" content="<?php echo base_url(); ?>">
      <meta property="twitter:title" content="education.cv">
      <meta property="twitter:description" content="education.cv">
      <meta property="twitter:image" content="<?php echo MAINLOGO; ?>">
      <link rel="preconnect" href="https://fonts.googleapis.com/">
      <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600;700&amp;display=swap" rel="stylesheet">
      <link href="<?php echo WEBASSETS; ?>css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="<?php echo WEBASSETS; ?>css/font-awesome.min.css">
      <link rel="stylesheet" href="<?php echo WEBASSETS; ?>css/owl.carousel.min.css">
      <link rel="stylesheet" href="<?php echo WEBASSETS; ?>css/owl.theme.default.min.css">
      <link rel="stylesheet" href="<?php echo WEBASSETS; ?>css/animate.css">
      <link rel="stylesheet" href="<?php echo WEBASSETS; ?>css/style.css">
   </head>
   <style type="text/css">
      /* Add custom CSS styles for the cookie consent pop-up */
      #cookieConsent {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      padding: 10px;
      background-color: rgb(9 105 195 / 76%);
      color: #fff;
      z-index: 9999;
      }
      /* Center the accept and reject buttons */
      .accept,
      .reject {
      margin: 0 10px;
      }
      .pxp-cities-card-1-image {
         border-radius: 50%;
      }
   </style>
   <body>
      <div class="pxp-preloader"><span>Loading...</span></div>
      <!-- <div id="cookieConsent" class="alert alert-info alert-dismissible fade show text-center" role="alert">
         <strong>Cookies!</strong> This website uses cookies to ensure you get the best experience on our website.
         <button type="button" class="btn btn-success btn-sm accept" data-dismiss="alert">Accept</button>
         <button type="button" class="btn btn-danger btn-sm reject">Reject</button>
      </div> -->
      <header class="pxp-header fixed-top">
         <div class="pxp-container">
            <div class="pxp-header-container">
               <div class="pxp-logo">
                  <a href="<?php echo base_url(); ?>" class="pxp-animate">
                     <img src="<?php echo WEBASSETS; ?>images/logo.png" style="height:30px;" alt="Find the perfect job for you">
                     <!-- <span style="color: var(--pxpMainColor)">education</span>.cv -->
                  </a>
               </div>
               <div class="pxp-nav-trigger navbar d-xl-none flex-fill">
                  <a role="button" data-bs-toggle="offcanvas" data-bs-target="#pxpMobileNav" aria-controls="pxpMobileNav">
                     <div class="pxp-line-1"></div>
                     <div class="pxp-line-2"></div>
                     <div class="pxp-line-3"></div>
                  </a>
                  <div class="offcanvas offcanvas-start pxp-nav-mobile-container" tabindex="-1" id="pxpMobileNav">
                     <div class="offcanvas-header">
                        <div class="pxp-logo">
                           <a href="<?php echo base_url(); ?>" class="pxp-animate"><span style="color: var(--pxpMainColor)">education</span>.cv</a>
                        </div>
                        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                     </div>
                     <div class="offcanvas-body">
                        <nav class="pxp-nav-mobile">
                           <ul class="navbar-nav justify-content-end flex-grow-1">
                              <li class="nav-item"><a class="nav-link" href="<?php echo base_url(); ?>">Home</a></li>
                              <li class="nav-item"><a class="nav-link" href="<?php echo base_url('discover'); ?>">Discover</a></li>
                              <li class="nav-item"><a class="nav-link" href="<?php echo base_url('contact_us'); ?>">Contact Us</a></li>
                              <li class="nav-item"><a class="nav-link" href="<?php echo base_url('faqs'); ?>">FAQs</a></li>
                              <li class="nav-item"><a class="nav-link" href="<?php echo base_url('about_us'); ?>">About Us</a></li>
                              <li class="nav-item"><a class="nav-link" href="<?php echo base_url('login'); ?>">Login / Register</a></li>
                           </ul>
                        </nav>
                     </div>
                  </div>
               </div>
               <div class="pxp-header-right">
                  <nav class="pxp-nav dropdown-hover-all d-none d-xl-block">
                     <ul>
                        <li><a href="<?php echo base_url(); ?>">Home</a></li>
                        <li><a href="<?php echo base_url('discover'); ?>">Discover</a></li>
                        <li><a href="<?php echo base_url('contact_us'); ?>">Contact Us</a></li>
                        <li><a href="<?php echo base_url('faqs'); ?>">FAQs</a></li>
                        <li><a href="<?php echo base_url('about_us'); ?>">About Us</a></li>
                     </ul>
                  </nav>
                  <nav class="pxp-user-nav d-none d-sm-flex">
                     <?php if($this->session->userdata('educationcv_web_email') != "" && $this->session->userdata('educationcv_web_id') != ""){ ?>
                        <a href="<?php echo base_url('dashboard'); ?>" class="btn rounded-pill pxp-nav-btn">My Dashboard</a>
                     <?php }else{ ?>
                        <a href="<?php echo base_url('login'); ?>" class="btn rounded-pill pxp-nav-btn">Login / Register</a>
                     <?php } ?>
                  </nav>
               </div>
            </div>
         </div>
      </header>