<div class="pxp-dashboard-content-details">
   <h2>Change Password</h2>
   <p class="pxp-text-light">Choose a new account password.</p>
   <form>
      <div class="row mt-4 mt-lg-5">
         <div class="col-md-6">
            <div class="mb-3">
               <label for="pxp-candidate-old-password" class="form-label">Old password</label>
               <input type="password" id="pxp-candidate-old-password" class="form-control" placeholder="Enter old password">
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-md-6">
            <div class="mb-3">
               <label for="pxp-candidate-new-password" class="form-label">New password</label>
               <input type="password" id="pxp-candidate-new-password" class="form-control" placeholder="Enter new password">
            </div>
         </div>
         <div class="col-md-6">
            <div class="mb-3">
               <label for="pxp-candidate-new-password-repeat" class="form-label">New password repeat</label>
               <input type="password" id="pxp-candidate-new-password-repeat" class="form-control" placeholder="Repeat new password">
            </div>
         </div>
      </div>
      <div class="mt-4 mt-lg-5">
         <button class="btn rounded-pill pxp-section-cta">Save New Password</button>
      </div>
   </form>
</div>
<script type="text/javascript">
  $(document).ready(function (e) {
      $(".m_changepassword").addClass('pxp-active');  
  });
</script>