<!--  BEGIN CONTENT PART  -->
<div id="content" class="main-content">
  <div class="container">
    <div class="page-header">
      <div class="page-title">
        <h3>Dashboard</h3>
      </div>
    </div>

    <div class="row layout-spacing ">

      <div class="col-xl-3 mb-xl-0 col-lg-6 mb-4 col-md-6 col-sm-6">
        <div class="widget-content-area  data-widgets br-4" style="padding: 11px;box-shadow: 10px 10px 5px #aaaaaa;">
          <div class="widget t-sales-widget">
            <div class="media">
              <div class="icon ml-2">
                <i class="fa fa-users"></i>
              </div>
              <div class="media-body text-right">
                <p class="widget-text mb-0" ><a href="<?php echo base_url('sup_admin/registers'); ?>" style="color: #000000;">Registers</a></p>
                <p class="widget-numeric-value"><?php echo $register_total; ?></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-xl-3 mb-xl-0 col-lg-6 mb-4 col-md-6 col-sm-6">
        <div class="widget-content-area  data-widgets br-4" style="padding: 11px;box-shadow: 10px 10px 5px #aaaaaa;">
          <div class="widget t-sales-widget">
            <div class="media">
              <div class="icon ml-2">
                <i class="fa fa-users"></i>
              </div>
              <div class="media-body text-right">
                <p class="widget-text mb-0" ><a href="<?php echo base_url('sup_admin/contactus'); ?>" style="color: #000000;">ContactUs</a></p>
                <p class="widget-numeric-value"><?php echo $contactus_total; ?></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      

    </div>
  </div>
</div>
</div>
<!--  END CONTENT PART  -->
</div>
<!-- END MAIN CONTAINER -->       
<script type="text/javascript">
  $(document).ready(function (e) {
       $("#mmm_dashboard").attr("aria-expanded",'true');
       $("#mm_dashboard").addClass('show');
       $("#m_dashboard").addClass('active');  
  });
</script>