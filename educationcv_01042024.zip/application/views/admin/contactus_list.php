<div id="content" class="main-content">
   <div class="container">
      <div class="page-header">
         <div class="page-title">
            <h3>Contact Us List</h3>
            <div class="crumbs">
               <ul id="breadcrumbs" class="breadcrumb">
                  <li><a href="<?php echo base_url('sup_admin/dashboard');?>"><i class="flaticon-home-fill"></i></a></li>
                  <li class="active">Contact Us List</li>
               </ul>
            </div>
         </div>
      </div>
      <div class="row layout-spacing">
         <div class="col-lg-12 ">
            <div class="statbox widget box box-shadow">
               <div class="widget-content widget-content-area">
                  <div class="table-responsive mb-4">
                     <table id="contactus_table" class="table table-bordered table-hover" style="color:black;">
                        <thead>
                           <tr style="background: #d7ebf5;">
                              <th>S.no</th>
                              <th>Name</th>
                              <th>Email</th>
                              <th>Subject</th>
                              <th>Message</th>
                              <th>Date</th>
                              <th>Action</th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
            </form>
         </div>
      </div>
   </div>
</div>
<script src="<?php echo PLUGINS; ?>/table/datatable/datatables.js"></script> 
<script type="text/javascript">
   $(document).ready(function (e) {
    $("#mmm_contactus").attr("aria-expanded",'true');
    $("#mm_contactus").addClass('show');
    $("#m_contactus").addClass('active');  
   });
  
   function dlt_data(user_id) {
     if (confirm("Are You Sure you want to delete?")) {
      var xmlhttp;
      if (window.XMLHttpRequest){
       xmlhttp=new XMLHttpRequest();
     }else{
       xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
     }
     var url = "<?php echo base_url('sup_admin/contactus/delete'); ?>" + "/" +user_id;
     xmlhttp.open("GET",url,true);   
     xmlhttp.send();
     xmlhttp.onreadystatechange=function(){
       if (xmlhttp.readyState == 4 ){
        location.reload();
      }
    }
   }
   }
   
$(document).ready(function(){
   $('#contactus_table').DataTable({
   "pagingType": "full_numbers",
   "processing": true,
   "serverSide": true,
   "order": [],
   "ajax": {
     "url": "<?php echo base_url('sup_admin/contactus/getLists'); ?>",
     "type": "POST",
       "data":function(data) {
       }
     },
     "columnDefs": [{ 
       "targets": [0,6],
       "orderable": false
     }],
     "initComplete": function(settings, json) {
       $('[data-toggle="tooltip"]').tooltip();
     }
   });
});
</script>