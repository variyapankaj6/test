<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
      <title>Educationcv</title>
      <link rel="shortcut icon" href="<?php echo MAINLOGO; ?>" type="image/x-icon">
      <link rel="icon" href="<?php echo MAINLOGO; ?>" type="image/x-icon">
      <!-- BEGIN GLOBAL MANDATORY STYLES -->
      <link href="<?php echo CSS; ?>loader.css" rel="stylesheet" type="text/css" />
      <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Josefin+Sans" />
      <link href="<?php echo BCSS; ?>/bootstrap.min.css" rel="stylesheet" type="text/css" />
      <link href="<?php echo CSS; ?>plugins.css" rel="stylesheet" type="text/css" />
      <link href="https://cdnjs.cloudflare.com/ajax/libs/iCheck/1.0.2/skins/flat/_all.css" rel="stylesheet" type="text/css" />
      <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" >
      <!-- END GLOBAL MANDATORY STYLES -->
      <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
      <link href="<?php echo CSS; ?>support-chat.css" rel="stylesheet" type="text/css" />
      <link href="<?php echo PLUGINS; ?>/maps/vector/jvector/jquery-jvectormap-2.0.3.css" rel="stylesheet" type="text/css" />
      <link href="<?php echo PLUGINS; ?>/charts/chartist/chartist.css" rel="stylesheet" type="text/css">
      <link href="<?php echo CSS; ?>default-dashboard/style.css" rel="stylesheet" type="text/css" />
      <!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->   
      <link  href="<?php echo PLUGINS; ?>/table/datatable/datatables.css" rel="stylesheet" type="text/css">
      <link rel="stylesheet" type="text/css" href="<?php echo CSS; ?>ecommerce/view_customers.css">
      <script src="<?php echo JS; ?>libs/jquery-3.1.1.min.js"></script>
      <link rel="stylesheet" type="text/css" href="<?php echo PLUGINS; ?>/select2/select2.min.css">
      <link href="<?php echo PLUGINS; ?>/date_time_pickers/bootstrap_date_range_picker/daterangepicker.css" rel="stylesheet" type="text/css">
</head>
<style type="text/css">
.select2-container--default .select2-search--inline .select2-search__field {
   width: auto!important;
}
html *
{
   font-family: 'Inter','Helvetica Neue','Helvetica',sans-serif;
}
@media (min-width: 1281px) {   /* ##Device = Desktops*/
  #form7 .form-control { 
      width: 50% !important;
    }
}
@media (min-width: 1025px) and (max-width: 1280px) { /*##Device = Laptops, Desktops*/
 #form7 .form-control { 
      width: 50% !important;
    }
}
@media (min-width: 768px) and (max-width: 1024px) { /*##Device = Tablets, Ipads (portrait)*/
   #form7 .form-control { 
      width: 50% !important;
    }
}
@media (min-width: 768px) and (max-width: 1024px) and (orientation: landscape) { /*##Device = Tablets, Ipads (landscape)*/
  #form7 .form-control { 
      width: 50% !important;
    }
}
@media (min-width: 481px) and (max-width: 767px) { /*##Device = Low Resolution Tablets, Mobiles (Landscape)*/
  #form7 .form-control { 
      width: 100% !important;
    }
}
@media (min-width: 320px) and (max-width: 480px) {  /*##Device = Most of the Smartphones Mobiles (Portrait)*/
 #form7 .form-control { 
      width: 100% !important;
    }
}
.list-group-item b{
  color: #0d25c6;
}
/*.row {
   padding: 0 !important;
   margin: 0 !important;
}
#content>.container {
     padding: 0px !important;
}*/
.navbar .navbar-nav .nav-item.user-profile-dropdown .dropdown-menu {
    right: 0px;
}
#content>.container {
    padding: 0 12px;
}
@media (min-width: 320px) and (max-width: 480px) {  /*##Device = Most of the Smartphones Mobiles (Portrait)*/
   header.tabMobileView {
      height: 68px;
   }
   .showonlydesktop{
      display: none;
   }
   #content {
      margin-top: 66px;
   }
}
</style>
   <script>
      function validate() {
          var old_pswd = document.getElementById("old_pswd").value;
          var new_pswd = document.getElementById("new_pswd").value;
          var confirm_pswd = document.getElementById("confirm_pswd").value;
          if (new_pswd == confirm_pswd && new_pswd != "" && confirm_pswd != "") {
      
            $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('admin/change_pswd'); ?>",
                    data: {old_pswd:old_pswd,new_pswd:new_pswd},
                    success:function(response) {
                        if(response == 'Password is Successfully Changed.')
                        {
                            alert(response); 
                            location.reload(); 
                        }
                        else
                        {
                             alert(response); 
                        }   
                    }
                });
          } else {
              if (new_pswd == "" && confirm_pswd == "") {
                  alert("Plaese fill out all fields.");
                  $('#new_pswd').focus();
                  return false;
              } else {
                  alert("Your passwords are not matched.");
                  return false;
              }
          }
      }
   </script>
   <!--------------------------------------------------CHANGE PASSWORD ------------------------------------------------->
   <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="formInputModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title" id="formInputModalLabel">Change password</h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <div class="modal-body">
               <form role="form">
                  <div class="form-group">
                     <label for="password">Old Password:</label>
                     <input type="password" name="old_pswd" class="form-control" id="old_pswd" required>
                  </div>
                  <div class="form-group">
                     <label for="pwd">New Password:</label>
                     <input type="password" name="new_pswd" id="new_pswd" class="form-control" required>
                  </div>
                  <div class="form-group">
                     <label for="pwd">Confirm Password:</label>
                     <input type="password" class="form-control" id="confirm_pswd" required>
                  </div>
            </div>
            <div class="modal-footer">
            <button type="button" onClick="validate()" class="btn btn-primary btn-rounded mt-3 mb-3" id="submit_coolfacts">Save changes</button>
            <button type="button" class="btn btn-dark btn-rounded mt-3 mb-3" data-dismiss="modal">Close</button>
            </div>
            </form>
         </div>
      </div>
   </div>
   <!-- CHNAGE PASSWORD -->
   <div class="modal fade" id="imageshowpopup" tabindex="-1" role="dialog" aria-labelledby="basicModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-body p-0">
               <div id="imageshowdata" data-dismiss="modal" aria-label="Close">
                  <!-- <img class="d-block w-100" src="" alt="First slide"> -->
               </div>
            </div>
         </div>
      </div>
   </div>
   <body class="default-sidebar" style="background: #5465d740;">
      <div id="eq-loader">
         <div class="eq-loader-div">
            <div class="eq-loading dual-loader mx-auto mb-5"></div>
         </div>
      </div>
      <!-- Tab Mobile View Header -->
      <header class="tabMobileView header navbar fixed-top d-lg-none">
         <div class="nav-toggle">
            <a href="javascript:void(0);" class="nav-link sidebarCollapse" data-placement="bottom">
            <i class="flaticon-menu-line-2"></i>
            </a>
            <a href="<?php echo base_url('sup_admin/dashboard');?>" class="" style="color: #fff;"> <img src="<?php echo MAINLOGO; ?>" class="img-fluid" alt="logo" style="height: 45px;width: auto;"></a>
         </div>
         <ul class="navbar-nav flex-row ml-lg-auto">
            <li class="nav-item dropdown user-profile-dropdown ml-lg-0 mr-lg-2 ml-3 order-lg-0 order-1">
               <a href="javascript:void(0);" class="nav-link dropdown-toggle user" id="userProfileDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
               <span class="flaticon-user-12"></span>
               </a>
               <div class="dropdown-menu  position-absolute" aria-labelledby="userProfileDropdown">
                  <a class="dropdown-item" href="#" data-toggle="modal" data-target="#myModal">
                  <i class="mr-1 flaticon-calendar-bold"></i> <span>Change Password</span>
                  </a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="<?php echo base_url('admin/logout');?>">
                  <i class="mr-1 flaticon-power-button"></i> <span>Log Out</span>
                  </a>
               </div>
            </li>
         </ul>
      </header>
      <!-- Tab Mobile View Header -->
      <!--  BEGIN NAVBAR  -->
      <header class="header navbar fixed-top navbar-expand-sm showonlydesktop">
         <a href="javascript:void(0);" class="sidebarCollapse d-none d-lg-block" data-placement="bottom"><i class="flaticon-menu-line-2"></i></a>
         <ul class="navbar-nav flex-row ml-lg-auto">
            <li class="nav-item dropdown user-profile-dropdown ml-lg-0 mr-lg-2 ml-3 order-lg-0 order-1">
               <a href="javascript:void(0);" class="nav-link dropdown-toggle user" id="userProfileDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
               <span class="flaticon-user-12"></span>
               </a>
               <div class="dropdown-menu  position-absolute" aria-labelledby="userProfileDropdown">
                  <a class="dropdown-item" href="#" data-toggle="modal" data-target="#myModal">
                  <i class="mr-1 flaticon-calendar-bold"></i> <span>Change Password</span>
                  </a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="<?php echo base_url('admin/logout');?>">
                  <i class="mr-1 flaticon-power-button"></i> <span>Log Out</span>
                  </a>
               </div>
            </li>
         </ul>
      </header>
      <!--  END NAVBAR  -->
      <!--  BEGIN MAIN CONTAINER  -->
      <div class="main-container" id="container">
      <div class="overlay"></div>
      <div class="cs-overlay"></div>
      <!--  BEGIN SIDEBAR  -->
      <div class="sidebar-wrapper sidebar-theme">
         <div id="dismiss" class="d-lg-none"><i class="flaticon-cancel-12"></i></div>
         <nav id="sidebar">
            <ul class="navbar-nav theme-brand flex-row  d-none d-lg-flex">
               <li class="nav-item d-flex">
                  <a href="<?php echo base_url('sup_admin/dashboard'); ?>" class="navbar-brand" style="width: 100%;">
                      <img src="<?php echo MAINLOGO; ?>" class="img-fluid"  alt="logo" style="width: auto;height: 54px;">
                  </a>
               </li>
            </ul>
            <ul class="list-unstyled menu-categories" id="accordionExample">
             
               <li class="menu p-0 m-0">
                  <a href="<?php echo base_url('sup_admin/dashboard'); ?>" aria-expanded="false" class="dropdown-toggle collapsed" id="mmm_dashboard">
                     <div class="">
                        <i class="flaticon-computer-6"></i>
                        <span>Dashboard</span>
                     </div>
                  </a>
               </li>

               <li class="menu">
                  <a href="<?php echo base_url('sup_admin/registers'); ?>"  aria-expanded="false" class="dropdown-toggle collapsed" id="mmm_registers">
                     <div class="">
                        <i class="fa fa-users"></i>
                        <span>Manage Registers</span>
                     </div>
                  </a>
               </li>

               <li class="menu">
                  <a href="<?php echo base_url('sup_admin/contactus'); ?>"  aria-expanded="false" class="dropdown-toggle collapsed" id="mmm_contactus">
                     <div class="">
                        <i class="fa fa-users"></i>
                        <span>Contact Us</span>
                     </div>
                  </a>
               </li>

               <li class="menu">
                  <a href="<?php echo base_url('sup_admin/cms_pages'); ?>"  aria-expanded="false" class="dropdown-toggle collapsed" id="mmm_cms_pages">
                     <div class="">
                        <i class="fa fa-file"></i>
                        <span>CMS management</span>
                     </div>
                  </a>
               </li>
            </ul>
         </nav>
      </div>