<div id="content" class="main-content">
 <div class="container">
  <div class="page-header">
   <div class="page-title">
    <h3>CMS Pages List</h3>
    <div class="crumbs">
     <ul id="breadcrumbs" class="breadcrumb">
      <li><a href="<?php echo base_url('sup_admin/dashboard');?>"><i class="flaticon-home-fill"></i></a></li>
      <li class="active">CMS Pages List</li>
    </ul>
  </div>
</div>
</div>

<div class="row layout-spacing">
 <div class="col-lg-12 ">
  <div class="statbox widget box box-shadow">
   <div class="widget-header">
    <div class="col-md-12 mb-2 mt-2 text-right">
                              <a href="<?php echo base_url("sup_admin/cms_pages/add_cms_pages");?>" class="btn btn-success  btn-rounded mr-3">Add New</a>
                           </div>
</div>
<div class="widget-content widget-content-area">
  <div class="table-responsive mb-4">
   <table id="cms_pages_table" class="table table-bordered table-hover" style="color:black;">
    <thead>
     <tr style="background: #e9ecef;">
      <th>S.no</th>
      <th>Name</th>
      <th>Date</th>
      <th>Option</th>
    </tr>
  </thead>
</table>
</div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
<script src="<?php echo PLUGINS; ?>/table/datatable/datatables.js"></script> 
<script type="text/javascript">
 $(document).ready(function (e) {
  $("#mmm_cms_pages").attr("aria-expanded",'true');
  $("#mm_cms_pages").addClass('show');
  $("#m_cms_pages").addClass('active');    
});

  $(document).ready(function(){
   $('#cms_pages_table').DataTable({
        "pagingType": "full_numbers",
        "processing": true,
        "serverSide": true,
        "order": [],
        "ajax": {
          "url": "<?php echo base_url('sup_admin/cms_pages/getLists'); ?>",
          "type": "POST",
        },
        "columnDefs": [{ 
          "targets": [0,3],
          "orderable": false
        }]
      });
  });

function dlt_data(user_id) {
    if (confirm("Are You Sure you want to delete?")) {
      var xmlhttp;
      if (window.XMLHttpRequest){
        xmlhttp=new XMLHttpRequest();
      }else{
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
      }
      var url = "<?php echo base_url('sup_admin/cms_pages/delete'); ?>" + "/" +user_id;
      xmlhttp.open("GET",url,true);   
      xmlhttp.send();
      xmlhttp.onreadystatechange=function(){
        if (xmlhttp.readyState == 4 ){
          location.reload();
        }
      }
    }
  }
</script>

