 <!--  BEGIN FOOTER  -->
 <footer class="footer-section theme-footer">
    <div class="footer-section-1  sidebar-theme">
    </div>
    <div class="footer-section-2 container-fluid">
        <div class="row">
            <div id="toggle-grid" class="col-xl-7 col-md-6 col-sm-6 col-12 text-sm-left text-center">
                </div>
                <div class="col-xl-5 col-md-6 col-sm-6 col-12">
                    <ul class="list-inline mb-0 d-flex justify-content-sm-end justify-content-center mr-sm-3 ml-sm-0 mx-3">
                        <li class="list-inline-item  mr-3">
                            <p class="bottom-footer">&#xA9; <?php echo date('Y'); ?> Educationcv</p>
                        </li>
                        <li class="list-inline-item align-self-center">
                            <div class="scrollTop"><i class="flaticon-up-arrow-fill-1"></i></div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <!--  END FOOTER  -->

    <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
    <!-- <script src="<?php echo JS; ?>libs/jquery-3.1.1.min.js"></script> -->
    <script src="<?php echo JS; ?>loader.js"></script>
    <script src="<?php echo BJS; ?>popper.min.js"></script>
    <script src="<?php echo BJS; ?>bootstrap.min.js"></script>
    <script src="<?php echo PLUGINS; ?>/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="<?php echo JS; ?>app.js"></script>
    <script src="<?php echo PLUGINS; ?>/select2/select2.min.js"></script>
    <script src="<?php echo PLUGINS; ?>/select2/custom-select2.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo PLUGINS; ?>/date_time_pickers/bootstrap_date_range_picker/moment.min.js"></script>
    <script src="<?php echo PLUGINS; ?>/date_time_pickers/bootstrap_date_range_picker/daterangepicker.js"></script>

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.css">
    <script>
        $('.date').datepicker();
        $(".select2").select2({
          placeholder: "Select a Subjects",
          // allowClear: true
       });
        $(document).ready(function() {
            App.init();
        });
        $(document).ready(function(){
          $('[data-toggle="tooltip"]').tooltip();
        });

        $('input[name="datefilter"]').daterangepicker({
            autoUpdateInput: false,
            locale: {
              cancelLabel: 'Clear'
            }
        });

        $('input[name="datefilter"]').on('apply.daterangepicker', function(ev, picker) {
            $(this).val(picker.startDate.format('YYYY/MM/DD') + ' - ' + picker.endDate.format('YYYY/MM/DD'));
        });

        $('input[name="datefilter"]').on('cancel.daterangepicker', function(ev, picker) {
            $(this).val('');
        });  
    </script>
    <script src="<?php echo JS; ?>custom.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/iCheck/1.0.2/icheck.min.js"></script>
    <!-- END GLOBAL MANDATORY SCRIPTS -->

    <script>
        $(document).ready(function(){
            $("#change_pass_btn").click(function(){
                if($("#old_password").val() == "" )
                {
                    $("#old_password").css('border-color','red');
                    $("#old_password").focus();
                }
                else if($("#new_password").val() == "" )
                {
                    $("#new_password").css('border-color','red');
                    $("#new_password").focus();
                }
                else if($("#retype_password").val() != $("#new_password").val())
                {
                    alert("Confirm password not matched.");
                    $("#retype_password").css('border-color','red');
                    $("#retype_password").focus();
                }
                else
                {
                    $.post("<?php echo base_url('admin/change_pswd'); ?>",
                    {
                        admin_name : $("#admin_name").val(),
                        old_password : $("#old_password").val(),
                        new_password : $("#new_password").val(),
                        retype_password : $("#retype_password").val()
                    },
                    function(data,status){
                    //alert("Data: " + data + "\nStatus: " + status);
                    if(data == "Not Updated")
                    {
                        alert("Sorry, Old password is wrong.");
                        $("#old_password").css('border-color','red');
                        $("#old_password").focus();
                    }
                    else if(data == "success")
                    {
                        alert("Password Updated Successfully.");
                        location.reload();
                    }
                });
                }
            });
        });

        function image_view(image)
        {
            $('#imageshowdata').html('<img src="'+image.src+'"  id="image-gallery-image" style="width: 100%;max-height: 100%">');
            $('#imageshowpopup').modal('show');
        }

    </script>
</body>
</html>