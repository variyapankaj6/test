<div id="content" class="main-content">
   <div class="container">
      <div class="page-header">
         <div class="page-title">
            <h3>Registers List</h3>
            <div class="crumbs">
               <ul id="breadcrumbs" class="breadcrumb">
                  <li><a href="<?php echo base_url('sup_admin/dashboard');?>"><i class="flaticon-home-fill"></i></a></li>
                  <li class="active">Registers List</li>
               </ul>
            </div>
         </div>
      </div>
      <div class="row layout-spacing">
         <div class="col-lg-12 ">
               <div class="statbox widget box box-shadow">
                  <div class="widget-content widget-content-area">
                     <div class="table-responsive mb-4">
                        <table id="registers_table" class="table table-bordered table-hover text-center" style="color:black;">
                          <thead>
                              <tr style="background: #d7ebf5;">
                                    <th>S.no</th>
                                    <th>Details</th>
                                    <th>Info</th>
                                    <th>Location</th>
                                    <th>Numbers</th>
                                    <th>Status</th>
                                    <th>Is Suspend</th>
                                    <th>Action</th>
                              </tr>
                           </thead>
                           </table>
                     </div>
                  </div>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>
<script src="<?php echo PLUGINS; ?>/table/datatable/datatables.js"></script> 
<script type="text/javascript">
  $(document).ready(function (e) {
       $("#mmm_registers").attr("aria-expanded",'true');
       $("#mm_registers").addClass('show');
       $("#m_registers").addClass('active');  
  });

    function dlt_data(user_id) {
		if (confirm("Are You Sure you want to delete?")) {
			var xmlhttp;
			if (window.XMLHttpRequest){
				xmlhttp=new XMLHttpRequest();
			}else{
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
			var url = "<?php echo base_url('sup_admin/registers/delete'); ?>" + "/" +user_id;
			xmlhttp.open("GET",url,true);   
			xmlhttp.send();
			xmlhttp.onreadystatechange=function(){
				if (xmlhttp.readyState == 4 ){
					location.reload();
				}
			}
		}
	}

    function update_filter(){
  $('#registers_table').DataTable().ajax.reload();
}

$(document).ready(function(){
   $('#registers_table').DataTable({
    "pagingType": "full_numbers",
    "processing": true,
    "serverSide": true,
    "order": [],
    "ajax": {
      "url": "<?php echo base_url('sup_admin/registers/getLists'); ?>",
      "type": "POST",
      "data":function(data) {
      }
    },
    "columnDefs": [{ 
      "targets": [0,1,2,4,7],
      "orderable": false
    }],
    "initComplete": function(settings, json) {
    $('[data-toggle="tooltip"]').tooltip();
    }
  });
 });

function active_deactive(users_id,val)
{
  var xmlhttp;
  if (window.XMLHttpRequest){
    xmlhttp=new XMLHttpRequest();
  }else{
    xmlhttp=new activeXObject("Microsoft.XMLHTTP");
  }
  var url = "<?php echo base_url('sup_admin/registers/active_deactive'); ?>" + "/" +users_id+ "/" +val;
  xmlhttp.open("GET",url,true);
  xmlhttp.send();
  xmlhttp.onreadystatechange=function(){
    if (xmlhttp.readyState == 4 ){
      $('#registers_table').DataTable().ajax.reload(null,false);
    }
  }
}

function active_suspend(users_id,val)
{
    if (confirm("Are You Sure you want to suspend?")) {
      var xmlhttp;
      if (window.XMLHttpRequest){
        xmlhttp=new XMLHttpRequest();
      }else{
        xmlhttp=new activeXObject("Microsoft.XMLHTTP");
      }
      var url = "<?php echo base_url('sup_admin/registers/active_suspend'); ?>" + "/" +users_id+ "/" +val;
      xmlhttp.open("GET",url,true);
      xmlhttp.send();
      xmlhttp.onreadystatechange=function(){
        if (xmlhttp.readyState == 4 ){
          $('#registers_table').DataTable().ajax.reload(null,false);
        }
      }
  }
}
</script>