<div id="content" class="main-content">
 <div class="container">
  <div class="page-header">
   <div class="page-title">
    <h3>Add CMS Page</h3>
    <div class="crumbs">
     <ul id="breadcrumbs" class="breadcrumb">
      <li><a href="<?php echo base_url();?>"><i class="flaticon-home-fill"></i></a></li>
      <li><a href="<?php echo base_url("sup_admin/cms_pages"); ?>">CMS Page List</a></li>
      <li class="active">Add CMS Page</li>
    </ul>
  </div>
</div>
</div>
<div class="row">
 <div class="col-lg-12 layout-spacing">
  <div class="statbox widget box box-shadow">
   <div class="widget-content widget-content-area">
         <form role="form" name="form"  action="" id="form7" method="post" enctype="multipart/form-data" >
            <div class="card">
               <div class="card-body">
                  <input type="hidden" id="id" value="<?php if(isset($records)){echo $records[0]['_id'];}else{ echo '0';}?>">

                  <div class="form-group">
                     <label>CMS Page Name *</label>
                     <input type="text"  style="width:50%"  class="form-control" value="<?php if(isset($records))echo $records[0]['name'];?>" name="name" placeholder="Enter CMS Page Name *" required>
                  </div>

                  <div class="form-group">
                     <label>Content *</label>
                     <textarea name="contant" class="form-control html_text" style="width: 50%;" placeholder="Enter Content *" required><?php if(isset($records))echo $records[0]['contant'];?></textarea>
                  </div>

                 
                  <div class="card-footer">
                     <button type="button" name="back" onClick="javascript:history.go(-1);" class="btn btn-secondary"><i
                        class="fa fa-chevron-circle-left"> &nbsp;</i>Back
                     </button>
                     <button type="submit" name="submit" onclick="return check_validation()"  class="btn btn-primary">Submit</button>
                  </div>
               </div>
            </div>
         </form>
     </div>
</div>
</div>
</div>
</div>
</div>
<script src="https://cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>
<script>
   $(document).ready(function (e) {
     $("#mmm_cms_pages").attr("aria-expanded",'true');
     $("#mm_cms_pages").addClass('show');
     $("#m_cms_pages").addClass('active');    
   });
   CKEDITOR.replace( 'contant' );
</script>