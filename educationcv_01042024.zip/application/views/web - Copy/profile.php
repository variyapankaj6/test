<style type="text/css">
   .whiteimage{
   display: none !important;
   }
   .blackimage{
   display: block !important;
   }
   .whitefont{
   color: #1d518d !important;
   }
</style>
<style type="text/css">
   input[type="file"] {
      display: none;
   }
   .custom-file-upload {
      border: 1px solid #ccc;
      display: inline-block;
      padding: 6px 12px;
      cursor: pointer;
   }
</style>
<div class="container pt-5 pb-5">
      <div class="row">
         <div class="col-md-12">
            <div class="pb-2 text-center">
               <h3 style=" font-weight: 600;color: #314584;">My Profile</h3>
            </div>
         </div>
         <div class="col-md-3">
            <div class="statbox widget box box-shadow" style="border: 2px solid #1d518d6b;background: white;padding: 25px 13px; border-radius: 10px;margin: 25px 0px;">
               <div class="widget-content widget-content-area">
                  <div class="text-center pb-4">
                     <img src="<?php if(!empty($records)){ if($records[0]['image'] != ''){ echo IMAGE.'/student/'.$records[0]['image']; }else{ echo NO_IMAGE; }}else{ echo NO_IMAGE; } ?>" height="150px" width="150px" class="rounded-circle" id="image">
                  </div>
                  <label><i class="fa fa-envelope"></i> <?php if(isset($records))echo $records[0]['email_id'];?></label><br/><label><i class="fa fa-phone"></i> <?php if(isset($records))echo $records[0]['mobile_no'];?></label>
               </div>
            </div>
         </div>
         <div class="col-md-7">
            <div class="statbox widget box box-shadow" style="border: 2px solid #1d518d6b;background: white;padding: 25px 13px; border-radius: 10px;margin: 25px 0px;">
               <div class="widget-content widget-content-area">
                  <form autocomplete="off" role="form" name="form" id="form7" method="post" enctype="multipart/form-data">
                     <div class="profile_img text-center">
                        <div style="text-align: left;padding: 8px 0px;">
                           <label class="browse btn-sm btn-primary custom-file-upload mt-2" style="background-color: #314584;">
                              <input type="file" name="image" accept="image/png,image/jpg,image/jpeg"  onchange="image_readURL(this);">
                              <span style="padding-right: 10px;"><i class="fa fa-picture-o" aria-hidden="true"></i></span>Update Profile Image
                           </label>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-6">
                           <div class="form-group">
                              <label>Gender</label>
                              <select class="form-control" name="gender" required>
                                 <option disabled selected value="">Select Gender</option>
                                 <option <?php if(isset($records)){ if($records[0]['gender'] == 0){ echo "selected"; }}?> value="0">Male</option>
                                 <option <?php if(isset($records)){ if($records[0]['gender'] == 1){ echo "selected"; }}?> value="1">Female</option>
                              </select>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <label>Date Of Birth</label>
                              <input type="text"  class="form-control date2" value="<?php if(isset($records))echo date('d-m-Y',strtotime($records[0]['date_of_birth']));?>" name="date_of_birth" placeholder="Enter Date Of Birth" required>
                           </div>
                        </div>
                        <div class="col-md-12">
                           <div class="form-group">
                              <label>Location</label>
                              <input type="text"  class="form-control" value="<?php if(isset($records))echo $records[0]['location'];?>" id="location" name="location" placeholder="Enter Location" required>
                              <input type="hidden" name="latitude" id="latitude" value="<?php if(isset($records))echo $records[0]['latitude'];?>">
                              <input type="hidden" name="longitude" id="longitude" value="<?php if(isset($records))echo $records[0]['longitude'];?>">
                           </div>
                        </div> 
                        <div class="col-md-12">
                           <div class="form-group">
                              <label>About Us</label>
                              <textarea rows="5" class="form-control" name="about_us" required placeholder="About Us"><?php if(isset($records)) { echo $records[0]['about_us']; }?></textarea>
                           </div>
                        </div>
                        <div class="col-md-12">
                           <div class="form-group">
                              <label>Address</label>
                              <textarea class="form-control" name="address" required placeholder="Address"><?php if(isset($records)) { echo $records[0]['address']; }?></textarea>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <label>Country</label>
                              <select name="country_id" id="country" class="form-control" required>
                                 <option selected disabled value="">Select Country</option>
                                 <?php foreach ($country_list as $key) { ?>
                                 <option value="<?php echo $key['_id']; ?>" <?php if(isset($records)){ if($records[0]['country_id'] == $key['_id']){ echo "selected"; } }?> ><?php echo $key['name']; ?></option>
                                 <?php } ?>
                              </select>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <label>State</label>
                              <select name="state_id" id="state" class="form-control" required>
                                 <option selected disabled value="">Select State</option>
                                    <?php foreach ($state_list as $key) { ?>
                                 <option value="<?php echo $key['_id']; ?>" <?php if(isset($records)){ if($records[0]['state_id'] == $key['_id']){ echo "selected"; } }?> ><?php echo $key['state_name']; ?></option>
                                    <?php } ?>
                              </select>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <label>City</label>
                              <select name="city_id" id="city" class="form-control" required>
                                 <option selected disabled value="">Select City</option>
                                 <?php foreach ($city_list as $key) { ?>
                                 <option value="<?php echo $key['_id']; ?>" <?php if(isset($records)){ if($records[0]['city_id'] == $key['_id']){ echo "selected"; } }?> ><?php echo $key['city_name']; ?></option>
                                 <?php } ?>
                              </select>
                           </div>
                        </div>
                     </div>
                     <div class="form-group pt-3">
                        <button type="submit" name="submit" class="btn btn-primary" style="width: 100%;background-color: #314584;border-radius: 5px;border: none;">Update Profile</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
         <div class="col-md-2"></div>
      </div>
   </div>
</div>
<script type="text/javascript">
   $('#header-area').removeClass('fixed-top');
   $('#header-area').css('box-shadow','15px 0px 15px -10px rgba(0,0,0,0.75)');
</script>
<script type="text/javascript">
   function image_readURL(input) {
    if (input.files && input.files[0]){
      var reader = new FileReader();
      reader.onload = function(e) {
        $('#image').attr('src', e.target.result);
        $('#image').show();
     }
     reader.readAsDataURL(input.files[0]);
   }}
</script>
<script type="text/javascript">
   $(function () {
    $('#country').change(function(){
     var id = $(this).val();   
     if(id){
      $.ajax({
       type:"POST",
       url:"<?php echo base_url('my_profile/getStateList'); ?>",
       data:{id:id},
       success:function(res){  
        if(res){
         var data = JSON.parse(res);
         $("#state").empty();
         $("#state").append('<option selected disabled value="">Select State</option>');
         $.each(data,function(key,value){
          $("#state").append('<option value="'+value._id+'">'+value.state_name+'</option>');
        });
       }else{
         $("#state").empty();
       }
     }
   });
    }else{
      $("#state").empty();
      $("#city").empty();
    }      
   });
   
   
    $('#state').on('change',function(){
     var id = $(this).val();    
     if(id){
      $.ajax({
       type:"POST",
       url:"<?php echo base_url('my_profile/getCityList'); ?>",
       data:{id:id},
       success:function(res){               
        if(res){
         var data = JSON.parse(res);
         $("#city").empty();
         $("#city").append('<option selected disabled value="">Select City</option>');
         $.each(data,function(key,value){
          $("#city").append('<option value="'+value._id+'">'+value.city_name+'</option>');
        });             
       }else{
         $("#city").empty();
       }
     }
   });
    }else{
      $("#city").empty();
    }    
   });
   });
</script>
<script>
   function initMap() {
       var input = document.getElementById('location');
     
       var autocomplete = new google.maps.places.Autocomplete(input);
      
       autocomplete.addListener('place_changed', function() {
           var place = autocomplete.getPlace();
           document.getElementById('location').value  = place.formatted_address;
           document.getElementById('latitude').value  = place.geometry.location.lat();
           document.getElementById('longitude').value  = place.geometry.location.lng();
       });
   }
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo GOOGLEMAPKEY; ?>&libraries=places&callback=initMap" async defer></script>