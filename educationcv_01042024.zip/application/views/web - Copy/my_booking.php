<style type="text/css">
   .subjectbox{
   background: #f8f9fa;
   border-radius: 2px;
   padding: 4px 10px;
   font-size: 0.8rem;
   margin-right: 3px;
   }
   .circleimage{
   height: 70px;
   width: 70px;
   border-radius: 50%;
   border: 1px solid #93c91c;
   }
</style>
<div class="container pt-5 pb-5">
   <div class="pb-2 text-center">
      <h3 style=" font-weight: 600;color: #314584;">My Booking List</h3>
   </div>
   <div class="col-md-12 p-0 mt-5">
      <div class="row">
         <?php if(empty($bookinglist)){ ?>
            <div class="col-md-12 text-center pt-5 pb-5">
               <h2 class="pt-5 pb-5" style="font-weight:400;">Data not found.</h2>
            </div>
         <?php } ?>
         <?php 
         foreach ($bookinglist as $val => $key) { 
            $teachersdata = $this->qm->select_where('tbl_teachers',array('_id' => $key->teacher_id));
            if($teachersdata[0]['image'])
            {
               $image = IMAGE."teacher/".$teachersdata[0]['image'];
            }else{
               $image = NO_USER;
            } 
            $boarddata = $this->qm->select_where('tbl_board',array('_id' => $key->board_id));
            $gradedata = $this->qm->select_where('tbl_grades',array('_id' => $key->grade_id));
            $curriculumdata = $this->qm->select_where('tbl_curriculum',array('_id' => $key->curriculum_id));
            $languagedata = $this->qm->select_where('tbl_language',array('_id' => $key->language_id));
            $total_review = $this->qm->num_row('tbl_teachers_rating',array('teacher_id' => $key->teacher_id,'status'=>1));
            $total_star = $this->db->query('SELECT avg(`rating`) as total FROM tbl_teachers_rating WHERE status = 1 AND teacher_id = '.$key->teacher_id)->result_array();
            $total_star = $this->qm->star_rating($total_star[0]['total']);
            if($key->status == '1') {
                $status = '<b style="color:orange;">Booked</b>';
            }else if($key->status == '2') {
                $status = '<b style="color:green;">Complete</b>';
            }else if($key->status == '3') {
                $status = '<b style="color:#d73d3d;">Cancel</b>';
            }else{
                $status = '<b style="color:#194880;">Pending</b>';
            }
         ?>
         <div class="col-md-4 pb-3">
            <div class="card" style="background: #fff;border-radius: 20px;">
               <div class="card-body">
                  <div class="d-flex pb-3">
                     <img class="card-img-top" src="<?php echo $image; ?>" alt="<?php echo $teachersdata[0]['name']; ?>" style="border-radius: 12px;background: #e6e7e2;height: 70px;width: 70px; margin-right: 10px;">
                     <div class="mt-auto mb-auto">
                        <p style="color: #194880;margin-bottom: 4px;">Tutor Name : <?php echo $teachersdata[0]['name']; ?></p>
                        <p style="color: #194880;margin-bottom: 4px;"><?php echo $total_star; ?> (<?php echo $total_review; ?> Reviews)</p>
                     </div>
                  </div>
                  <p style="color: #194880;margin-bottom: 4px;">Date : <?php echo date('d F Y',strtotime($key->date)); ?></p>
                  <p style="color: #194880;margin-bottom: 4px;">Timeing : <?php echo date('h:i A',strtotime($key->start_time)).' to '.date('h:i A',strtotime($key->end_time)); ?></p>
                  <p style="color: #194880;margin-bottom: 4px;">Price : Rs. <?php echo $teachersdata[0]['min_fee_range']; ?> to <?php echo $teachersdata[0]['max_fee_range']; ?>/<?php if($teachersdata[0]['fee_type'] == 1){ echo "Monthly"; }else if($teachersdata[0]['fee_type'] == 2){ echo "Hourly"; }else{ echo "Fixed"; }?></p>
                  <p style="color: #194880;margin-bottom: 4px;">Board : <?php echo $boarddata[0]['name']; ?></p>
                  <p style="color: #194880;margin-bottom: 4px;">Grade : <?php echo $gradedata[0]['name']; ?></p>
                  <p style="color: #194880;margin-bottom: 4px;">Curriculum : <?php echo $curriculumdata[0]['name']; ?></p>
                  <p style="color: #194880;margin-bottom: 4px;">Language : <?php echo $languagedata[0]['name']; ?></p>
                  <p style="color: #194880;margin-bottom: 4px;">Status : <?php echo $status; ?></p>
               </div>
            </div>
         </div>
         <?php } ?>
         <div class="col-md-12 item3">
             <div class="row mb-5">
               <div class="col-md-12">
                  <div class="page-pagination-wrapper mt-20 mt-md-20 mt-sm-20">
                     <nav class="page-pagination">
                        <ul class="pagination justify-content-center">
                           <?php echo $links; ?>
                        </ul>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div> 
<script type="text/javascript">
   $('#header-area').removeClass('fixed-top');
   $('#header-area').css('box-shadow','15px 0px 15px -10px rgba(0,0,0,0.75)');
</script>