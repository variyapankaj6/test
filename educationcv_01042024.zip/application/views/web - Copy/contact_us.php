<div class="container pt-5 pb-5">
<div class="row pt-5">
      <div class="col-md-2"></div>
      <div class="col-md-8">
         <p style="color: #93c91d;" class="mb-0">CONTACT US</p>
         <h2 style="font-weight: 600;color: #314584;">For More Enquiries</h2>
         <form class="pt-5" method="post" autocomplete="off">
            <div class="form-group row pb-3">
               <div class="col">
                  <input type="text" class="form-control" style="padding: 20px 9px;" placeholder="Your email" name="email_id" required>
               </div>
               <div class="col">
                  <input type="text" class="form-control" style="padding: 20px 9px;" placeholder="Subject" name="subject" required>
               </div>
            </div>
            <div class="form-group">
               <textarea class="form-control" rows="5" name="message" placeholder="Message here..." required></textarea>
            </div>
            <div class="form-group text-center pt-5">
               <button type="submit" name="contactsubmit" class="btn btn-primary" style="background-color: #ffc107;border-radius: 31px;border: none;">Send Message</button>
            </div>
         </form>
      </div>
      <div class="col-md-2"></div>
   </div>
</div>
<script type="text/javascript">
   $('#header-area').removeClass('fixed-top');
   $('#header-area').css('box-shadow','15px 0px 15px -10px rgba(0,0,0,0.75)');
</script>