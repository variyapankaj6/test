<!DOCTYPE html>
<html class="no-js" lang="ENG">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Conceptorz</title>
      <meta name="title" content="Conceptorz">
      <meta name="author" content="Conceptorz">
      <meta name="keywords" content="Conceptorz">
      <meta name="description" content="Conceptorz">
      <link rel="shortcut icon" href="<?php echo MAINLOGO; ?>" type="image/x-icon">
      <link rel="icon" href="<?php echo MAINLOGO; ?>" type="image/x-icon">

      <!-- Open Graph / Facebook -->
      <meta property="og:type" content="website">
      <meta property="og:url" content="<?php echo base_url(); ?>">
      <meta property="og:title" content="Conceptorz">
      <meta property="og:description" content="Conceptorz">
      <meta property="og:image" content="<?php echo MAINLOGO; ?>">

      <!-- Twitter -->
      <meta property="twitter:card" content="summary_large_image">
      <meta property="twitter:url" content="<?php echo base_url(); ?>">
      <meta property="twitter:title" content="Conceptorz">
      <meta property="twitter:description" content="Conceptorz">
      <meta property="twitter:image" content="<?php echo MAINLOGO; ?>">
   
      <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Work+Sans" />
      <link href="<?php echo WEBASSETS; ?>assets/css/revslider/settings.css" rel="stylesheet">
      <link href="<?php echo WEBASSETS; ?>assets/css/vendor/bootstrap.min.css" rel="stylesheet">
      <link href="<?php echo WEBASSETS; ?>assets/css/vendor/font-awesome.css" rel="stylesheet">
      <link href="<?php echo WEBASSETS; ?>assets/css/vendor/dl-icon.css" rel="stylesheet">
      <link href="<?php echo WEBASSETS; ?>assets/css/plugins.css" rel="stylesheet">
      <link href="<?php echo WEBASSETS; ?>assets/css/helper.min.css" rel="stylesheet">
      <link href="<?php echo WEBASSETS; ?>assets/css/style.min.css" rel="stylesheet">
      <link href="<?php echo WEBASSETS; ?>styles.css" rel="stylesheet">
      <script src="<?php echo WEBASSETS; ?>assets/js/vendor/modernizr-2.8.3.min.js"></script>
      <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"/>
      <script src="<?php echo WEBASSETS; ?>assets/js/vendor/jquery-3.3.1.min.js"></script>
   </head>
   <style type="text/css">
      html *
      {
      font-family: 'Work Sans', sans-serif;
      }
      .tab-slider--nav {
      width: 100%;
      float: left;
      margin-bottom: 20px;
      }
      .footer-text
      {
         color: #FFFFFF;
      }
      .social
      {
      width: 90%;
      }
      @media (max-width: 767px) {
      .social
      {
      width: 70% !important;
      }
      .social-flex
      {
      justify-content: center;
      display: flex;
      }
      .header-button
      {
      margin-left: -34px;
      }
      }
      .tab-slider--tabs {
      display: block;
      float: left;
      margin-top: -29px;
      padding: 12px;
      list-style: none;
      position: relative;
      border-radius: 0px;
      overflow: hidden;
      background: #1e508d00;
      height: 50px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      width: 100%;
      /* border: 1px solid #157cb9; */
      }
      .tab-slider--tabs:after {
      content: "";
      width: 50%;
      background: #1e508d00;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      transition: all 250ms ease-in-out;
      border-radius: 0px;
      }
      .tab-slider--tabs.slide:after {
      left: 50%;
      }
      .tab-slider--trigger {
      font-size: 12px;
      line-height: 1;
      font-weight: bold;
      color: #345F90;
      text-transform: uppercase;
      text-align: center;
      /* padding: 19px 20px; */
      position: relative;
      z-index: 2;
      cursor: pointer;
      display: inline-block;
      transition: color 250ms ease-in-out;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      width: 49%;
      color: white;
      }
      .tab-slider--trigger.active {
      color: #fff;
      }
      .tab-slider--body {
      margin-bottom: 20px;
      }
      .nice-select {
      border: 1px solid #157cb9;
      color: #157cb9 !important;
      -webkit-border-radius: 0;
      -moz-border-radius: 0;
      border-radius: 0;
      float: none;
      height: 39px;
      text-transform: capitalize;
      line-height: inherit;
      padding: 8px 30px 8px 15px;
      width: 100%;
      border-radius: 13px;
      color: black
      }
      .nice-select span.current {
         font-weight: 300;
      }
      .card-container {
      align-items: start;
      display: grid;
      grid-gap: 16px;
      grid-template-columns: repeat(auto-fit, 300px);
      justify-content: center;
      }
      .card{
      background-color: rgb(255, 255, 255);
      box-shadow: 0 0 6px 2px rgb(0 0 0 / 10%);
      border: none;
      }
      .fas {
      font-size: 50px;
      }
      .card-heading {
      font-weight: 600;
      color: #8dcff1;
      font-size: 18px;
      }
      .my-cards {
      max-width: 1000px;
      margin: 0px auto;
      padding: 40px 0;
      }
      .my-card {
      margin: 0px;
      display: inline-block;
      position: relative;
      width: 100%;
      height: 200px;
      opacity: 0.95;
      border: 2px solid #54baeb;
      border-radius: 13px;
      }
      .my-card:hover .my-front,
      .my-card:focus .my-front {
      -webkit-transform: rotateY(-180deg);
      transform: rotateY(-180deg);
      }
      .my-card:hover .my-back,
      .my-card:focus .my-back {
      -webkit-transform: rotateY(0deg);
      transform: rotateY(0deg);
      }
      .my-card .my-front {
      width: 100%;
      height: 100%;
      position: absolute;
      color: #54baeb;
      border-radius: 5px;
      -webkit-backface-visibility: hidden;
      backface-visibility: hidden;
      -webkit-transition: -webkit-transform 300ms;
      transition: -webkit-transform 300ms;
      transition: transform 300ms;
      transition: transform 300ms, -webkit-transform 300ms;
      -webkit-transition-timing-function: linear;
      transition-timing-function: linear;
      }
      .my-card .my-back {
      width: 100%;
      height: 100%;
      position: absolute;
      color: #fff;
      border-radius: 5px;
      -webkit-backface-visibility: hidden;
      backface-visibility: hidden;
      -webkit-transition: -webkit-transform 300ms;
      transition: -webkit-transform 300ms;
      transition: transform 300ms;
      transition: transform 300ms, -webkit-transform 300ms;
      -webkit-transition-timing-function: linear;
      transition-timing-function: linear;
      background: #54baeb;
      }
      .my-card .my-front hr,
      .my-card .my-back hr {
      border: none;
      color: white;
      border: 1px solid;
      }
      .my-card .my-front {
      transform: rotateY(0deg);
      text-align: center;
      padding: 30px;
      }
      .my-card .my-front .my-image {
      height: 80px;
      width: 90px;
      border: 5px solid white;
      display: inline-block;
      margin-bottom: 10px;
      }
      .my-card .my-front .my-name {
      display: inline-block;
      font-size: 18px;
      }
      .my-card .my-back {
      -webkit-transform: rotateY(180deg);
      transform: rotateY(180deg);
      padding: 23px 30px;
      display: flex;
      align-items: flex-end;
      }
      .my-card .my-back a {
      color: white;
      text-decoration: none;
      }
      .my-card .my-back a i {
      font-size: 22px;
      padding: 5px;
      -webkit-transition: -webkit-transform 0.1s ease-out;
      -moz-transition: -moz-transform 0.1s ease-out;
      -o-transition: -o-transform 0.1s ease-out;
      transition: transform 0.1s ease-out;
      }
      .my-card .my-back a:hover i {
      transform: scale(1.2);
      }
      .learn {
      background-color: #1d518d;
      color: white;
      border-radius: 7px;
      padding: 5px;
      border: none;
      font-size: 13px;
      }
      .demo{ background: #f8f7f6; }
      #testimonial-slider{
      padding: 16px 20px 35px 20px;
      text-align: center;
      }
      .testimonial .description{
      font-size: 14px;
      color: #777;
      line-height: 26px;
      text-indent: 30px;
      position: relative;
      }
      .testimonial .title{
      font-size: 24px;
      font-weight: bold;
      color: #363636;
      text-transform: capitalize;
      margin: 0;
      }
      .testimonial .post{
      display: block;
      font-size: 15px;
      color: #363636;
      }
      .owl-buttons{
      width: 100%;
      height: 40px;
      position: absolute;
      bottom: 40%;
      left: 0;
      }
      .owl-prev,
      .owl-next{
         position: absolute;
         left: -23px;
         transition: all 0.4s ease-in-out 0s;
      }
      .owl-next{
         left: auto;
         right: -23px;
      }
      .owl-buttons .owl-prev:before,
      .owl-buttons .owl-next:before{
      content: "\f104";
      font-family: "Font Awesome 5 Free";
      font-weight: 900;
      font-size: 60px;
      font-weight: 900;
      color: #cacaca;
      line-height: 20px;
      opacity: 0.8;
      }
      .owl-buttons .owl-next:before{
      content: "\f105";
      }
      .owl-buttons .owl-prev:hover:before,
      .owl-buttons .owl-next:hover:before{
      opacity: 1;
      }
      .owl-theme .owl-controls .owl-buttons div{
      background: transparent;
      }
      .owl-theme .owl-controls{
      margin-top: 40px;
      }
      .owl-theme .owl-controls .owl-page span{
      width: 50px;
      height: 50px;
      border-radius: 50%;
      border: 4px solid #ccc;
      background: url("../images/img-1.jpg") no-repeat;
      background-size: cover;
      transition: all 0.3s ease-in-out 0s;
      }
      .owl-theme .owl-controls .owl-page:nth-child(2) span{
      background: url("../images/img-2.jpg") no-repeat;
      background-size: cover;
      }
      .owl-theme .owl-controls .owl-page:nth-child(3) span{
      background: url("../images/img-3.jpg") no-repeat;
      background-size: cover;
      }
      .owl-theme .owl-controls.clickable .owl-page:hover span{
      opacity: 0.5;
      }
      .owl-theme .owl-controls .owl-page.active span,
      .owl-theme .owl-controls .owl-page.active:hover span{
      border-color: #d133ff;
      opacity: 1;
      }
      @media only screen and (max-width: 479px){
      .owl-buttons{ bottom: 30%; }
      }
      .popular-sub-p
      {
      position: absolute;
      top: 50%;
      left: 50%;
      color: rgb(255, 255, 255);
      font-size: 25px;
      transform: translate(-50%, -50%);
      text-shadow: 0px 0px 3px white;
      text-align: center;
      }
      @media only screen and (max-width: 768px) {
         .mobile-hide
         {
            display: none;
         }
         .slider-p
         {
            display: none;
         }
         .test-img
         {
            width: 50% !important;
         }
      }
      .carousel-caption {
         transform: translateY(-50%);
         bottom: 0;
         top: 50%;
         right: 10%;
         left: 10%;
      }
      .test-img
      {
      width: 20%;
      }
      .form-control{
         background: #e7f0fb;
         border: none;
         color: #194880;
      }
      .owl-prev span, .owl-next span {
          color: #ffffff;
          background: #faaf3a;
          padding: 6px;
          border-radius: 50%;
      }
      #partitioned {
        padding-left: 13px;
       letter-spacing: 40px;
       border: 0;
       background-image: linear-gradient(to left, black 70%, rgba(255, 255, 255, 0) 0%);
       background-position: bottom;
       background-size: 50px 1px;
       background-repeat: repeat-x;
       background-position-x: 35px;
       width: 190px;
       outline: none;
      }
      .coursesbtn{
         background-color: #ffffff;
         color: #60beae;
         border-color: #60beae;
         border-radius: 10px;
         line-height: 1.5;
      }
   </style>
   <body class="preloader-active">
      <div class="preloader-area-wrap">
         <div class="spinner d-flex justify-content-center align-items-center h-100">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
         </div>
      </div>

      <div class="modal fade bd-mobile-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content" style="border-radius: 40px;">
            <div class="col-md-12">
               <div class="row">
                  <div class="col-md-5 mobile-hide" style="background: #faaf3a;border-radius: 40px 0px 0px 40px;">
                     <h2 class="p-4 pt-5" style="color: blue;">Join Our Community <span style="color:white;">Build Your Wonderful Career</span></h2>
                     <img src="<?php echo WEBASSETS; ?>assets/img/5364323.png" style="position: absolute;bottom: 0px;max-width: 100%;height: 300px;">
                  </div>
                  <div class="col-md-7 p-5 text-center">
                     <img src="<?php echo WEBASSETS; ?>assets/img/logo.png" alt="Logo" style="width: 225px;"/>
                     <p class="pt-5 pb-5">Enroll Now To Learn LIVE<br/>Online From Conceptorz</p>
                     <form id="mobile_login" method="post" autocomplete="off">
                        <div class="form-group">
                           <select name="country_code" class="form-control" style="padding: 12px 9px;height: auto;" required>
                              <option value="" disabled selected>Select Your Country Code</option>
                              <option value="91">India (+91)</option>
                           </select>
                        </div>
                        <div class="form-group">
                           <input type="number" onKeyPress="if(this.value.length==10) return false;" placeholder="Enter Your Mobile Number" name="mobile_no" class="form-control" required>
                        </div>
                        <p id="mobile_error"></p>
                        <button type="submit" class="btn btn-block" style="background-color: #faaf3a;border-color: #faaf3a; border-radius: 25px;font-size: larger;color: white;">Next</button>
                     </form>
                     <button class="btn mt-5 btn-block" style="background: white;color: black;border-color: #a3a1a1;border-radius: 25px;"><img src="<?php echo WEBASSETS; ?>assets/img/google.png" alt="Logo" style="width: 30px;"/> Continue with Google</button>
                     <small>We never post without your permission</small>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade bd-otp-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content" style="border-radius: 40px;">
            <div class="col-md-12">
               <div class="row">
                  <div class="col-md-5 mobile-hide" style="background: #faaf3a;border-radius: 40px 0px 0px 40px;">
                     <h2 class="p-4 pt-5" style="color: blue;">Join Our Community <span style="color:white;">Build Your Wonderful Career</span></h2>
                     <img src="<?php echo WEBASSETS; ?>assets/img/5364323.png" style="position: absolute;bottom: 0px;max-width: 100%;height: 300px;">
                  </div>
                  <div class="col-md-7 p-5 text-center">
                     <img src="<?php echo WEBASSETS; ?>assets/img/logo.png" alt="Logo" style="width: 225px;"/>
                     <h6 style="line-height: 34px;color: #9f9999;" class="pt-5 pb-5">Please enter OTP sent to your<br/>Mobile +910389264246 <span style="color:red;"><i class="fa fa-edit"></i>Edit</span></h6>
                     <form id="otp_form" method="post" autocomplete="off">
                        <div class="form-group">
                           <input type="number" onKeyPress="if(this.value.length==4) return false;" id="partitioned" name="otp" required>
                        </div>
                        <p id="otp_error"></p>
                        <h5 class="mt-5" style="color:#faaf3a;" onclick="resend_otp();">RESEND</h5>
                        <small>By clicking verify, you agree to conceptorz<br/>Tearms & Conditions and the Privacy Policy</small>
                        <button type="submit" class="mt-5 btn btn-block" style="background-color: #faaf3a;border-color: #faaf3a; border-radius: 25px;font-size: larger;color: white;">VERIFY</button>
                     </form>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade bd-register-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content" style="border-radius: 40px;">
            <div class="col-md-12">
               <div class="row">
                  <div class="col-md-5 mobile-hide" style="background: #faaf3a;border-radius: 40px 0px 0px 40px;">
                     <h2 class="p-4 pt-5" style="color: blue;">Join Our Community <span style="color:white;">Build Your Wonderful Career</span></h2>
                     <img src="<?php echo WEBASSETS; ?>assets/img/5364323.png" style="position: absolute;bottom: 0px;max-width: 100%;height: 300px;">
                  </div>
                  <div class="col-md-7 p-5 text-center">
                     <img src="<?php echo WEBASSETS; ?>assets/img/logo.png" alt="Logo" style="width: 225px;"/>
                     <h5 style="line-height: 34px;color: #9f9999;" class="pt-5 pb-5">Almost Done !</h5>
                     <form id="registerform" method="post" autocomplete="off">
                        <div class="form-group">
                           <input type="text" placeholder="Enter Name" name="name" class="form-control" required>
                        </div>
                        <div class="form-group">
                           <input type="text" placeholder="Enter Date Of Birth" name="date_of_birth" class="form-control date2" required>
                        </div>
                        <div class="form-group">
                           <select class="form-control" style="height:auto;" name="gender" required>
                              <option selected disabled value="">Select Gender</option>
                              <option value="0">Male</option>
                              <option value="1">Female</option>
                           </select>
                        </div>
                        <div class="form-group">
                           <input type="email" placeholder="Enter Your Email ID" name="email_id" class="form-control" required>
                           <small>We never post without your permission</small>
                        </div>
                        <p id="register_error"></p>
                        <button type="submit" class="mb-5 btn btn-block" style="background-color: #faaf3a;border-color: #faaf3a; border-radius: 25px;font-size: larger;color: white;">LET ME IN</button>
                     </form>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>

      <header id="header-area" class="fixed-top sticky-header headerUp">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="header-content-wrapper d-flex align-items-center" style="padding: 13px 0;">
                     <div class="header-left-area d-flex align-items-center">
                        <div class="logo-area">
                           <a href="<?php echo base_url(); ?>"><img src="<?php echo MAINLOGO; ?>" alt="Logo"
                              style="width: 225px;" /></a>
                        </div>
                     </div>
                     <div class="header-mainmenu-area d-none d-lg-block">
                        <nav id="mainmenu-wrap" style="float: right;">
                           <ul class="nav mainmenu justify-content-right">
                              <li class="dropdown-show">
                                 <a href="<?php echo base_url('tutors'); ?>" class="btn coursesbtn">Tutors</a>
                              </li>
                              <li class="dropdown-show m-auto">
                                 <a href="<?php echo base_url(); ?>">Home</a>
                              </li>
                              <li class="dropdown-show m-auto">
                                 <a href="<?php echo base_url('about_us'); ?>">About Us</a>
                              </li>
                              <!-- <li class="dropdown-show m-auto">
                                 <a href="#">Blogs</a>
                              </li> -->
                              <li class="dropdown-show m-auto">
                                 <a href="<?php echo base_url('contact_us'); ?>">Contact Us</a>
                              </li>
                              <?php if($this->session->userdata('conceptorz2022_web_email') != "" && $this->session->userdata('conceptorz2022_web_id') != ""){ ?>
                                 <li class="dropdown-show m-auto">
                                    <a href="#">My Account</a>
                                    <ul class="dropdown-nav">
                                       <li><a style="font-size: 1rem;color: #194880;" href="<?php echo base_url('my_profile'); ?>">My Profile</a></li>
                                       <li><a href="<?php echo base_url('my_booking'); ?>" style="font-size: 1rem;color: #194880;" href="#">My Booking list</a></li>
                                       <li><a style="font-size: 1rem;color: #194880;" href="<?php echo base_url('home/logout'); ?>">Logout</a></li>
                                    </ul>
                                 </li>
                              <?php }else{ ?>
                                 <!-- <li class="dropdown-show m-auto">
                                    <a href="#">More</a>
                                 </li> -->
                              <?php } ?>
                           </ul>
                        </nav>
                     </div>
                     <div class="header-right-area d-flex justify-content-end align-items-center">
                        <?php if($this->session->userdata('conceptorz2022_web_email') != "" && $this->session->userdata('conceptorz2022_web_id') != ""){ 
                           $notifications_count = $this->qm->num_row('tbl_notifications',array('student_id' => $this->session->userdata('conceptorz2022_web_id'),'noti_for'=>0,'read_status'=>0));
                        ?>
                        <a href="<?php echo base_url('notification'); ?>"><button class="mini-cart-icon" style="font-size: 1.2rem;">
                            <i class="fa fa-bell" style="color: #306097;"></i>
                            <span class="cart-count" style="left: 14px;left: 10px;font-size: 0.8rem;background-color: #306097;"><?php echo $notifications_count; ?></span>
                        </button></a>
                        <?php }else{ ?>
                        <a data-toggle="modal" data-target=".bd-mobile-modal-lg" class="btn btn-outline-primary shadow-sm header-button" style="background-color: #ffffff;color: #60beae;border-color: #60beae;padding: 6px 30px !important;border-radius: 10px;">Login</a>
                        <?php } ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header>
<script type="text/javascript">
   $("#mobile_login").submit(function(e) {
      e.preventDefault();
      var form = $(this);
      $.ajax({
         type: "POST",
         url: "<?php echo base_url('home/mobile_check'); ?>",
         data: form.serialize(),
         success: function(data)
         {
            var data = JSON.parse(data);
            if(data.status == 1){
               $('.bd-mobile-modal-lg').modal('hide');
               $('.bd-otp-modal-lg').modal({backdrop: 'static', keyboard: false});
               $("#otp_error").html(data.message);
            }else{
               $("#mobile_error").html(data.message);
            }
         }
      });
   });

   function resend_otp(){
      $.ajax({
         type: "POST",
         url: "<?php echo base_url('home/resend_otp'); ?>",
         data: '',
         success: function(data)
         {
            var data = JSON.parse(data);
            $("#otp_error").html(data.message);
         }
      });
   }


   $("#otp_form").submit(function(e) {
      e.preventDefault();
      var form = $(this);
      $.ajax({
         type: "POST",
         url: "<?php echo base_url('home/verify_otp'); ?>",
         data: form.serialize(),
         success: function(data)
         {
            var data = JSON.parse(data);
            if(data.status == 1){
               $('.bd-otp-modal-lg').modal('hide');
               $('.bd-register-modal-lg').modal({backdrop: 'static', keyboard: false});
               $("#register_error").html(data.message);
            }else if(data.status == 2){
               $("#otp_error").html(data.message);
               location.reload();
            }else{
               $("#otp_error").html(data.message);
            }
         }
      });
   });


   $("#registerform").submit(function(e) {
      e.preventDefault();
      var form = $(this);
      $.ajax({
         type: "POST",
         url: "<?php echo base_url('home/register_now'); ?>",
         data: form.serialize(),
         success: function(data)
         {
            var data = JSON.parse(data);
            if(data.status == 1){
               $("#register_error").html(data.message);
               location.reload();
            }else{
               $("#register_error").html(data.message);
            }
         }
      });
   });
</script>