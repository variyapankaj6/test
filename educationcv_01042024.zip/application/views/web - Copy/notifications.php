<div class="container pt-5 pb-5">
   <div class="pb-2 text-center">
      <h3 style=" font-weight: 600;color: #314584;">Notifications</h3>
   </div>
   <div class="row">
      <div class="col-md-2"></div>
      <div class="col-md-8">
         <?php if(empty($notificationslist)){ ?>
            <div class="col-md-12 text-center pt-5 pb-5">
               <h2 class="pt-5 pb-5" style="font-weight:400;">Data not found.</h2>
            </div>
         <?php } ?>
         <?php 
         foreach ($notificationslist as $val => $key) { 
         ?>
         <div class="p-3 mb-3" style="background-color: #f0f0f0; border-radius: 8px;">
            <?php if(!empty($key->booking_id)){ ?>
               <a href="<?php echo base_url('my_booking'); ?>">
                  <span style="color: #1d528c;" ><?php echo $key->message; ?></span><br/>
                  <small style="color:gray;"> <?php echo date('d M Y',strtotime($key->created_at)); ?> </small>
               </a>
            <?php }else{ ?>
               <a href="<?php echo base_url('my_booking'); ?>">
                  <span style="color: #1d528c;" ><?php echo $key->message; ?></span><br/>
                  <small style="color:gray;"> <?php echo date('d M Y',strtotime($key->created_at)); ?> </small>
               </a>
            <?php } ?>
         </div>
         <?php } ?>
         <div class="col-md-12 item3">
             <div class="row mb-5">
               <div class="col-md-12">
                  <div class="page-pagination-wrapper mt-20 mt-md-20 mt-sm-20">
                     <nav class="page-pagination">
                        <ul class="pagination justify-content-center">
                           <?php echo $links; ?>
                        </ul>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="col-md-2"></div>
   </div>
</div>
<script type="text/javascript">
   $('#header-area').removeClass('fixed-top');
   $('#header-area').css('box-shadow','15px 0px 15px -10px rgba(0,0,0,0.75)');
</script>