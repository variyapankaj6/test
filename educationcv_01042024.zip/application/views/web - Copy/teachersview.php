<style type="text/css">
   .product-description-review .desc-review-tab-menu li a.active {
   background-color: #ffa500;
   color: #ffffff;
   }
   .product-description-review .desc-review-tab-menu li a {
   color: #314584;
   font-size: 1.1rem;
   padding: 7px 17px;
   }
   .product-description-review .tab-content {
   color: #000000;
   font-size: 1rem;
   margin-top: 20px;
   }
   .subjectbox1{
      color: white;
      border-radius: 16px;
      padding: 4px 10px;
      font-size: 0.8rem;
      margin-right: 3px;
      border: 1px solid white;
      background-color: #0000009e;
   }
</style>
<div class="container pt-5">
   <div class="col-md-12 pb-5">
      <div class="card" style="border-radius: 15px;">
         <div class="col-md-12 p-3">
            <div class="d-md-flex">
               <div style="margin-right: 2rem!important;">
                  <img src="<?php echo $image; ?>" alt="" style="height: 200px;max-width: 100%;border-radius: 15px;margin-bottom: 10px;">
               </div>
               <div class="mt-auto mb-auto">
                  <h4 style="color: #314584;"><?php echo $tutors_details[0]['name']; ?></h4>
                  <div class="d-flex">
                     <?php echo $total_star; ?> <small style="color: #194880;font-weight: 500;"> (<?php echo $total_review; ?> Reviews)</small>
                  </div>
                  <p class="mb-2 mt-2" style="color:#ffa500;font-weight: 600;"><i class="fa fa-map-marker" style="color:#314584;"></i> <?php echo $city[0]['city_name']; ?>, <?php echo $state[0]['state_name']; ?>, <?php echo $country[0]['name']; ?></p>
                  <p class="mb-2" style="color:#ffa500;font-weight: 600;"><?php echo $tutors_details[0]['total_exp']; ?> Year Of Experience</p>
                  <p class="mb-0" style="color:#ffa500;font-weight: 600;">Rs. <span style="color:#314584;"><?php echo $tutors_details[0]['min_fee_range']; ?> to <?php echo $tutors_details[0]['max_fee_range']; ?>/<?php if($tutors_details[0]['fee_type'] == 1){ echo "Monthly"; }else if($tutors_details[0]['fee_type'] == 2){ echo "Hourly"; }else{ echo "Fixed"; }?></span></p> 
                  <?php if($this->session->userdata('conceptorz2022_web_email') != "" && $this->session->userdata('conceptorz2022_web_id') != ""){  ?>
                     <button class="btn mt-3" data-toggle="modal" data-target="#exampleModal" style="background: #ffa500;border-color: #ffa500;border-radius: 14px;padding: 8px 25px;color: white;">BOOK A FREE DEMO</button>
                  <?php }else{ ?>
                     <button class="btn mt-3" data-toggle="modal" data-target=".bd-mobile-modal-lg" style="background: #ffa500;border-color: #ffa500;border-radius: 14px;padding: 8px 25px;color: white;">BOOK A FREE DEMO</button>
                  <?php } ?>
               </div>
            </div>
         </div>
      </div>
      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog" role="document">
            <div class="modal-content" style="border: 4px solid #ffa500;border-radius: 20px;">
               <div class="modal-body">
                  <h3 class="pb-3 modal-title text-center" id="exampleModalLabel" style="color: #ffa500;">Book a Demo</h3>
                  <form method="post" autocomplete="off" id="skill_submit">
                  <div class="d-md-flex">
                     <div style="margin-right: 2rem!important;">
                        <img src="<?php echo $image; ?>" alt="" style="height: 85px;max-width: 100%;border-radius: 15px;margin-bottom: 10px;">
                     </div>
                     <div class="mt-auto mb-auto">
                        <h4 style="color: #314584;"><?php echo $tutors_details[0]['name']; ?></h4>
                        <div class="d-flex">
                           <?php echo $total_star; ?> <small style="color: #194880;font-weight: 500;"> (<?php echo $total_review; ?> Reviews)</small>
                        </div>
                        <p class="mb-2 mt-2" style="color:#ffa500;font-weight: 600;"><i class="fa fa-map-marker" style="color:#314584;"></i> <?php echo $city[0]['city_name']; ?>, <?php echo $state[0]['state_name']; ?>, <?php echo $country[0]['name']; ?></p>
                        <div class="mt-3">
                           <div class="form-group">
                              <label class="control-label" for="select_date">Select Skill:</label>
                              <select class="form-control" name="skill_id" required>
                                 <option value="" selected disabled>Select SKill</option>
                                 <?php foreach ($teachers_skills as $key => $value) {
                                       $curriculum1 = $this->qm->select_where('tbl_curriculum',array('_id'=>$value['curriculum_id']));
                                       $grade1 = $this->qm->select_where('tbl_grades',array('_id'=>$value['grade_id']));
                                       $board1 = $this->qm->select_where('tbl_board',array('_id'=>$value['board_id']));
                                       $language1 = $this->qm->select_where('tbl_language',array('_id'=>$value['language_id']));
                                 ?>
                                 <option value="<?php echo $value['_id']; ?>"><?php echo $board1[0]['name'].' - '.$grade1[0]['name'].' - '.$curriculum1[0]['name'].' - '.$language1[0]['name']; ?></option>
                                 <?php } ?>
                              </select>
                           </div>
                           <div class="form-group">
                              <label class="control-label" for="select_date">Select Date:</label>
                              <input type="text" id="select_date" name="select_date" class="form-control date1" placeholder="Select Date" required>
                           </div>
                           <div class="form-group">
                              <label class="control-label" for="booking_id">Select Timing:</label>
                              <select class="form-control" id="booking_id" name="booking_id" required>
                                 <option value="" selected disabled>Select Timing</option>
                              </select>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="text-right">
                     <button type="button" style="border-radius: 10px;" class="btn btn-secondary" data-dismiss="modal">Close</button>
                     <button type="submit" name="demosubmit" style="border-radius: 10px;background: #ffa500;border-color: #ffa500;" class="btn btn-primary">Book</button>
                  </div>
               </form>
               </div>
            </div>
         </div>
      </div>
      <div class="card mt-5" style="border-radius: 15px;">
         <div class="col-md-12 p-3">
            <div class="product-description-review mt-0">
               <!-- Product Description Tab Menu -->
               <ul class="nav nav-tabs desc-review-tab-menu" id="desc-review-tab" role="tablist">
                  <li>
                     <a class="active show" id="desc-tab" data-toggle="tab" href="#descriptionContent" role="tab" aria-selected="true">Profile Details</a>
                  </li>
                 <!--  <li>
                     <a id="classes-tab" data-toggle="tab" href="#classesContent" class="">Classes</a>
                  </li> -->
                  <li>
                     <a id="profile-tab" data-toggle="tab" href="#reviewContent" class="">Reviews</a>
                  </li>
               </ul>
               <div class="tab-content" id="myTabContent">
                  <div class="tab-pane fade active show" id="descriptionContent">
                     <div class="description-content">
                        <h6>Overview</h6>
                        <p class="m-0"><?php echo $tutors_details[0]['about_us']; ?></p>
                        <div class="row p-2">
                           <div class="col-md-3"></div>
                           <div class="col-md-6">
                              <?php if(!empty($video)){ ?>
                              <video controls="" poster="assets/img/video.png" style="width: 100%;height: 100%;border-radius: 25px;border: 3px solid orange;background: orange;">
                                 <source src="<?php echo $video; ?>" type="video/ogg">
                                 Your browser does not support the video tag.
                              </video>
                              <?php } ?>
                           </div>
                           <div class="col-md-3"></div>
                        </div>
                        <h6 class="pt-3">Skills</h6>
                        <table id="table_skill" class="table table-bordered table-hover" style="color:black;">
                           <thead>
                              <tr style="background: #194880;color: white;">
                                 <th>Board</th>
                                 <th>Grade</th>
                                 <th>Curriculum</th>
                                 <th>Language</th>
                              </tr>
                           </thead>
                           <tbody>
                              <?php if(isset($teachers_skills)){
                                 foreach ($teachers_skills as $key => $value) {
                                    $curriculum1 = $this->qm->select_where('tbl_curriculum',array('_id'=>$value['curriculum_id']));
                                    $grade1 = $this->qm->select_where('tbl_grades',array('_id'=>$value['grade_id']));
                                    $board1 = $this->qm->select_where('tbl_board',array('_id'=>$value['board_id']));
                                    $language1 = $this->qm->select_where('tbl_language',array('_id'=>$value['language_id']));
                              ?>
                              <tr>
                                 <td><?php echo $board1[0]['name']; ?></td>
                                 <td><?php echo $grade1[0]['name']; ?></td>
                                 <td><?php echo $curriculum1[0]['name']; ?></td>
                                 <td><?php echo $language1[0]['name']; ?></td>
                              </tr>
                              <?php }} ?>
                           </tbody>
                        </table>
                     </div>
                  </div>
                  <div class="tab-pane fade" id="classesContent">
                     <div class="classes-content">
                        <p class="m-0">Class List
                        </p>
                     </div>
                  </div>
                  <div class="tab-pane fade" id="reviewContent">
                     <div class="product-ratting-wrap">
                        <div class="pro-avg-ratting">
                           <h4><?php echo round($total_star12[0]['total'],2); ?> <span>(Overall)</span></h4>
                           <span>Based on <?php echo $total_review; ?> Comments</span>
                        </div>
                        <div class="rattings-wrapper">
                           <?php foreach ($review_list as $key => $value) { 
                              $student_data = $this->qm->select_where('tbl_students',array('_id' => $value['student_id']));
                              if($student_data[0]['image'])
                              {
                                 $image = IMAGE."student/".$student_data[0]['image'];
                              }else{
                                 $image = NO_USER;
                              }
                              $review_star = $this->qm->star_rating($value['rating']);
                           ?>
                           <div class="sin-rattings">
                              <div class="ratting-author">
                                 <h3><?php echo $student_data[0]['name']; ?></h3>
                                 <div class="ratting-star">
                                    <?php echo $review_star; ?>
                                 </div>
                              </div>
                              <p><?php echo $value['message']; ?></p>
                           </div>
                           <?php } ?>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<script type="text/javascript">
   $('#header-area').removeClass('fixed-top');
   $('#header-area').css('box-shadow','15px 0px 15px -10px rgba(0,0,0,0.75)');

$(function () {
  $('#select_date').change(function(){
   var id = $(this).val();   
   if(id){
    $.ajax({
     type:"POST",
     url:"<?php echo base_url('tutors/getbooktime'); ?>",
     data:{id:id},
     success:function(res){  
      if(res){
       var data = JSON.parse(res);
       $("#booking_id").empty();
       $("#booking_id").append('<option selected disabled value="">Select Timing</option>');
       $.each(data,function(key,value){
        $("#booking_id").append('<option value="'+value._id+'">'+value.start_time+' to '+value.end_time+'</option>');
      });
     }else{
       $("#booking_id").empty();
       $("#booking_id").append('<option selected disabled value="">Select Timing</option>');
     }
   }
 });
  }else{
    $("#booking_id").empty();
    $("#booking_id").append('<option selected disabled value="">Select Timing</option>');
  }      
});
});
</script>