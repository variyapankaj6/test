<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
   <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
   </ol>
   <div class="carousel-inner">
      <div class="carousel-item active" style="padding: 0px; ">
         <img class="d-block pt-5" src="<?php echo WEBASSETS; ?>assets/img/background.png" alt="First slide">
         <div class="carousel-caption d-md-block">
            <div class="row p-0">
               <div class="col-md-6 text-left">
                  <h1 style="font-weight: bolder;font-style: italic;color: #60beae;">Hire The Right<br>Tutor Now!</h1>
                  <p style="color:#6c757d;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.<br/>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.<br/></p>
                  <div class="text-right">
                     <button class="btn btn-primary" style="background: #ffc107;padding: 8px 10px;border-radius: 24px;border-color: #ffc107;font-size: 0.8rem;">Watch Video Now</button>
                  </div>
               </div>
               <div class="col-md-6">
                  <img class="d-block" src="<?php echo WEBASSETS; ?>assets/img/women.png" alt="First slide">
               </div>
            </div>
         </div>
      </div>
      <!-- <div class="carousel-item " style="padding: 0px; ">
         <img class="d-block pt-5" src="<?php echo WEBASSETS; ?>assets/img/background.png" alt="First slide">
         </div> -->
   </div>
   <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
   <span class="carousel-control-prev-icon" aria-hidden="true"></span>
   <span class="sr-only">Previous</span>
   </a>
   <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
   <span class="carousel-control-next-icon" aria-hidden="true"></span>
   <span class="sr-only">Next</span>
   </a>
</div>
<div class="w-100" style="background-color:#edf3fa;">
   <div class="container pb-5">
      <h2 class="pt-5 text-center" style="font-weight: bolder;font-style: italic;color: #ffc107;">TRUSTED <span style="color: #60beae;">BY</span></h2>
      <div class="col-md-12 mt-3">
         <div class="owl-carousel carousel-howwork">
            <div class="m-auto">
               <img src="<?php echo WEBASSETS; ?>assets/img/c1.png" style="height: 100px;width: auto;">
            </div>
            <div class="m-auto">
               <img src="<?php echo WEBASSETS; ?>assets/img/c2.png" style="height: 100px;width: auto;">
            </div>
            <div class="m-auto">
               <img src="<?php echo WEBASSETS; ?>assets/img/c3.png" style="height: 100px;width: auto;">
            </div>
            <div class="m-auto">
               <img src="<?php echo WEBASSETS; ?>assets/img/c2.png" style="height: 100px;width: auto;">
            </div>
            <div class="m-auto">
               <img src="<?php echo WEBASSETS; ?>assets/img/c4.png" style="height: 100px;width: auto;">
            </div>
         </div>
      </div>
   </div>
</div>
<div class="container w-100 pb-5">
   <div class="row">
      <div class="col-md-4 mt-5">
         <div class="row">
            <div class="col-md-6 pt-5 col-6">
               <div class="card mb-3">
                  <img src="<?php echo WEBASSETS; ?>assets/img/t1.png" class="card-img-top" style="width: 50%;margin: 10px auto;float: none;margin-bottom: 10px;" alt="...">
                  <div class="card-body text-center" style="padding: 0.25rem;">
                     <p class="mb-0">Physics</p>
                     <small class="m-0" style="color:black;">Some quick example text to build on the card title and make</small>
                  </div>
               </div>
               <div class="card mb-3">
                  <img src="<?php echo WEBASSETS; ?>assets/img/t1.png" class="card-img-top" style="width: 50%;margin: 10px auto;float: none;margin-bottom: 10px;" alt="...">
                  <div class="card-body text-center" style="padding: 0.25rem;">
                     <p class="mb-0">Physics</p>
                     <small class="m-0" style="color:black;">Some quick example text to build on the card title and make</small>
                  </div>
               </div>
            </div>
            <div class="col-md-6 col-6 m-auto">
               <div class="card mb-3">
                  <img src="<?php echo WEBASSETS; ?>assets/img/t1.png" class="card-img-top" style="width: 50%;margin: 10px auto;float: none;margin-bottom: 10px;" alt="...">
                  <div class="card-body text-center" style="padding: 0.25rem;">
                     <p class="mb-0">Physics</p>
                     <small class="m-0" style="color:black;">Some quick example text to build on the card title and make</small>
                  </div>
               </div>
               <div class="card mb-3">
                  <img src="<?php echo WEBASSETS; ?>assets/img/t1.png" class="card-img-top" style="width: 50%;margin: 10px auto;float: none;margin-bottom: 10px;" alt="...">
                  <div class="card-body text-center" style="padding: 0.25rem;">
                     <p class="mb-0">Physics</p>
                     <small class="m-0" style="color:black;">Some quick example text to build on the card title and make</small>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="col-md-4 text-center mt-auto mb-auto">
         <h2 style="font-weight: bolder;font-style: italic;color: #ffc107;">Top<br><span style="color: #60beae;">Couses</span></h2>
         <b style="color:black;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</b>
      </div>
      <div class="col-md-4 mt-5">
         <div class="row">
            <div class="col-md-6 pt-5 col-6">
               <div class="card mb-3">
                  <img src="<?php echo WEBASSETS; ?>assets/img/t1.png" class="card-img-top" style="width: 50%;margin: 10px auto;float: none;margin-bottom: 10px;" alt="...">
                  <div class="card-body text-center" style="padding: 0.25rem;">
                     <p class="mb-0">Physics</p>
                     <small class="m-0" style="color:black;">Some quick example text to build on the card title and make</small>
                  </div>
               </div>
               <div class="card mb-3">
                  <img src="<?php echo WEBASSETS; ?>assets/img/t1.png" class="card-img-top" style="width: 50%;margin: 10px auto;float: none;margin-bottom: 10px;" alt="...">
                  <div class="card-body text-center" style="padding: 0.25rem;">
                     <p class="mb-0">Physics</p>
                     <small class="m-0" style="color:black;">Some quick example text to build on the card title and make</small>
                  </div>
               </div>
            </div>
            <div class="col-md-6 col-6 m-auto">
               <div class="card mb-3">
                  <img src="<?php echo WEBASSETS; ?>assets/img/t1.png" class="card-img-top" style="width: 50%;margin: 10px auto;float: none;margin-bottom: 10px;" alt="...">
                  <div class="card-body text-center" style="padding: 0.25rem;">
                     <p class="mb-0">Physics</p>
                     <small class="m-0" style="color:black;">Some quick example text to build on the card title and make</small>
                  </div>
               </div>
               <div class="card mb-3">
                  <img src="<?php echo WEBASSETS; ?>assets/img/t1.png" class="card-img-top" style="width: 50%;margin: 10px auto;float: none;margin-bottom: 10px;" alt="...">
                  <div class="card-body text-center" style="padding: 0.25rem;">
                     <p class="mb-0">Physics</p>
                     <small class="m-0" style="color:black;">Some quick example text to build on the card title and make</small>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="container w-100 pb-5">
   <div class="row">
      <div class="col-md-6 m-auto">
         <img src="<?php echo WEBASSETS; ?>assets/img/z1.png" class="card-img-top" alt="...">
      </div>
      <div class="col-md-1 text-center"></div>
      <div class="col-md-5 text-center">
         <div class="d-flex mb-3">
            <div class="m-auto pr-3">
               <div style="background-color: #faaf3a;padding: 15px;border-radius: 50%;height: 80px;width: 80px;">
                  <img src="<?php echo WEBASSETS; ?>assets/img/z2.png" class="card-img-top" alt="...">
               </div>
            </div>
            <div class="text-left mt-auto mb-auto">
               <h4 class="mb-0" style="font-weight: bolder;font-style: italic;color: #faaf3a;">Learning</h4>
               <small class="m-0" style="color:black;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</small>
            </div>
         </div>
         <div class="d-flex mb-3">
            <div class="m-auto pr-3">
               <div style="background-color: #faaf3a;padding: 15px;border-radius: 50%;height: 80px;width: 80px;">
                  <img src="<?php echo WEBASSETS; ?>assets/img/z3.png" class="card-img-top" alt="...">
               </div>
            </div>
            <div class="text-left mt-auto mb-auto">
               <h4 class="mb-0" style="font-weight: bolder;font-style: italic;color: #faaf3a;">Learning</h4>
               <small class="m-0" style="color:black;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</small>
            </div>
         </div>
         <div class="d-flex mb-3">
            <div class="m-auto pr-3">
               <div style="background-color: #faaf3a;padding: 15px;border-radius: 50%;height: 80px;width: 80px;">
                  <img src="<?php echo WEBASSETS; ?>assets/img/z4.png" class="card-img-top" alt="...">
               </div>
            </div>
            <div class="text-left mt-auto mb-auto">
               <h4 class="mb-0" style="font-weight: bolder;font-style: italic;color: #faaf3a;">Learning</h4>
               <small class="m-0" style="color:black;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</small>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="container w-100 pb-3">
   <h2 class="text-center" style="font-weight: bolder;font-style: italic;color: #ffc107;">MEET OUR <span style="color: #60beae;">TOP TUTORS</span></h2>
</div>
<div class="w-100 mb-5" style="background-color:#ebedf5;">
   <div class="container pt-5 pb-5">
      <div class="col-md-12" >
         <div class="owl-carousel carousel-team">
            <?php foreach ($teachers as $key => $value) { 
               if($value['image'])
               {
                  $image = IMAGE."teacher/".$value['image'];
               }else{
                  $image = NO_USER;
               } 
               $state = $this->qm->select_where('tbl_state',array('_id' => $value['state_id']));
            ?>
            <div class="m-1" style="background:unset;">
               <div class="card-body text-center">
                  <div class="text-center m-auto">
                     <img src="<?php echo $image; ?>" style="height: 180px;width: 180px;border-radius: 50%;display: unset;">
                  </div>
                  <div class="p-2">
                     <p class="m-0" style="font-weight: 500;"><?php echo $value['name']; ?></p>
                     <small class="mb-1"><?php echo $value['total_exp']; ?> Year Of Experience</small>
                     <p style="font-weight: 500;"><?php echo $state[0]['state_name']; ?></p>
                     <a href="<?php echo base_url('tutors/view/').$value['_id']; ?>" class="btn" style="background: #f8f9fa;border-color: #f8f9fa;border-radius: 14px;padding: 8px 25px;">View Profile</a>
                  </div>
               </div>
            </div>
            <?php } ?>
         </div>
      </div>
   </div>
</div>
<div class="container w-100 pt-5 pb-5">
   <div class="row">
      <div class="col-md-5 mt-auto mb-auto">
         <div class="text-left mt-auto mb-auto">
            <h2 style="font-weight: bolder;font-style: italic;color: #ffc107;">FOR <span style="color: #60beae;">STUDENT</span></h2>
            <p class="m-0" style="color:black;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            <a href="<?php echo base_url('tutors'); ?>" class="btn mt-3" style="background: #faaf3a;border-color: #faaf3a;border-radius: 14px;padding: 8px 25px;color: white;">EXPLORE</a>
         </div>
      </div>
      <div class="col-md-2 text-center"></div>
      <div class="col-md-5 m-auto">
         <img src="<?php echo WEBASSETS; ?>assets/img/STUDENT JUMP.png" class="card-img-top" alt="...">
      </div>
   </div>
</div>
<div class="container w-100 pb-5">
   <div class="row">
      <div class="col-md-5 m-auto">
         <img src="<?php echo WEBASSETS; ?>assets/img/TEACHER BOARD.png" class="card-img-top" alt="...">
      </div>
      <div class="col-md-2 text-center"></div>
      <div class="col-md-5 mt-auto mb-auto">
         <div class="text-left mt-auto mb-auto">
            <h2 style="font-weight: bolder;font-style: italic;color: #ffc107;">FOR <span style="color: #60beae;">TEACHER</span></h2>
            <p class="m-0" style="color:black;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            <a href="<?php echo base_url('tutors'); ?>" class="btn mt-3" style="background: #faaf3a;border-color: #faaf3a;border-radius: 14px;padding: 8px 25px;color: white;">EXPLORE</a>
         </div>
      </div>
   </div>
</div>
<div class="container text-center w-100 pb-5">
   <h2 class="text-center" style="font-weight: bolder;font-style: italic;color: #ffc107;">HOW IT <span style="color: #60beae;">WORKS</span></h2>
   <p class="m-0 text-center" style="color:black;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
   <a href="<?php echo base_url('tutors'); ?>" class="btn mt-3 " style="background: #faaf3a;border-color: #faaf3a;border-radius: 14px;padding: 8px 25px;color: white;">EXPLORE</a>
</div>
<div class="text-center w-100" style="background:url('assets/img/Layer 2 (1).png');background-size: contain;background-repeat: no-repeat;background-position: center;">
   <div class="container">
      <div class="row">
         <div class="col-md-4">
            <div class="text-center">
               <img src="<?php echo WEBASSETS; ?>assets/img/online-course-2.png" style="height: 130px;background-color: #faaf3a;padding: 30px 28px;border-radius: 15px;margin: 10px;box-shadow: 0 0 6px 2px rgb(0 0 0 / 48%);" alt="...">
               <h4 style="color: #314584;">Select Your <br/>Course</h4>
            </div>
         </div>
         <div class="col-md-4">
            <div class="text-center">
               <img src="<?php echo WEBASSETS; ?>assets/img/tutor.png" style="height: 130px;background-color: #faaf3a;padding: 30px 28px;border-radius: 15px;margin: 10px;box-shadow: 0 0 6px 2px rgb(0 0 0 / 48%);" alt="...">
               <h4 style="color: #314584;">Find The <br/>Right Tutor</h4>
            </div>
         </div>
         <div class="col-md-4">
            <div class="text-center">
               <img src="<?php echo WEBASSETS; ?>assets/img/class.png" style="height: 130px;background-color: #faaf3a;padding: 30px 28px;border-radius: 15px;margin: 10px;box-shadow: 0 0 6px 2px rgb(0 0 0 / 48%);" alt="...">
               <h4 style="color: #314584;">Book Your <br/>Demo</h4>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="container text-center w-100 pt-5 pb-5">
   <div class="row">
      <div class="col-3 text-center">
         <div class="mb-3">
            <img src="<?php echo WEBASSETS; ?>assets/img/student-with-graduation-cap.png" class="card-img-top" style="height: 50px;width: 50px;" alt="...">
            <h5 style="color: #314584;">10000+ <br/>Students</h5>
         </div>
      </div>
      <div class="col-3"></div>
      <div class="col-3"></div>
      <div class="col-3 text-center">
         <div class="mb-3">
            <img src="<?php echo WEBASSETS; ?>assets/img/clock.png" class="card-img-top" style="height: 50px;width: 50px;" alt="...">
            <h5 style="color: #314584;">1M+ <br/>Teaching Hrs</h5>
         </div>
      </div>
      <div class="col-md-3"></div>
      <div class="col-md-6 text-center mt-auto mb-auto">
         <h2 style="font-weight: bolder;font-style: italic;color: #ffc107;">Our<br><span style="color: #60beae;">ACHIEVEMENTS</span></h2>
         <b style="color:black;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</b>
      </div>
      <div class="col-md-3"></div>
      <div class="col-3 text-center">
         <div class="mt-3">
            <img src="<?php echo WEBASSETS; ?>assets/img/class.png" class="card-img-top" style="height: 50px;width: 50px;" alt="...">
            <h5 style="color: #314584;">150+ <br/>Tutors</h5>
         </div>
      </div>
      <div class="col-3"></div>
      <div class="col-3"></div>
      <div class="col-3 text-center">
         <div class="mt-3">
            <img src="<?php echo WEBASSETS; ?>assets/img/online-course.png" class="card-img-top" style="height: 50px;width: 50px;" alt="...">
            <h5 style="color: #314584;">100+ <br/>Courses</h5>
         </div>
      </div>
      <div class="col-md-3"></div>
   </div>
</div>
<div class="container w-100 pb-5">
   <div class="row">
      <div class="col-md-6 mt-auto mb-auto">
         <div class="text-left mt-auto mb-auto">
            <h2 style="font-weight: bolder;font-style: italic;color: #ffc107;">ABOUT <span style="color: #60beae;">CONCEPTORZ</span></h2>
            <p class="m-0" style="color:black;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            <p class="mb-2" style="color:black;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
         </div>
      </div>
      <div class="col-md-6 m-auto">
         <img src="<?php echo WEBASSETS; ?>assets/img/image (10).png" class="card-img-top" alt="...">
      </div>
   </div>
</div>
<div class="container w-100 pb-5">
   <div class="owl-carousel carousel-materials">
      <?php foreach ($teachers_rating as $key => $value) { 
         $student_data = $this->qm->select_where('tbl_students',array('_id' => $value['student_id']));
         if($student_data[0]['image'])
         {
            $image = IMAGE."student/".$student_data[0]['image'];
         }else{
            $image = NO_USER;
         }
         $review_star = $this->qm->star_rating($value['rating']);
      ?>
      <div class="card m-3">
         <div class="card-body text-center pt-2 pb-2" style="background: #e9e9e9;border-radius: 10px;">
            <img src="<?php echo WEBASSETS; ?>assets/img/user.jpg" alt="Vikas Jain" class="img-fluid" style="height: 110px;width: 110px;display: unset;border-radius: 50%;padding-top: -20px;position: relative;margin-top: -17px;">
            <div class="p-3" style="display: flex;justify-content: space-between;">
               <?php echo $review_star; ?>
            </div>
            <h5 style="font-weight: 600;color: unset;"><?php echo $student_data[0]['name']; ?></h5>
            <div style="background: #ddd8d8;border-radius: 10px;padding: 10px;margin: 10px 0px;height: 111px;overflow: hidden;font-size: 0.8rem;"><?php echo $value['message']; ?></div>
         </div>
      </div>
      <?php } ?>
   </div>
</div>