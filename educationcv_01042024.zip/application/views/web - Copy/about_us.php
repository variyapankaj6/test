<div class="container pt-5 pb-5">
   <div class="row">
      <div class="col-md-6 mt-auto mb-auto">
         <div class="text-left mt-auto mb-auto">
            <h2 style="font-weight: bolder;font-style: italic;color: #ffc107;">ABOUT <span style="color: #60beae;">CONCEPTORZ</span></h2>
            <p class="m-0" style="color:black;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            <p class="mb-2" style="color:black;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
         </div>
      </div>
      <div class="col-md-6 m-auto">
         <img src="<?php echo WEBASSETS; ?>assets/img/image (10).png" class="card-img-top" alt="...">
      </div>
      <div class="col-md-12 m-auto">
         <p class="m-0" style="color:black;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
         <p class="mb-2" style="color:black;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
      </div>
   </div>
</div>
<script type="text/javascript">
   $('#header-area').removeClass('fixed-top');
   $('#header-area').css('box-shadow','15px 0px 15px -10px rgba(0,0,0,0.75)');
</script>