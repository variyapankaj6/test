<style type="text/css">
   .subjectbox{
      color: black;
      border-radius: 16px;
      padding: 4px 10px;
      font-size: 0.8rem;
      margin-right: 3px;
      border: 2px solid #74c5b7;
   }
   
   .subjectbox1{
      color: white;
      border-radius: 16px;
      padding: 4px 10px;
      font-size: 0.8rem;
      margin-right: 3px;
      border: 1px solid white;
      background-color: #0000009e;
   }
   .subjectbox1:hover{
      background: #74c5b7;
      color: white;
   }
   .card-img-overlay {
       top: 40%;
       bottom: 30%;
   }
   .page-pagination ul li a {
      line-height: unset;
   }
   .page-item.active .page-link {
      background-color: #74c5b7;
      border-color: #74c5b7;
   }
</style>
<div class="container pt-4 pb-5">
   <div class="col-md-12 pt-5 pb-5">
      <div class="row">
         <div class="col-md-10">
            <div class="row" style="box-shadow: 0 0 6px 2px rgb(0 0 0 / 10%); border-radius: 15px;">
               <div class="col-md-3 m-auto" style="border-right: 1px solid darkgrey;">
                  <div class="form-group" style="margin-top: 1rem;">
                     <select class="form-control" id="board_id" style="background: white;">
                        <option value="" selected disabled>Select Board</option>
                        <?php foreach ($board_list as $key) { ?>
                           <option <?php if(isset($fil_board)){ if($key['_id'] == $fil_board){ echo "selected";}} ?> value="<?php echo $key['_id']; ?>"><?php echo $key['name']; ?></option>
                        <?php } ?>
                     </select>
                  </div>
               </div>
               <div class="col-md-3 m-auto" style="border-right: 1px solid darkgrey;">
                  <div class="form-group" style="margin-top: 1rem;">
                     <select class="form-control" id="grade_id" style="background: white;">
                        <option value="" selected disabled>Select Grade</option>
                        <?php foreach ($grade_list as $key) { ?>
                           <option <?php if(isset($fil_grade)){ if($key['_id'] == $fil_grade){ echo "selected";}} ?> value="<?php echo $key['_id']; ?>"><?php echo $key['name']; ?></option>
                        <?php } ?>
                     </select>
                  </div>
               </div>
               <div class="col-md-3 m-auto" style="border-right: 1px solid darkgrey;">
                  <div class="form-group" style="margin-top: 1rem;">
                     <select class="form-control" id="curriculum_id" style="background: white;">
                        <option value="" selected disabled>Select Curriculum</option>
                        <?php foreach ($curriculum_list as $key) { ?>
                           <option <?php if(isset($fil_curriculum)){ if($key['_id'] == $fil_curriculum){ echo "selected";}} ?> value="<?php echo $key['_id']; ?>"><?php echo $key['name']; ?></option>
                        <?php } ?>
                     </select>
                  </div>
               </div>
               <div class="col-md-3 m-auto">
                  <select class="form-control" id="language_id" style="background: white;">
                     <option value="" selected disabled>Select Language</option>
                     <?php foreach ($language_list as $key) { ?>
                        <option <?php if(isset($fil_language)){ if($key['_id'] == $fil_language){ echo "selected";}} ?> value="<?php echo $key['_id']; ?>"><?php echo $key['name']; ?></option>
                     <?php } ?>
                  </select>
               </div>
            </div>
         </div>
         <div class="col-md-2">
            <div class="form-group" style="margin-top: 1rem;">
               <button class="btn btn-block filter_now" style="border-radius:10px;background-color: #60beae;border-color: #60beae;color: #fff;">SEARCH</button>
            </div>
         </div>
      </div>
   </div>
   <div class="col-md-12">
      <div class="row">
         <?php if(empty($tutorslist)){ ?>
            <div class="col-md-12 text-center pt-5 pb-5">
               <h2 class="pt-5 pb-5" style="font-weight:400;">Data not found.</h2>
            </div>
         <?php } ?>
         <?php 
            foreach ($tutorslist as $val => $key) {
               if($key->image)
               {
                  $image = IMAGE."teacher/".$key->image;
               }else{
                  $image = NO_USER;
               } 
               $state = $this->qm->select_where('tbl_state',array('_id' => $key->state_id));
               $city = $this->qm->select_where('tbl_city',array('_id' => $key->city_id));
               $total_review = $this->qm->num_row('tbl_teachers_rating',array('teacher_id' => $key->_id,'status'=>1));
               $total_star = $this->db->query('SELECT avg(`rating`) as total FROM tbl_teachers_rating WHERE status = 1 AND teacher_id = '.$key->_id)->result_array();
               $total_star1 = $this->qm->star_rating($total_star[0]['total']);
               $skills = $this->db->query('SELECT * FROM tbl_teachers_skills WHERE status = 1 AND teacher_id = '.$key->_id.' limit 3')->result_array();
            ?>
         <div class="col-md-4 pb-3">
            <div class="card" style="background: #fff;border-radius: 40px;">
               <img class="card-img-top" src="<?php echo $image; ?>" alt="<?php echo $key->name; ?>" style="border-radius: 40px;background: #e6e7e2;">
               <div class="card-img-overlay">
                  <button class="btn subjectbox1 mb-3" style="background: #74c5b7;border: unset;border-radius: 0px 20px 20px 0px; position: relative;left: -25px;text-align: left;"><?php echo $key->name; ?><br/><?php if(!empty($state) && !empty($city)){ echo $city[0]['city_name'].','.$state[0]['state_name']; } ?></button>
                  <div style="display: flex;justify-content: space-between;">
                     <?php foreach ($skills as $key1) { 
                        $board_name = $this->qm->select_where('tbl_board',array('_id' => $key1['board_id']));
                     ?>
                        <a href="<?php echo base_url('tutors?&board=').$key1['board_id'];?>" class="btn subjectbox1"><?php echo $board_name[0]['name']; ?></a>
                     <?php } ?>
                  </div>
               </div>
               <div class="card-body">
                  <p style="color: #194880;font-weight: 500;"><?php echo $total_star1; ?> (<?php echo $total_review; ?> Reviews) Teachers</p>
                  <div style="color:#194880;height: 46px;overflow: hidden;margin-bottom: 15px;"><?php echo $key->about_us; ?></div>
                  <div style="display: flex;justify-content: space-between;">
                     <a href="<?php echo base_url('tutors/view/').$key->_id; ?>" class="btn subjectbox">Rs. <?php echo $key->min_fee_range; ?> to <?php echo $key->max_fee_range; ?>/<?php if($key->fee_type == 1){ echo "Monthly"; }else if($key->fee_type == 2){ echo "Hourly"; }else{ echo "Fixed"; }?></a>
                     <a href="<?php echo base_url('tutors/view/').$key->_id; ?>" class="btn" style="color: white;border-radius: 16px;padding: 4px 10px;font-size: 0.8rem;margin-right: 3px;border: 2px solid #74c5b7;background: #74c5b7;">Buy Now</a>
                  </div>
               </div>
            </div>
         </div>
         <?php } ?>
         <div class="col-md-12 item3">
            <div class="row mb-5">
               <div class="col-md-12">
                  <div class="page-pagination-wrapper mt-20 mt-md-20 mt-sm-20">
                     <nav class="page-pagination">
                        <ul class="pagination justify-content-center">
                           <?php echo $links; ?>
                        </ul>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<script type="text/javascript">
   $('#header-area').removeClass('fixed-top');
   $('#header-area').css('box-shadow','15px 0px 15px -10px rgba(0,0,0,0.75)');
</script>
<script type="text/javascript">
   $(".filter_now").click(function(){
       var url = '<?php echo base_url('tutors'); ?>?';
       var board = $('#board_id').val();
       if(board != null)
       {
           url += '&board='+board
       }
       var grade = $('#grade_id').val();
       if(grade != null)
       {
           url += '&grade='+grade
       }
       var curriculum = $('#curriculum_id').val();
       if(curriculum != null)
       {
           url += '&curriculum='+curriculum
       }
       var language = $('#language_id').val();
       if(language != null)
       {
           url += '&language='+language
       }
       if(board != null || curriculum != null || grade != null || language != null)
       {
          window.location.href = url;
       }else{
         toastr.error('Select Filter First.');
       }
   });
</script>