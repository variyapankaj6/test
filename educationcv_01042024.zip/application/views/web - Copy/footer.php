<footer class="pt-5 footer footer_color" style="background-color: #194880;">
   <div class="container text-center pb-5 text-md-left">
      <div class="row">
         <hr class="clearfix w-100 d-md-none">
         <div class="col-md-12">
            <div class="row">
               <div class="col-md-3 mx-auto">
                  <a href="index.html">
                  <img src="<?php echo WEBASSETS; ?>assets/img/L.png" alt="Logo" style="width: 200px;max-width: 100%;"/>
                  </a>
                  <p class="pt-3" style="color:#fff;">Lorem Ipsum is simply dummy text of the printing and typesetting
                     industry. Lorem Ipsum has been the
                  </p>
                  <div style="display: flex;justify-content: space-between;">
                     <a href="index.html"><img src="<?php echo WEBASSETS; ?>assets/img/F.png" alt="Logo"
                        style="height: 30px;max-width: 100%;"/></a>
                     <a href="index.html"><img src="<?php echo WEBASSETS; ?>assets/img/I.png" alt="Logo"
                        style="height: 30px;max-width: 100%;"/></a>
                     <a href="index.html"><img src="<?php echo WEBASSETS; ?>assets/img/T.png" alt="Logo"
                        style="height: 30px;max-width: 100%;"/></a>
                     <a href="index.html"><img src="<?php echo WEBASSETS; ?>assets/img/Y.png" alt="Logo"
                        style="height: 30px;max-width: 100%;"/></a>
                  </div>
               </div>
               <hr class="clearfix w-100 d-md-none">
               <div class="col-md-3 mx-auto" style="line-height: 30px;">
                  <h6 class="mt-5 mb-4" style="color:#4aa3c5;font-weight: 500;">HELPFUL LINKS</h6>
                  <ul class="list-unstyled">
                     <li>
                        <a class="footer_color footer-text" href="#!">Why Online School?</a>
                     </li>
                     <li>
                        <a class="footer_color footer-text" href="#!">Home Schooling In India</a>
                     </li>
                     <li>
                        <a class="footer_color footer-text" href="#!">Summer School Program</a>
                     </li>
                     <li>
                        <a class="footer_color footer-text" href="#!">Skill Based Program</a>
                     </li>
                     <li>
                        <a class="footer_color footer-text" href="#!">FAQ</a>
                     </li>
                  </ul>
               </div>
               <hr class="clearfix w-100 d-md-none">
               <div class="col-md-3 mx-auto" style="line-height: 30px;">
                  <h6 class=" mt-5 mb-4" style="color:#4aa3c5;font-weight: 500;">DISCOVER</h6>
                  <ul class="list-unstyled">
                     <li>
                        <a class="footer_color footer-text" href="#!">21K Group</a>
                     </li>
                     <li>
                        <a class="footer_color footer-text" href="#!">Our Partners</a>
                     </li>
                     <li>
                        <a class="footer_color footer-text" href="#!">Our Accereditations</a>
                     </li>
                     <li>
                        <a class="footer_color footer-text" href="#!">Founding Team</a>
                     </li>
                     <li>
                        <a class="footer_color footer-text" href="#!">What Sets Us Apart?</a>
                     </li>
                  </ul>
               </div>
               <hr class="clearfix w-100 d-md-none">
               <div class="col-md-3 mx-auto" style="line-height: 30px;">
                  <h6 class=" mt-5 mb-4" style="color:#4aa3c5;font-weight: 500;">INFO FOR</h6>
                  <ul class="list-unstyled">
                     <li>
                        <a class="footer_color footer-text" href="#!">How To Enroll?</a>
                     </li>
                     <li>
                        <a class="footer_color footer-text" href="#!">Who Should Enroll</a>
                     </li>
                     <li>
                        <a class="footer_color footer-text" href="#!">Batch Timings</a>
                     </li>
                     <li>
                        <a class="footer_color footer-text" href="#!">Frees</a>
                     </li>
                     <li>
                        <a class="footer_color footer-text" href="#!">Parent Testimonials</a>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="pb-5" style="background:#faaf3a;">
   </div>
</footer>
<!-- <script src="<?php echo WEBASSETS; ?>assets/js/vendor/jquery-3.3.1.min.js"></script> -->
<script src="<?php echo WEBASSETS; ?>assets/js/vendor/bootstrap.min.js"></script>
<script src="<?php echo WEBASSETS; ?>assets/js/plugins.js"></script>
<script src="<?php echo WEBASSETS; ?>assets/js/active.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.css">
<script type="text/javascript">
   $('.date').datepicker({format: 'dd-mm-yyyy'});
   $('.date1').datepicker({
       format: 'dd-mm-yyyy',
       startDate: new Date()
   });
   $('.date2').datepicker({
       format: 'dd-mm-yyyy',
       endDate: new Date()
   });
   // Default Configuration
   $(document).ready(function() {
    toastr.options = {
      'closeButton': true,
      'debug': false,
      'newestOnTop': false,
      'progressBar': false,
      'positionClass': 'toast-top-right',
      'preventDuplicates': false,
      'showDuration': '1000',
      'hideDuration': '1000',
      'timeOut': '5000',
      'extendedTimeOut': '1000',
      'showEasing': 'swing',
      'hideEasing': 'linear',
      'showMethod': 'fadeIn',
      'hideMethod': 'fadeOut',
    }
   });
   
   var error = "<?php echo $this->session->flashdata('error'); ?>";
   var success = "<?php echo $this->session->flashdata('success'); ?>";
   if(error != ''){
    toastr.error(error);
   }
   if(success != ''){
    toastr.success(success);
   }
</script>
<script>
   $('.carousel-howwork').owlCarousel({
       // loop: true,
       autoplayTimeout: 1500,
       margin: 0,
       nav: false,
       dots: false,
       navText: ['<span class="fa fa-chevron-left"></span>',
           '<span class="fa fa-chevron-right"></span>'
       ],
       responsive: {
           0: {
               items: 2
           },
           600: {
               items: 5
           },
           1000: {
               items: 5
           }
       }
   })
   $('.carousel-team').owlCarousel({
       // loop: true,
       autoplayTimeout: 1500,
       margin: 20,
       nav: true,
       dots: false,
       navText: ['<span class="fa fa-chevron-left"></span>',
           '<span class="fa fa-chevron-right"></span>'
       ],
       responsive: {
           0: {
               items: 1.5,
               margin: 10,
           },
           600: {
               items: 1.5
           },
           1000: {
               items: 4
           }
       }
   })
   $('.carousel-materials').owlCarousel({
       // loop: true,
       autoplayTimeout: 1500,
       margin: 10,
       nav: true,
       dots: false,
       navText: ['<span class="fa fa-chevron-left"></span>',
           '<span class="fa fa-chevron-right"></span>'
       ],
       responsive: {
           0: {
               items: 1.5
           },
           600: {
               items: 3
           },
           1000: {
               items: 3
           }
       }
   })
</script>
<script>
   $(document).ready(function(){
       $("#testimonial-slider").owlCarousel({
           items:1,
           itemsDesktop:[1000,1],
           itemsDesktopSmall:[979,1],
           itemsTablet:[768,1],
           pagination:true,
           navigation:false,
           navigationText:["",""],
           slideSpeed:1000,
           autoPlay:true
       });
   });
</script>
<script>
   $("document").ready(function () {
       $(".tab-slider--body").hide();
       $(".tab-slider--body:first").show();
   });
   
   $(".tab-slider--nav li").click(function () {
       $(".tab-slider--body").hide();
       var activeTab = $(this).attr("rel");
       $("#" + activeTab).fadeIn();
       if ($(this).attr("rel") == "tab2") {
           $('.tab-slider--tabs').addClass('slide');
       } else {
           $('.tab-slider--tabs').removeClass('slide');
       }
       $(".tab-slider--nav li").removeClass("active");
       $(this).addClass("active");
   });
</script>
</body>
</html>