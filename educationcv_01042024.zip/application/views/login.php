<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title>Educationcv</title>
    <link rel="icon" type="image/x-icon" href="<?php echo MAINLOGO; ?>"/>
    <link rel="shortcut icon" href="<?php echo MAINLOGO; ?>" type="image/x-icon">
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="<?php echo CSS; ?>loader.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Josefin+Sans" />
    <link href="<?php echo BCSS; ?>bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo CSS; ?>plugins.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo CSS; ?>users/login-2.css" rel="stylesheet" type="text/css" />  
</head>
<style type="text/css">
html *
{
   font-family: 'Inter','Helvetica Neue','Helvetica',sans-serif;
}
</style>
<body class="login">
    <div id="eq-loader">
      <div class="eq-loader-div">
          <div class="eq-loading dual-loader mx-auto mb-5"></div>
      </div>
    </div>
    <form class="form-login" method="post" autocomplete="off">
        <div class="row">
            <div class="col-md-12 text-center mb-4"> 
                <!-- <h1>Conceptorz</h1> -->
                <img alt="logo" src="<?php echo MAINLOGO; ?>" class="theme-logo" style="max-width: 100%;">
            </div>
            <div class="col-md-12">
                <?php if(isset($error)) { echo $error."<br/>"; } ?>

                <label for="inputEmail" class="sr-only">Email address</label>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="icon-inputEmail"><i class="flaticon-user-7"></i> </span>
                    </div>
                    <input type="email" id="inputEmail" name="admin"  class="form-control" placeholder="Email Address" aria-describedby="inputEmail" required >
                </div>

                <label for="inputPassword" class="sr-only">Password</label>                
                <div class="input-group mb-4">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="icon-inputPassword"><i class="flaticon-key-2"></i> </span>
                    </div>
                    <input type="password" name="pass"  id="inputPassword" class="form-control" placeholder="Password" aria-describedby="inputPassword" required >
                </div>
                <button class="btn btn-lg btn-gradient-warning btn-block btn-rounded mb-4 mt-5" type="submit" name="login">Login</button>
            </div>
        </div>
    </form>   
    <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
    <script src="<?php echo JS; ?>libs/jquery-3.1.1.min.js"></script>
    <script src="<?php echo JS; ?>loader.js"></script>
    <script src="<?php echo BJS; ?>popper.min.js"></script>
    <script src="<?php echo BJS; ?>bootstrap.min.js"></script>
    <!-- END GLOBAL MANDATORY SCRIPTS -->
</body>
</html>