<?php 
$config = array(
    'protocol' => 'smtp',
    'smtp_host' => '', 
    'smtp_port' => 465,
    'smtp_user' => '',
    'smtp_pass' => '',
    'smtp_crypto' => 'ssl',
    'mailtype' => 'html',
    'smtp_timeout' => '4', 
    'charset' => 'iso-8859-1',
    'wordwrap' => TRUE
);
?>