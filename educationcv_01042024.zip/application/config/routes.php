<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Home';
$route['404_override'] = 'My404';
$route['translate_uri_dashes'] = FALSE;

$route['register'] = 'Login/register';

$route['about_us'] = 'About_us';
$route['faqs'] = 'About_us/faqs';
$route['privacy_policy'] = 'About_us/privacy_policy';
$route['terms_and_conditions'] = 'About_us/terms_and_conditions';

$route['admin'] = 'Admin';
$route['admin/dashboard'] = 'Admin/dashboard';
$route['admin/change_pswd'] = 'Admin/change_pswd';
$route['admin/logout'] = 'Admin/logout';

$route['changepassword'] = 'Changepassword';

$route['comments'] = 'Comments';
$route['comments/getLists'] = 'Comments/getLists';

$route['contact_us'] = 'Contact_us';

$route['dashboard'] = 'Dashboard';

$route['discover'] = 'Discover/index';
$route['discover/view/(:num)'] = 'Discover/view/$1';

$route['followers'] = 'Followers';
$route['followers/getLists_following'] = 'Followers/getLists_following';
$route['followers/getLists'] = 'Followers/getLists';
$route['following'] = 'Followers/following';

$route['home'] = 'Home';

$route['login'] = 'Login';
$route['login/register'] = 'Login/register';
$route['login/logout'] = 'Login/logout';


$route['profile'] = 'Profile';
$route['profile/delete_education_experience'] = 'Profile/delete_education_experience';
$route['profile/education_experience'] = 'Profile/education_experience';
$route['profile/delete_education_training'] = 'Profile/delete_education_training';
$route['profile/education_training'] = 'Profile/education_training';
$route['profile/delete_graduate_certificate'] = 'Profile/delete_graduate_certificate';
$route['profile/graduate_certificate'] = 'Profile/graduate_certificate';
$route['profile/delete_websites'] = 'Profile/delete_websites';
$route['profile/delete_non_award_program'] = 'Profile/delete_non_award_program';
$route['profile/programs_websites'] = 'Profile/programs_websites';


$route['sup_admin/cms_pages'] = 'sup_admin/Cms_pages';
$route['sup_admin/cms_pages/getLists'] = 'sup_admin/Cms_pages/getLists';
$route['sup_admin/cms_pages/add_cms_pages'] = 'sup_admin/Cms_pages/add_cms_pages';
$route['sup_admin/cms_pages/delete'] = 'sup_admin/Cms_pages/delete';

$route['sup_admin/contactus'] = 'sup_admin/Contactus';
$route['sup_admin/contactus/getLists'] = 'sup_admin/Contactus/getLists';
$route['sup_admin/contactus/delete'] = 'sup_admin/Contactus/delete';

$route['sup_admin/dashboard'] = 'sup_admin/Dashboard';

$route['sup_admin/registers'] = 'sup_admin/Registers';
$route['sup_admin/registers/active_deactive'] = 'sup_admin/Registers/active_deactive';
$route['sup_admin/registers/active_suspend'] = 'sup_admin/Registers/active_suspend';
$route['sup_admin/registers/getLists'] = 'sup_admin/Registers/getLists';
$route['sup_admin/registers/delete'] = 'sup_admin/Registers/delete';

$route['(:any)'] = 'Discover/view_main/$1';