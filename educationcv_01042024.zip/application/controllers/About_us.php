<?php defined('BASEPATH') OR exit('No direct script access allowed');
class About_us extends CI_Controller {

	public function __construct(){	
		parent::__construct();
		$this->load->model('Query_model','qm',TRUE);
	}
	
	public function index(){
		$this->load->view('web/header');
		$this->load->view('web/about_us');
		$this->load->view('web/footer');
	}

	public function faqs(){
		$this->load->view('web/header');
		$this->load->view('web/faqs');
		$this->load->view('web/footer');
	}

	public function privacy_policy(){
		$this->load->view('web/header');
		$this->load->view('web/privacy_policy');
		$this->load->view('web/footer');
	}

	public function terms_and_conditions(){
		$this->load->view('web/header');
		$this->load->view('web/terms_and_conditions');
		$this->load->view('web/footer');
	}
}