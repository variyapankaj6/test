<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Profile extends CI_Controller {

	public function __construct(){	
		parent::__construct();
		$this->load->model('security_model');
        $this->load->library('form_validation');
		$this->security_model->is_logged_in_web();
		$this->load->model('query_model','qm',TRUE);
	}
	
	public function index(){
        $user_id = $this->session->userdata('educationcv_web_id');
		if (isset($_POST['submit'])) {
            $this->form_validation->set_rules('name', 'Name', 'required|max_length[100]');
            $this->form_validation->set_rules('mobile_no', 'Mobile Number', 'required|numeric|min_length[10]|max_length[15]');
            $this->form_validation->set_rules('profession', 'Profession', 'required|max_length[50]');
            $this->form_validation->set_rules('location', 'Location', 'required|max_length[100]');
            $this->form_validation->set_rules('about_us', 'About Us', 'required|max_length[1000]');
            $this->form_validation->set_rules('facebook_link', 'Facebook Link', 'valid_url');
            $this->form_validation->set_rules('twitter_link', 'Twitter Link', 'valid_url');
            $this->form_validation->set_rules('instagram_link', 'Instagram Link', 'valid_url');
            $this->form_validation->set_rules('linkedin_link', 'LinkedIn Link', 'valid_url');
            $this->form_validation->set_rules('youtube_link', 'YouTube Link', 'valid_url');
            $this->form_validation->set_rules('pinterest_link', 'Pinterest Link', 'valid_url');
            $this->form_validation->set_rules('snapchat_link', 'Snapchat Link', 'valid_url');
            $this->form_validation->set_rules('whatsapp_link', 'WhatsApp Link', 'valid_url');
            $this->form_validation->set_rules('threads_link', 'Threads Link', 'valid_url');
            $this->form_validation->set_rules('tiktok_link', 'Tiktok Link', 'valid_url');
            $this->form_validation->set_rules('others_link', 'Others Link', 'valid_url');
            if ($this->form_validation->run() === false) {
                $this->session->set_flashdata('error', validation_errors());
                $this->session->set_flashdata('post_error', $_POST);
                redirect('profile');
            }else{
                date_default_timezone_set('Asia/Kolkata');
                if (isset($_FILES['photo']['name']) && ($_FILES['photo']['name']) != "") {
                    $data['tbl'] = 'tbl_register';
                    $data['select_field'] = 'photo';
                    $data['where_field'] = "_id='".$user_id."'";
                    $imgpath = 'images/user';
                    $data['img_path'] = glob($imgpath.'*');
                    $this->qm->delete_img($data);

                    $type = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
                    $photo = rand(1111, 9999) . time() . "." . $type;
                    $config['file_name'] = $photo;
                    $config['upload_path'] = "images/user/";
                    $config['allowed_types'] = "jpg|jpeg|png";
                    $this->upload->initialize($config);
                    $this->upload->do_upload('photo');
                    $post_data['photo'] = $photo;
                }
                $post_data['name'] = ucfirst($_POST['name']);
                $post_data['mobile_no'] = $_POST['mobile_no'];
                $post_data['profession'] = $_POST['profession'];
                $post_data['location'] = $_POST['location'];
                $post_data['about_us'] = $_POST['about_us'];
                $post_data['modified_at'] = date('Y-m-d H:i:s');
                $this->qm->updt('tbl_register', $post_data,array('_id' => $user_id));

                $social['faceboook_link'] = !empty($_POST['faceboook_link']) ? $_POST['faceboook_link'] : null; 
                $social['twitter_link'] = !empty($_POST['twitter_link']) ? $_POST['twitter_link'] : null; 
                $social['instagram_link'] = !empty($_POST['instagram_link']) ? $_POST['instagram_link'] : null; 
                $social['linkedin_link'] = !empty($_POST['linkedin_link']) ? $_POST['linkedin_link'] : null; 
                $social['youtube_link'] = !empty($_POST['youtube_link']) ? $_POST['youtube_link'] : null; 
                $social['pinterest_link'] = !empty($_POST['pinterest_link']) ? $_POST['pinterest_link'] : null; 
                $social['snapchat_link'] = !empty($_POST['snapchat_link']) ? $_POST['snapchat_link'] : null; 
                $social['whatsapp_link'] = !empty($_POST['whatsapp_link']) ? $_POST['whatsapp_link'] : null; 
                $social['threads_link'] =  !empty($_POST['threads_link']) ? $_POST['threads_link'] : null; 
                $social['tiktok_link'] =  !empty($_POST['tiktok_link']) ? $_POST['tiktok_link'] : null; 
                $social['others_link'] =  !empty($_POST['others_link']) ? $_POST['others_link'] : null; 
                $checklink = $this->qm->select_where('tbl_social_media', array('register_id' => $user_id));
                if(empty($checklink)){
                    $social['register_id'] = $user_id;
                    $this->qm->ins('tbl_social_media', $social);
                }else{
                    $this->qm->updt('tbl_social_media', $social,array('register_id' => $user_id));
                }

                $this->session->set_flashdata('success', 'Profile Update Successfully.');
                redirect('profile');
            }
        }else{
            $view_data['records'] = $this->qm->select_where('tbl_register', array('_id' => $user_id));
            $view_data['social_media'] = $this->qm->select_where('tbl_social_media', array('register_id' => $user_id));
            $this->load->view('web/header_user');
            $this->load->view('web/profile',$view_data);
            $this->load->view('web/footer_user');
        }
    }

    public function process_profile_ajax() {
        $url = $this->input->post('url');
        $user_id = $this->session->userdata('educationcv_web_id');
        $check = $this->qm->select_where('tbl_register', array('profile_url' => $url,'_id !=' => $user_id));
        if (empty($check)) {
            $post_data['profile_url'] = $url;
            $post_data['modified_at'] = date('Y-m-d H:i:s');
            $this->qm->updt('tbl_register', $post_data,array('_id' => $user_id));
            echo "Profile URL Updated";
        } else {
            echo "<b style='color:red;'>This name already used try diffrent<b>";
        }
    }

    public function delete_education_experience($id)
    {
        $user_id = $this->session->userdata('educationcv_web_id');
        $check = $this->qm->select_where('tbl_education_exp', array('_id' => $id,'register_id' => $user_id));
        if(!empty($check)){
            $where=array('_id'=>$id);
            $this->qm->dlt("tbl_education_exp",$where);   
        }
        $this->session->set_flashdata('success', 'Education experience Delete Successfully.');
        redirect('profile/education_experience');
    }

    public function education_experience(){
        $user_id = $this->session->userdata('educationcv_web_id');
        $update_id = $this->uri->segment(3);
        if (isset($_POST['submit'])) {
            $this->form_validation->set_rules('name', 'Name', 'required|max_length[100]');
            $this->form_validation->set_rules('collage_name', 'Collage Name', 'required|max_length[100]');
            $this->form_validation->set_rules('details', 'Details', 'required|max_length[500]');
            $this->form_validation->set_rules('start_year', 'Start Year', 'required|numeric');
            $this->form_validation->set_rules('end_year', 'End Year', 'required|numeric');
            $this->form_validation->set_rules('spent', 'Spent', 'required|numeric');
            if ($this->form_validation->run() === false) {
                $this->session->set_flashdata('error', validation_errors());
                $this->session->set_flashdata('post_error', $_POST);
                redirect('profile/education_experience');
            }else{
                date_default_timezone_set('Asia/Kolkata');
                $post_data1['name'] = $_POST['name'];
                $post_data1['collage_name'] = $_POST['collage_name'];
                $post_data1['details'] = $_POST['details'];
                $post_data1['start_year'] = $_POST['start_year'];
                $post_data1['end_year'] = $_POST['end_year'];
                $post_data1['spent'] = $_POST['spent'];
                $post_data1['register_id'] = $user_id;
                if ($update_id != "") {
                    $this->qm->updt('tbl_education_exp', $post_data1,array('_id' => $update_id));
                    $this->session->set_flashdata('success', 'Education experience Update Successfully.');
                }else{
                    $post_data1['created_at'] = date('Y-m-d H:i:s');
                    $this->qm->ins('tbl_education_exp', $post_data1);
                    $this->session->set_flashdata('success', 'Education experience Added Successfully.');
                }
                redirect('profile/education_experience');
            }
        }else{
            $view_data['records'] = $this->qm->select_where('tbl_register', array('_id' => $user_id));
            $view_data['education_exp'] = $this->qm->select_where('tbl_education_exp', array('register_id' => $user_id));
            if ($update_id != "") {
                $view_data['education_exp_update'] = $this->qm->select_where('tbl_education_exp', array('_id' => $update_id,'register_id' => $user_id));
                if(empty($view_data['education_exp_update'])){
                    redirect('profile/education_experience');
                }
            }
            $this->load->view('web/header_user');
            $this->load->view('web/education_experience',$view_data);
            $this->load->view('web/footer_user');
        }
    }

    public function delete_education_training($id)
    {
        $user_id = $this->session->userdata('educationcv_web_id');
        $check = $this->qm->select_where('tbl_education_traning', array('_id' => $id,'register_id' => $user_id));
        if(!empty($check)){
            $where=array('_id'=>$id);
            $this->qm->dlt("tbl_education_traning",$where);   
        }
        $this->session->set_flashdata('success', 'Education training Delete Successfully.');
        redirect('profile/education_training');
    }

    public function education_training(){
        $user_id = $this->session->userdata('educationcv_web_id');
        $update_id = $this->uri->segment(3);
        if (isset($_POST['submit'])) {
            $this->form_validation->set_rules('name', 'Name', 'required|max_length[100]');
            $this->form_validation->set_rules('collage_name', 'Collage Name', 'required|max_length[100]');
            $this->form_validation->set_rules('details', 'Details', 'required|max_length[500]');
            $this->form_validation->set_rules('start_year', 'Start Year', 'required|numeric');
            $this->form_validation->set_rules('end_year', 'End Year', 'required|numeric');
            $this->form_validation->set_rules('spent', 'Spent', 'required|numeric');
            if ($this->form_validation->run() === false) {
                $this->session->set_flashdata('error', validation_errors());
                $this->session->set_flashdata('post_error', $_POST);
                redirect('profile/education_training');
            }else{
                date_default_timezone_set('Asia/Kolkata');
                $post_data1['name'] = $_POST['name'];
                $post_data1['collage_name'] = $_POST['collage_name'];
                $post_data1['details'] = $_POST['details'];
                $post_data1['start_year'] = $_POST['start_year'];
                $post_data1['end_year'] = $_POST['end_year'];
                $post_data1['spent'] = $_POST['spent'];
                $post_data1['register_id'] = $user_id;
                if ($update_id != "") {
                    $this->qm->updt('tbl_education_traning', $post_data1,array('_id' => $update_id));
                    $this->session->set_flashdata('success', 'Education training Update Successfully.');
                }else{
                    $post_data1['created_at'] = date('Y-m-d H:i:s');
                    $this->qm->ins('tbl_education_traning', $post_data1);
                    $this->session->set_flashdata('success', 'Education training Added Successfully.');
                }
                redirect('profile/education_training');
            }
        }else{
            $view_data['records'] = $this->qm->select_where('tbl_register', array('_id' => $user_id));
            $view_data['education_traning'] = $this->qm->select_where('tbl_education_traning', array('register_id' => $user_id));
            if ($update_id != "") {
                $view_data['education_traning_update'] = $this->qm->select_where('tbl_education_traning', array('_id' => $update_id,'register_id' => $user_id));
                if(empty($view_data['education_traning_update'])){
                    redirect('profile/education_training');
                }
            }
            $this->load->view('web/header_user');
            $this->load->view('web/education_training',$view_data);
            $this->load->view('web/footer_user');
        }
    }

    public function delete_graduate_certificate($id)
    {
        $user_id = $this->session->userdata('educationcv_web_id');
        $check = $this->qm->select_where('tbl_graduate_certificate', array('_id' => $id,'register_id' => $user_id));
        if(!empty($check)){
            $where=array('_id'=>$id);
            $data['tbl'] = 'tbl_graduate_certificate';
            $data['select_field'] = 'file';
            $data['where_field'] = "_id='".$id."'";
            $imgpath = 'images/certificate';
            $data['img_path'] = glob($imgpath.'*');
            $this->qm->delete_img($data);
            $this->qm->dlt("tbl_graduate_certificate",$where);   
        }
        $this->session->set_flashdata('success', 'Graduate Certificate Delete Successfully.');
        redirect('profile/graduate_certificate');
    }

    public function graduate_certificate(){
        $user_id = $this->session->userdata('educationcv_web_id');
        $update_id = $this->uri->segment(3);
        if (isset($_POST['submit'])) {
            $this->form_validation->set_rules('name', 'Name', 'required|max_length[100]');
            $this->form_validation->set_rules('course_name', 'Course Name', 'required|max_length[100]');
            $this->form_validation->set_rules('location', 'Location', 'required|max_length[500]');
            if ($this->form_validation->run() === false) {
                $this->session->set_flashdata('error', validation_errors());
                $this->session->set_flashdata('post_error', $_POST);
                redirect('profile/graduate_certificate');
            }else{
                date_default_timezone_set('Asia/Kolkata');
                if (isset($_FILES['file']['name']) && ($_FILES['file']['name']) != "") {
                    if ($update_id != "") {
                        $data['tbl'] = 'tbl_graduate_certificate';
                        $data['select_field'] = 'file';
                        $data['where_field'] = "_id='".$update_id."'";
                        $imgpath = 'images/certificate';
                        $data['img_path'] = glob($imgpath.'*');
                        $this->qm->delete_img($data);
                    }

                    $type = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
                    $file = rand(1111, 9999) . time() . "." . $type;
                    $config['file_name'] = $file;
                    $config['upload_path'] = "images/certificate/";
                    $config['allowed_types'] = "jpg|jpeg|png";
                    $this->upload->initialize($config);
                    $this->upload->do_upload('file');
                    $post_data1['file'] = $file;
                }

                $post_data1['name'] = $_POST['name'];
                $post_data1['course_name'] = $_POST['course_name'];
                $post_data1['location'] = $_POST['location'];
                $post_data1['register_id'] = $user_id;
                if ($update_id != "") {
                    $this->qm->updt('tbl_graduate_certificate', $post_data1,array('_id' => $update_id));
                    $this->session->set_flashdata('success', 'Graduate Certificate Update Successfully.');
                }else{
                    $post_data1['created_at'] = date('Y-m-d H:i:s');
                    $this->qm->ins('tbl_graduate_certificate', $post_data1);
                    $this->session->set_flashdata('success', 'Graduate Certificate Added Successfully.');
                }
                redirect('profile/graduate_certificate');
            }
        }else{
            $view_data['records'] = $this->qm->select_where('tbl_register', array('_id' => $user_id));
            $view_data['graduate_certificate'] = $this->qm->select_where('tbl_graduate_certificate', array('register_id' => $user_id));
            if ($update_id != "") {
                $view_data['graduate_certificate_update'] = $this->qm->select_where('tbl_graduate_certificate', array('_id' => $update_id,'register_id' => $user_id));
                if(empty($view_data['graduate_certificate_update'])){
                    redirect('profile/graduate_certificate');
                }
            }
            $this->load->view('web/header_user');
            $this->load->view('web/graduate_certificate',$view_data);
            $this->load->view('web/footer_user');
        }
    }

    public function delete_websites($id)
    {
        $user_id = $this->session->userdata('educationcv_web_id');
        $check = $this->qm->select_where('tbl_websites', array('_id' => $id,'register_id' => $user_id));
        if(!empty($check)){
            $where=array('_id'=>$id);
            $this->qm->dlt("tbl_websites",$where);   
        }
        $this->session->set_flashdata('success', 'Website Delete Successfully.');
        redirect('profile/programs_websites');
    }

    public function delete_non_award_program($id)
    {
        $user_id = $this->session->userdata('educationcv_web_id');
        $check = $this->qm->select_where('tbl_non_award_program', array('_id' => $id,'register_id' => $user_id));
        if(!empty($check)){
            $where=array('_id'=>$id);
            $this->qm->dlt("tbl_non_award_program",$where);   
        }
        $this->session->set_flashdata('success', 'Non Award Program Delete Successfully.');
        redirect('profile/programs_websites');
    }

    public function programs_websites(){
        $user_id = $this->session->userdata('educationcv_web_id');
        if (isset($_POST['submit'])) {
            $this->form_validation->set_rules('website_name', 'Website Name', 'required|valid_url');
            if ($this->form_validation->run() === false) {
                $this->session->set_flashdata('error', validation_errors());
                $this->session->set_flashdata('post_error', $_POST);
                redirect('profile/programs_websites');
            }else{
                date_default_timezone_set('Asia/Kolkata');
                $post_data1['website_name'] = $_POST['website_name'];
                $post_data1['register_id'] = $user_id;
                $post_data1['created_at'] = date('Y-m-d H:i:s');
                $this->qm->ins('tbl_websites', $post_data1);
                $this->session->set_flashdata('success', 'Website Added Successfully.');
                redirect('profile/programs_websites');
            }
        }else if (isset($_POST['submit1'])) {
            $this->form_validation->set_rules('name', 'Name', 'required|max_length[100]');
            if ($this->form_validation->run() === false) {
                $this->session->set_flashdata('error', validation_errors());
                $this->session->set_flashdata('post_error', $_POST);
                redirect('profile/programs_websites');
            }else{
                date_default_timezone_set('Asia/Kolkata');
                $post_data1['name'] = $_POST['name'];
                $post_data1['register_id'] = $user_id;
                $post_data1['created_at'] = date('Y-m-d H:i:s');
                $this->qm->ins('tbl_non_award_program', $post_data1);
                $this->session->set_flashdata('success', 'Non Award Program Added Successfully.');
                redirect('profile/programs_websites');
            }
        }else{
            $view_data['records'] = $this->qm->select_where('tbl_register', array('_id' => $user_id));
            $view_data['non_award_program'] = $this->qm->select_where('tbl_non_award_program', array('register_id' => $user_id));
            $view_data['websites'] = $this->qm->select_where('tbl_websites', array('register_id' => $user_id));
            $this->load->view('web/header_user');
            $this->load->view('web/programs_websites',$view_data);
            $this->load->view('web/footer_user');
        }
    }
}