<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {

	public function __construct(){	
		parent::__construct();
		$this->load->model('Query_model','qm',TRUE);
		$this->load->library('form_validation');
	}
	
	public function index(){
		if($this->session->userdata('educationcv_web_email') != "" && $this->session->userdata('educationcv_web_id') != ""){
			redirect('dashboard');
		}
		if(isset($_POST['login'])){
			$this->form_validation->set_rules('username', 'Username', 'required|valid_email');
        	$this->form_validation->set_rules('password', 'Password', 'required|min_length[5]');
       		if ($this->form_validation->run() === false) {
       			$this->session->set_flashdata('error', validation_errors());
       			$this->session->set_flashdata('username', $_POST['username']);
       			$this->session->set_flashdata('password', $_POST['password']);
       			redirect('login');
       		}else{
       			$username = $this->input->post('username');
            	$password = $this->input->post('password');
				$where = array ('email_id' => $username, 'password' => md5($password));
				$validate = $this->qm->select_where('tbl_register',$where);
				if(!empty($validate))
				{
					$this->session->set_userdata('educationcv_web_email',$validate[0]['email_id']);
					$this->session->set_userdata('educationcv_web_id',$validate[0]['_id']);
					$this->session->set_flashdata('success', 'Login successful!');
	                redirect('dashboard');
				}else{
					$this->session->set_flashdata('error', 'Invalid username or password.');
					redirect('login');
				}
			}
		}else{  
			$this->load->view('web/header');
			$this->load->view('web/login');
			$this->load->view('web/footer');
		}
	}

	public function register(){
		if($this->session->userdata('educationcv_web_email') != "" && $this->session->userdata('educationcv_web_id') != ""){
			redirect('dashboard');
		}
		if(isset($_POST['register'])){
			$this->form_validation->set_rules('name', 'Name', 'required');
			$this->form_validation->set_rules('email_id', 'Email', 'required|valid_email|is_unique[tbl_register.email_id]');
			$this->form_validation->set_message('is_unique', 'Email already registered.Try Diffrent.');
        	$this->form_validation->set_rules('password', 'Password', 'required|min_length[5]');
       		if ($this->form_validation->run() === false) {
       			$this->session->set_flashdata('error', validation_errors());
       			$this->session->set_flashdata('name', $_POST['name']);
       			$this->session->set_flashdata('email_id', $_POST['email_id']);
       			$this->session->set_flashdata('password', $_POST['password']);
       			redirect('register');
       		}else{
       			$post_data = array(
					'name' => ucfirst($_POST['name']),
					'email_id' => $_POST['email_id'],
					'password' => md5($_POST['password']),
					'status' => 1,
					'created_at' => date('Y-m-d H:i:s'),
					'modified_at' => date('Y-m-d H:i:s'),
				);
				$register_id  = $this->qm->ins('tbl_register', $post_data);
				$this->session->set_userdata('educationcv_web_email',$_POST['email_id']);
				$this->session->set_userdata('educationcv_web_id',$register_id);
				$this->session->set_flashdata('success', 'Login successful!');
	            redirect('dashboard');
			}
		}else{  
			$this->load->view('web/header');
			$this->load->view('web/register');
			$this->load->view('web/footer');
		}
	}


	public function logout(){
		$sess_array = array('educationcv_web_email','educationcv_web_id');
        $this->session->unset_userdata($sess_array);
		redirect('login');
	}
}