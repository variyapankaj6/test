<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends CI_Controller {

	public function __construct(){	
		parent::__construct();
		$this->load->model('Query_model','qm',TRUE);
	}
	
	public function index(){
		$view_data['top_profiles'] = $this->db->query('SELECT * FROM tbl_register ORDER BY profile_view DESC LIMIT 8')->result_array();
		$this->load->view('web/header');
		$this->load->view('web/home',$view_data);
		$this->load->view('web/footer');
	}
}