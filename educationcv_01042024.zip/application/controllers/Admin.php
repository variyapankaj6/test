<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends CI_Controller {

	public function __construct(){	
		parent::__construct();
		$this->load->model('Query_model','qm',TRUE);
	}
	
	public function index(){
		if($this->session->userdata('educationcv_email') != "" && $this->session->userdata('educationcv_id') != ""){
			redirect('sup_admin/dashboard');
		}
		
		if(isset($_POST['login'])){

			$where = array ('email_id' => $_POST['admin'], 'password' => md5($_POST['pass']));
			$validate['login'] = $this->qm->select_where('tbl_login',$where);
			if(!empty($validate['login']))
			{
				$educationcv_email = $validate['login'][0]['email_id'];
			    $educationcv_id = $validate['login'][0]['_id'];
				$this->session->set_userdata('educationcv_email',$educationcv_email);
				$this->session->set_userdata('educationcv_id',$educationcv_id);
				redirect('sup_admin/dashboard');
			}else{
				$view_data['error'] = "Username OR Password is incorrect.";
				$this->load->view('login',$view_data);
			}
		}else{  
			$this->load->view('login');
		}
	}
	
	public function dashboard(){
		if($this->session->userdata('educationcv_email') != "" && $this->session->userdata('educationcv_id') != "")
		{
			redirect('sup_admin/dashboard');
		}
	}
	
	public function change_pswd()
	{
		$old_pswd = $_POST['old_pswd']; //$this->uri->segment(3);
		$new_pswd = $_POST['new_pswd']; // $this->uri->segment(4);
		
		$admin_name = $this->session->userdata('educationcv_email');
		$where = array ('email_id' => $admin_name, 'password' => md5($old_pswd));
		$num_row = $this->qm->num_row('tbl_login',$where);
		if($num_row == 1)
		{
			$what = array (
				'password' => md5($new_pswd)
			);	
			$where = array (
				'email_id' => $admin_name
			);
			$this->qm->updt('tbl_login',$what,$where);
			echo "Password is Successfully Changed.";
		}
		else
		{
			echo "Old Password is not correct";
		}
	} 

	public function logout(){
		$sess_array = array('educationcv_email','educationcv_id');
        $this->session->unset_userdata($sess_array);
		redirect('/admin');
	}
}