<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Changepassword extends CI_Controller {

	public function __construct(){	
		parent::__construct();
		$this->load->model('security_model');
        $this->load->library('form_validation');
		$this->security_model->is_logged_in_web();
		$this->load->model('query_model','qm',TRUE);
	}
	
	public function index(){
		$this->load->view('web/header_user');
		$this->load->view('web/changepassword');
		$this->load->view('web/footer_user');
	}
}