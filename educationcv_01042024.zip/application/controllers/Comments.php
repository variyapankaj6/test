<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Comments extends CI_Controller {

	public function __construct(){	
		parent::__construct();
		$this->load->model('security_model');
		$this->load->model('Comments_table');
        $this->load->library('form_validation');
		$this->security_model->is_logged_in_web();
		$this->load->model('query_model','qm',TRUE);
	}
	
	public function index(){
		$this->load->view('web/header_user');
		$this->load->view('web/comments');
		$this->load->view('web/footer_user');
	}

	public function getLists(){
        $data = $row = array();
        $user_id = $this->session->userdata('educationcv_web_id');
        $where1 = array();
        $where1[] = 'register_id = '.$user_id;
        $where = implode(' AND ',$where1);
        $memData = $this->Comments_table->getRows($_POST,$where);
        $i = $_POST['start'];
        foreach($memData as $member){
            $i++;
            $sub_array = array();  
            $sub_array[] = '<div class="pxp-candidate-dashboard-job-title">'.$member->name.'</div>
                        <div class="pxp-candidate-dashboard-job-location">'.$member->profession.'</div>';
            $sub_array[] = $member->message; 
            $sub_array[] = date('d M Y h:i A',strtotime($member->created_at));
            $data[] = $sub_array; 
        }

        
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Comments_table->countAll($where),
            "recordsFiltered" => $this->Comments_table->countFiltered($_POST,$where),
            "data" => $data,
            "class" => "red"
        );
        // Output to JSON format
        echo json_encode($output);
    }
}