<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Registers extends CI_Controller {

	public function __construct(){	
		parent::__construct();
		$this->load->model('Registers_table');
		$this->load->model('security_model');
		$this->security_model->is_logged_in();
		$this->load->model('query_model','qm',TRUE);
	}

	public function index(){
		$this->load->view('admin/header');
		$this->load->view('admin/registers_list');
		$this->load->view('admin/footer');
	}

	public function active_deactive($id,$val){
        $this->qm->updt("tbl_register",array('status'=>$val),array('_id'=>$id));
    }

    public function active_suspend($id,$val){
        $this->qm->updt("tbl_register",array('is_suspend'=>$val),array('_id'=>$id));
    }

	public function getLists(){
        $data = $row = array();
        $where1 = array();
        $where = implode(' AND ',$where1);
        $memData = $this->Registers_table->getRows($_POST,$where);
        $i = $_POST['start'];
        foreach($memData as $member){
            $i++;
			if($member->status == '1') 
			{
				$status = '<i class="fa fa-toggle-on" onclick="active_deactive('.$member->_id.',0)" style="font-size:40px;color:green;"></i>';
			}else{
				$status = '<i class="fa fa-toggle-off" onclick="active_deactive('.$member->_id.',1)" style="font-size:40px;color:green;"></i>';
			}

			if($member->is_suspend == '1') 
			{
				$is_suspend = '<i class="fa fa-toggle-on" onclick="active_suspend('.$member->_id.',0)" style="font-size:40px;color:red;"></i>';
			}else{
				$is_suspend = '<i class="fa fa-toggle-off" onclick="active_suspend('.$member->_id.',1)" style="font-size:40px;color:red;"></i>';
			}

			if($member->photo)
			{
				$photo = IMAGE."user/".$member->photo;
			}else{
				$photo = NO_USER;
			}

            $sub_array = array();  
            $sub_array[] = $i;
            $sub_array[] = '<a class="product-list-img" href="javascript: void(0);"><img src="'.$photo.'" class="rounded"></a><br/>'.$member->profession.'<br/>'.$member->name;
            $sub_array[] = "<small>Mobile No</small> : ".$member->mobile_no."<br/> <small>Email</small> : ".$member->email_id;
            $sub_array[] = $member->location;
            $sub_array[] = "<small>Followers</small> : ".$member->followers."<br/> <small>Following</small> : ".$member->following."<br/> <small>Profile View</small> : ".$member->profile_view;
            $sub_array[] = $status;
            $sub_array[] = $is_suspend; 
            $sub_array[] = '<ul class="table-controls">
                            <li>
                               <a target="_blank" href="'.base_url('/').$member->profile_url.'" data-toggle="tooltip" data-placement="top" title="" data-original-title="View">
                               <i class="flaticon-view" style="color: green;"></i>
                               </a>
                            </li>
                            <li>
                               <a href="javascript:void(0);" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete" onClick="dlt_data('.$member->_id.')">
                               <i class="flaticon-delete-5"  style="color: red;"></i>
                               </a>
                            </li>
                         </ul>';
            $data[] = $sub_array;
    	}

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Registers_table->countAll($where),
            "recordsFiltered" => $this->Registers_table->countFiltered($_POST,$where),
            "data" => $data,
        );
        // Output to JSON format
        echo json_encode($output);
    }

	function delete($admin_id='')
    {
        if($admin_id=='')
            $user_id=$this->input->post('admin_id');
        else
            $user_id = array($admin_id);
        foreach($user_id as $admin_id)
        {
            $where=array('_id'=>$admin_id);
			$this->qm->dlt("tbl_register",$where);
        }
        redirect('sup_admin/registers');
    }
}