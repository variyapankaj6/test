<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Contactus extends CI_Controller {

	public function __construct(){	
		parent::__construct();
		$this->load->model('Contactus_table');
		$this->load->model('security_model');
		$this->security_model->is_logged_in();
		$this->load->model('query_model','qm',TRUE);
	}

	public function index(){
		$this->load->view('admin/header');
		$this->load->view('admin/contactus_list');
		$this->load->view('admin/footer');
	}

	public function getLists(){
        $data = $row = array();
        $where1 = array();
        $where = implode(' AND ',$where1);
        
        $memData = $this->Contactus_table->getRows($_POST,$where);
        $i = $_POST['start'];
        foreach($memData as $member){
            $i++;
            $sub_array = array();  
            $sub_array[] = $i;
            $sub_array[] = $member->name;
            $sub_array[] = $member->email_id;
            $sub_array[] = $member->subject;
            $sub_array[] = $member->message;
            $sub_array[] = $member->created_at; 
            $sub_array[] = '<ul class="table-controls">
                            <li>
                               <a href="javascript:void(0);" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete" onClick="dlt_data('.$member->_id.')">
                               <i class="flaticon-delete-5"  style="color: red;"></i>
                               </a>
                            </li>
                         </ul>';
            $data[] = $sub_array;
    	}

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Contactus_table->countAll($where),
            "recordsFiltered" => $this->Contactus_table->countFiltered($_POST,$where),
            "data" => $data,
        );
        // Output to JSON format
        echo json_encode($output);
    }

	function delete($admin_id='')
    {
        if($admin_id=='')
            $user_id=$this->input->post('admin_id');
        else
            $user_id = array($admin_id);
        foreach($user_id as $admin_id)
        {
            $where=array('_id'=>$admin_id);
			$this->qm->dlt("tbl_contact_us",$where);
        }
        redirect('sup_admin/contactus');
    }
}