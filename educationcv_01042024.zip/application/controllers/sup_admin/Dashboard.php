<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('security_model');
		$this->security_model->is_logged_in();
		$this->load->model('query_model','qm',TRUE);
	}
	
	public function index(){
		$view_data['register_total'] = $this->db->count_all('tbl_register');
		$view_data['contactus_total'] = $this->db->count_all('tbl_contact_us');
		$this->load->view('admin/header');
		$this->load->view('admin/dashboard',$view_data);
		$this->load->view('admin/footer');
	}
}