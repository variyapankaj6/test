<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Cms_pages extends CI_Controller {

	public function __construct(){	
		parent::__construct();
		$this->load->model('CMS_table');
		$this->load->model('security_model');
		$this->security_model->is_logged_in();
		$this->load->model('query_model','qm',TRUE);
	}

	public function index(){
		$this->load->view('admin/header');
		$this->load->view('admin/cms_list');
		$this->load->view('admin/footer');
	}

	public function getLists(){
        $data = $row = array();
        $where = "";
        $memData = $this->CMS_table->getRows($_POST,$where);
        $i = $_POST['start'];
        foreach($memData as $member){
            $i++;
            date_default_timezone_set('UTC');
            $sub_array = array();  
            $sub_array[] = $i;
            $sub_array[] = $member->name; 
            $sub_array[] = date('d M Y',strtotime($member->created_at));   
            $sub_array[] = '<ul class="table-controls">
                            
                            <li><a href="' . base_url('sup_admin/cms_pages/add_cms_pages') . "/" . $member->_id . '" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
                            <i class="flaticon-edit" style="color:green;"></i>
                            </a></li>
                            <li><a href="javascript:void(0);" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete" onClick="dlt_data(' . $member->_id . ')">
                                <i class="flaticon-delete-5" style="color:red;"></i>
                             </a> </li>
             </ul>';

             // <li>
             //                   <a href="'.base_url('page/').$member->name.'" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="View">
             //                   <i class="flaticon-view" style="color: blue;"></i>
             //                   </a>
             //                </li>
            $data[] = $sub_array; 
        }

        
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->CMS_table->countAll($where),
            "recordsFiltered" => $this->CMS_table->countFiltered($_POST,$where),
            "data" => $data,
            "class" => "red"
        );
        // Output to JSON format
        echo json_encode($output);
    }

    public function add_cms_pages()
    {
        $this->load->view('admin/header');
        $id = $this->uri->segment(4);
        if ($id != "") {
            if (isset($_POST['submit'])) {
                $where = array('_id' => $id);
                date_default_timezone_set('UTC');
                $post_data['contant'] = $_POST['contant'];
                $post_data['name'] = ucfirst($_POST['name']);
                $post_data['modified_at'] = date('Y-m-d H:i:s');
                $this->qm->updt('tbl_cms_page', $post_data, $where);
                redirect('sup_admin/cms_pages');
            } 
            else 
            {
                $view_data['records'] = $this->qm->select_where('tbl_cms_page', array('_id' => $id));
                $this->load->view('admin/add_cms_pages', $view_data);
            }
        }
        else
        {
            if(isset($_POST['submit']))
            {
                date_default_timezone_set('UTC');
                $post_data = array(
                    'name' => ucfirst($_POST['name']),
                    'contant' => $_POST['contant'],
                    'created_at' => date('Y-m-d H:i:s'),
                    'modified_at' => date('Y-m-d H:i:s'),
                );

                $this->qm->ins('tbl_cms_page', $post_data);
                redirect('sup_admin/cms_pages');
            }
            $this->load->view('admin/add_cms_pages');
         }
        $this->load->view('admin/footer');
    }

    function delete($admin_id='')
    {
        if($admin_id=='')
            $user_id=$this->input->post('admin_id');
        else
            $user_id = array($admin_id);
        foreach($user_id as $admin_id)
        {
            $where=array('_id'=>$admin_id);         
            $this->qm->dlt("tbl_cms_page",$where);
        }
        redirect('sup_admin/cms_pages');
    }
}

