<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Contact_us extends CI_Controller {

	public function __construct(){	
		parent::__construct();
		$this->load->model('Query_model','qm',TRUE);
		$this->load->library('form_validation');
	}
	
	public function index(){
		if(isset($_POST['submit'])){
			$this->form_validation->set_rules('email_id', 'Email', 'required|valid_email');
        	$this->form_validation->set_rules('name', 'Name', 'required');
        	$this->form_validation->set_rules('subject', 'Subject', 'required');
        	$this->form_validation->set_rules('message', 'Message', 'required');
       		if ($this->form_validation->run() === false) {
       			$this->session->set_flashdata('error', validation_errors());
       			$this->session->set_flashdata('errorpost', $_POST);
       			redirect('contact_us');
       		}else{
				date_default_timezone_set('Asia/Kolkata');
	            $post_data = array(
	            	'name' => $_POST['name'],
	                'email_id' => $_POST['email_id'],
	                'subject' => $_POST['subject'],
	                'message' => $_POST['message'],
	                'created_at' => date('Y-m-d H:i:s')
	            );
	            $this->qm->ins('tbl_contact_us', $post_data);
	            $this->session->set_flashdata('success', 'Your contact information has been sent successfully! Thank you for reaching out. We will be in touch soon.');
	            redirect('contact_us');
	        }
		}
		$this->load->view('web/header');
		$this->load->view('web/contact_us');
		$this->load->view('web/footer');
	}
}