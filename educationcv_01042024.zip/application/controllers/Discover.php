<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Discover extends CI_Controller {

    public function __construct(){  
        parent::__construct();
        $this->load->model('Query_model','qm',TRUE);
        $this->load->model('Discover_pagination');
        $this->load->library("pagination");
    }
    
    public function index(){
        $where1 = array();
        $is_filter = 0;
        if(isset($_GET['location'])){
            $data['fil_location'] = $_GET['location'];
            $where1[] = "location LIKE '%".$_GET['location']."%'";
            $is_filter = 1;
        }else{
           $data['fil_location'] = '';
        }

        if(isset($_GET['search'])){
            $data['fil_search'] = $_GET['search'];
            $where1[] = "(name LIKE '%".$_GET['search']."%' OR about_us LIKE '%".$_GET['search']."%')"; 
            $is_filter = 1;
        }else{
           $data['fil_search'] = '';
        }

        if(isset($_GET['order']))
        {
            $data['fil_order'] = $_GET['order'];
        }else{
            $data['fil_order'] = '';
        }
        $where = implode(' AND ',$where1);

        $config = array();
        $config["base_url"] = base_url()."discover";
        $config["total_rows"] = $this->Discover_pagination->get_count($where);
        $config["per_page"] = 12;
        $config["uri_segment"] = 2;
        $config['page_query_string'] = TRUE;
        $config['query_string_segment'] = 'page';
        $config['reuse_query_string'] = true;
        $config['attributes'] = array('class' => 'page-link');

        $config['next_link'] = '<i class="fa fa-arrow-right" aria-hidden="true"></i>';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '<i class="fa fa-arrow-left" aria-hidden="true"></i>';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="page-item active"><a href="javascript:void(0)" class="page-link">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
             

        $this->pagination->initialize($config);
        $current_page = $this->input->get('page',0);

        $data["links"] = $this->pagination->create_links();
        $data['discoverlist'] = $this->Discover_pagination->get_items($config["per_page"], $current_page,$where,$data['fil_order']);
       
        $data['total_items'] = $this->Discover_pagination->get_count($where);

        $data['is_filter'] = $is_filter;

        $this->load->view('web/header');
        $this->load->view('web/discoverlist',$data);
        $this->load->view('web/footer');
    }


    public function view($id){
        $data['register_details'] = $this->qm->select_where('tbl_register',array('_id' => $id));
        if(!empty($data['register_details'])){
            if(isset($_POST['submit'])){
                if($this->session->userdata('educationcv_web_email') != "" && $this->session->userdata('educationcv_web_id') != ""){
                    date_default_timezone_set('Asia/Kolkata');
                    $post_data['post_register_id'] = $this->session->userdata('educationcv_web_id');
                    $post_data['register_id'] = $id;
                    $post_data['message'] = $_POST['comment'];
                    $post_data['status'] = 1;
                    $this->qm->ins('tbl_comments', $post_data);
                    $this->session->set_flashdata('success', 'Comment sent successfully.');
                    redirect('discover/view/'.$id.'#commentview');
                }else{
                    $this->session->set_flashdata('error', 'Login Required.');
                    redirect('discover/view/'.$id.'#commentview');
                }
            }
            if($data['register_details'][0]['photo'])
            {
               $data['image'] = IMAGE."user/".$data['register_details'][0]['photo'];
            }else{
               $data['image'] = NO_USER;
            }
            $data['education_exp'] = $this->qm->select_where('tbl_education_exp',array('register_id' => $id));
            $data['education_traning'] = $this->qm->select_where('tbl_education_traning',array('register_id' => $id));
            $data['graduate_certificate'] = $this->qm->select_where('tbl_graduate_certificate',array('register_id' => $id));
            $data['non_award_program'] = $this->qm->select_where('tbl_non_award_program',array('register_id' => $id));
            $data['comments_total'] = $this->qm->num_row('tbl_comments',array('register_id' => $id));
            $data['comments'] = $this->db->query('SELECT tbl_comments.*, tbl_register.name, tbl_register.photo FROM tbl_comments JOIN tbl_register ON tbl_comments.post_register_id = tbl_register._id WHERE tbl_comments.register_id = '.$id.' ORDER BY tbl_comments._id DESC LIMIT 5')->result_array();
            $data['social_media'] = $this->qm->select_where('tbl_social_media',array('register_id' => $id));
            $this->load->view('web/header');
            $this->load->view('web/discoverview',$data);
            $this->load->view('web/footer');
        }else{
            redirect('discover');
        }
    }

    public function view_main($profile_url){
        $data['register_details'] = $this->qm->select_where('tbl_register',array('profile_url' => $profile_url));
        if(!empty($data['register_details'])){
            $register_id = $data['register_details'][0]['_id'];
            if(isset($_POST['submit'])){
                if($this->session->userdata('educationcv_web_email') != "" && $this->session->userdata('educationcv_web_id') != ""){
                    date_default_timezone_set('Asia/Kolkata');
                    $post_data['post_register_id'] = $this->session->userdata('educationcv_web_id');
                    $post_data['register_id'] = $register_id;
                    $post_data['message'] = $_POST['comment'];
                    $post_data['status'] = 1;
                    $this->qm->ins('tbl_comments', $post_data);
                    $this->session->set_flashdata('success', 'Comment sent successfully.');
                    redirect($profile_url.'#commentview');
                }else{
                    $this->session->set_flashdata('error', 'Login Required.');
                    redirect($profile_url.'#commentview');
                }
            }
            if($data['register_details'][0]['photo'])
            {
               $data['image'] = IMAGE."user/".$data['register_details'][0]['photo'];
            }else{
               $data['image'] = NO_USER;
            }
            $data['education_exp'] = $this->qm->select_where('tbl_education_exp',array('register_id' => $register_id));
            $data['education_traning'] = $this->qm->select_where('tbl_education_traning',array('register_id' => $register_id));
            $data['graduate_certificate'] = $this->qm->select_where('tbl_graduate_certificate',array('register_id' => $register_id));
            $data['non_award_program'] = $this->qm->select_where('tbl_non_award_program',array('register_id' => $register_id));
            $data['comments_total'] = $this->qm->num_row('tbl_comments',array('register_id' => $register_id));
            $data['comments'] = $this->db->query('SELECT tbl_comments.*, tbl_register.name, tbl_register.photo
                                FROM tbl_comments
                                JOIN tbl_register ON tbl_comments.post_register_id = tbl_register._id
                                WHERE tbl_comments.register_id = '.$register_id.'
                                ORDER BY tbl_comments._id DESC
                                LIMIT 5;
                                ')->result_array();
            $data['social_media'] = $this->qm->select_where('tbl_social_media',array('register_id' => $register_id));


            $this->db->select('SUM(spent) AS total_spent');
            $this->db->select('SUM(end_year - start_year) AS total_years');
            $this->db->from('tbl_education_exp');
            $this->db->where('register_id',$register_id);
            $query = $this->db->get();
            $result = $query->row();
            $totalSpent = $result->total_spent; // Total spent
            $totalYears = $result->total_years; // Total years


            $this->db->select('SUM(spent) AS total_spent');
            $this->db->select('SUM(end_year - start_year) AS total_years');
            $this->db->from('tbl_education_traning');
            $this->db->where('register_id',$register_id);
            $query = $this->db->get();
            $result1 = $query->row();
            $totalSpent1 = $result1->total_spent; // Total spent
            $totalYears1 = $result1->total_years; // Total years


            $data['totalSpent'] = $totalSpent+$totalSpent1; // Total spent
            $data['totalYears'] = $totalYears+$totalYears1; // Total years
            $this->load->view('web/header');
            $this->load->view('web/discoverview',$data);
            $this->load->view('web/footer');
        }else{
            redirect('discover');
        }
    }
}