<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Followers extends CI_Controller {

	public function __construct(){	
		parent::__construct();
		$this->load->model('security_model');
		$this->load->model('Followers_table');
		$this->load->model('Following_table');
        $this->load->library('form_validation');
		$this->security_model->is_logged_in_web();
		$this->load->model('query_model','qm',TRUE);
	}
	
	public function index(){
		$this->load->view('web/header_user');
		$this->load->view('web/followers');
		$this->load->view('web/footer_user');
	}

	public function following(){
		$this->load->view('web/header_user');
		$this->load->view('web/following');
		$this->load->view('web/footer_user');
	}

	public function getLists_following(){
        $data = $row = array();
        $user_id = $this->session->userdata('educationcv_web_id');
        $where1 = array();
        $where1[] = 'register_id = '.$user_id;
        $where = implode(' AND ',$where1);
        $memData = $this->Following_table->getRows($_POST,$where);
        $i = $_POST['start'];
        foreach($memData as $member){
            $i++;
            $sub_array = array();  
            $sub_array[] = '<div class="pxp-candidate-dashboard-job-title">'.$member->name.'</div>
                        <div class="pxp-candidate-dashboard-job-location">'.$member->profession.'</div>';
            $sub_array[] = $member->location; 
            $sub_array[] = $member->followers; 
            if($member->status == 1){ 
            	$sub_array[] = '<b style="color:green;">Accepted</b>'; 
            }else if($member->status == 2){ 
            	$sub_array[] = '<b style="color:red;">Rejected</b>'; 
            }else{ 
            	$sub_array[] = '<b style="color:blue;">Pending</b>'; 
            }
            $sub_array[] = date('d M Y h:i A',strtotime($member->created_at));
            $data[] = $sub_array; 
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Following_table->countAll($where),
            "recordsFiltered" => $this->Following_table->countFiltered($_POST,$where),
            "data" => $data,
            "class" => "red"
        );
        // Output to JSON format
        echo json_encode($output);
    }

	public function getLists(){
        $data = $row = array();
        $user_id = $this->session->userdata('educationcv_web_id');
        $where1 = array();
        $where1[] = 'post_register_id = '.$user_id;
        $where = implode(' AND ',$where1);
        $memData = $this->Followers_table->getRows($_POST,$where);
        $i = $_POST['start'];
        foreach($memData as $member){
            $i++;
            $sub_array = array();  
            $sub_array[] = '<div class="pxp-candidate-dashboard-job-title">'.$member->name.'</div>
                        <div class="pxp-candidate-dashboard-job-location">'.$member->profession.'</div>';
            $sub_array[] = $member->location; 
            $sub_array[] = $member->followers; 
            if($member->status == 1){ 
            	$sub_array[] = '<b style="color:green;">Accepted</b>'; 
            }else if($member->status == 2){ 
            	$sub_array[] = '<b style="color:red;">Rejected</b>'; 
            }else{ 
            	$sub_array[] = '<b style="color:blue;">Pending</b>'; 
            }
            $sub_array[] = date('d M Y h:i A',strtotime($member->created_at));
            $data[] = $sub_array; 
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Followers_table->countAll($where),
            "recordsFiltered" => $this->Followers_table->countFiltered($_POST,$where),
            "data" => $data,
            "class" => "red"
        );
        // Output to JSON format
        echo json_encode($output);
    }
}