<?php
class Discover_pagination extends CI_Model {

    protected $table = 'tbl_register';

    public function __construct() {
        parent::__construct();
    }

    public function get_count($where) {
        if($where != '')
        {
            $this->db->where($where);
        }
        $query = $this->db->get($this->table);
        return $query->num_rows();
    }

    public function get_items($limit, $start ,$where,$order) {
        $this->db->limit($limit, $start);
        if($where != '')
        {
            $this->db->where($where);
        }
        if($order != '')
        {
            if($order == "AtoZ"){
                $this->db->order_by("name","ASC");
            }else if($order == "ZtoA"){
                $this->db->order_by("name","DESC");
            }else if($order == "price_asc"){
                $this->db->order_by("name","ASC");
            }else{
                $this->db->order_by("created_at","DESC");
            }
        }
        $query = $this->db->get($this->table);
        // print_r($where); die();
        return $query->result();
    }
}