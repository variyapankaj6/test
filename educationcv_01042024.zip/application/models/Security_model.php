<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Security_model extends CI_Model{
    public function is_logged_in(){
        if($this->session->userdata('educationcv_email') != "" && $this->session->userdata('educationcv_id') != ""){
            return true;
        }else{
             $this->session->set_flashdata('error','Please login!');
             redirect('/admin');
        }
    }
    
    public function is_logged_in_web(){
        if($this->session->userdata('educationcv_web_email') != "" && $this->session->userdata('educationcv_web_id') != ""){
            return true;
        }else{
             $this->session->set_flashdata('error','Please login!');
             redirect('');
        }
    }
}